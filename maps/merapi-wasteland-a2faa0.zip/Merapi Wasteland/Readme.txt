Command & Conquer Generals: Zero Hour Map

================================================================
Title                   : Merapi Wasteland
Version                 : 1.0
Author                  : Pascalis Sadewa Setyanta
Email Address           : pascalis_sadewa@yahoo.co.id

Twitter			: pascalisadewa

deviantART		: http://dawn-shade.deviantart.com

Facebook		: http://www.facebook.com/pascalis
                           
Description             : 
This is a 2-player map set in somewhere near Merapi volcano.

One of the 130 active volcanoes in Indonesia, Merapi is the most active. The name Merapi means "Mountain of Fire". The volcano is considered sacred and every year a priest climbs to the top to make an offering. The mountain high 2968 meters, it is located 25 km north of Yogyakarta.

Then, he erupts again in 26 November 2010.

Some moments after the eruption, the pyroclastic flows from the mountain causing most of the trees near the river were knocked down and the ground was coated by ash and rock. Not only that, volcanic material also flows through the river causing flood to nearby village. The blast also leaving more than 100 people dead and forcing tens of thousands from their homes.

An Oil Derricks and an artillery platform per player locations. AI are enabled with more complex waypoint system. There are more techbuildings available for capture. Some supply for the refugees are available if you explore the map but beware, there are refugees running their car and truck panicly! Take care of your infantry as they can easily crushed by them.


Game Type               : Skirmish
Single Player           : Yes
Multiplayer             : Yes
Known bugs              : None known

Installation
------------
To use the map, look in your "My Documents" for a folder named "Command and Conquer Generals Zero Hour Data/Maps". If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and comeback. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the "/Command and Conquer Generals Zero Hour data/Maps" folder. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section.


Copyright / Permissions
-----------------------
This level is copyrighted by Pascalis Sadewa a.k.a Dawn-Shade 2010
Authors may NOT use this level as a base to build additional levels, unless they have my permission.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!
----------------------
All trademarks and trade names are properties of their respective owners.
