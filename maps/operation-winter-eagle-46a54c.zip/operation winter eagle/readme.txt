*********Operation winter eagle readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        operation winter eagle
Created by:  snowy007
Players:     1 player




installation:
--------------

unzip and put the folder in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

this is a single player mission for skirmish mode. 
the boss general and the demo general are working together. they where able to enter general towns base. he is in great 
danger. you must save him fast and rebuild his base. then your objective will be to destroy the boss generals base.
you can try to capture the demo generals base to make it easier.
this is a very long mission for people who like to be busy.






