
Hello,

Thanks for checking out "Four Corners".

The first map created by Robert Bassham.
rb1drummin@aol.com

This is a rather simple skirmish map yet has some interesting scripting 
to it.  The Local player has defensive-laser bunkers defending their base.  
This involves 18 lasers and the twenty power plants needed to run it which 
are located out of view.  This will hold off your enemy for awhile but don't
count in it.

Each enemy base has twenty tank crates in front of it producing forty tanks each.
The AI uses these tanks mostly for defense.

There is a solder named "Keyman" who can change game play.
Place Keyman in the RED HUT to play without Laser system.
AND/OR place Keyman in BLUE HUT to remove Half the Crates from the map.

There is also a Missile Launcher up for grabs in the center of the map.

Enjoy!