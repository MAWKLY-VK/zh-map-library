You Downloaded a Generals Zero Hour Map:                    Great With MOD: Zero Hour Reborn
           Jungle Typhoon                                               
           by. sgtmyers88
PLEASE DONT EDIT THE MAP WITHOUT MY PERMISSION!


ACCESSING:
extract, copy, and paste the Jungle Typhoon Files to your Generals Zero Hour map data directory.

OVERVIEW: 4 player AI skirmish and multiplayer
Set Somewhere in Laos this little skirmish has 3 players in the valley 
and 1 player on the mountain the three in the valley have lots of room but are gonna clash
intensely later on while the one on the mountain has a defensive bonus but has less room
This map Has jungles, a river, two large rice patties, a big village and plenty of supplies.
ALSO CAME WITH STORM EFFECTS!

questions, comments, suggestions relating to Command & Conquer and/or my maps
contact me via email or instant messenger at sgtmyers88@yahoo.com 

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN! 

PROBLEMS/BUGS: no known issues 

2005 sgtmyers88

OH... HAVE FUN IN THE TYPHOON!
