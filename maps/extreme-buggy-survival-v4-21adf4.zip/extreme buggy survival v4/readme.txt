This file contains credits of map [extreme] buggy survival.
Please leave this file in place as a sing of respect for the authors.

Original author: Xperience of Micro
Website: speed-clan.teamfr.com

Map upgraded by: [RTS]BN+VS* (aka [RTS]ch2.1.6d)
Xfire: bn2vs
Website: www.bn2vs.com (for generals maps: generals.bn2vs.com)
Blog: blog.bn2vs.com
Forums: code.bn2vs.com


=========================================================================
Installation Instructions:
=========================================================================
	You can download the map at
	* http://generals.bn2vs.com/
	* http://www.cnclabs.com/maps/generals/maps.aspx

	Place the '[extreme] buggy survival' folder in your "My Documents/
	Command and Conquer Generals Data/Maps/" and you're ready to go.
	Make sure that within the Maps folder the .map and .tga file are in 
	its own directory which has the exact same name as the .map file.

	Play the map
	-> Put an USA bot on the middle upper spot. only USA bots will work!


=========================================================================
Map Info:
=========================================================================
	Players: 4
	Playable via Multiplayer and Skirmish
        
	Each player starts with 3 GLA buggies and 1 Jermen Kell. Like on 
	Aod maps, waves of enemy units will be spammed onto the map. Your 
	goal is to survive and destroy each wave with your buggies. When
	you lose a buggy, it won't be replaced, so be very careful with 
	them! 

	To set the map difficulty, set the USA both to either normal,
	hard or brutal. Hard will feature a bigger challange the normal,
	and btural will be more difficult then hard.

	Note that bots (as allie) will not play and be inactive. When 
	such a bot is on the map, you also won't lose when all your units
	have been destroyed, like is the case with all human players.

	Some tips:
	* When playing on hard or brutal, air strikes will be spawned onto
	  the map at random intervals - as soon as you see the warning,
	  make sure your buggies are moving (else there is a good chance
	  they will be wiped out by the aurora's).
	* Be very careful not to loose your Jermen. You can use him to
	  snipe infantry (esp on brutal - wave 3), and to snipe other units
	  and then capture them with infantry (ambush or para drop).
	* If you want to take a break, put your units at the top of the map,
	  unless drawing attention, they won't be attacked. Be sure to help
	  your team players out though!
	* Don't forget to upgrade your buggy ammo at your black market!!


=========================================================================
version Info:
=========================================================================
       This is the readme file of
       "[extreme] buggy survival v4 - standard edition"
       Updates and other greath maps can be found at generals.bn2vs.com


=========================================================================
Changelog:
=========================================================================
	Version 4:
	* Rearanged the spawn points
	* Added multiple new waves for brutal
	* Changed several waves to make the map more challanging

	Version 3:
	* Improved hunting scripts
	* Added new version of wave 2 for hard
	* Changed spawn point of airstrikes to provide a longer period to
	  respond to the warning
	* Moved wave 8 hard to wave 8 normal, and added a new hard wave
	* Made minor changes to some other waves
	* Moved the lower left spawnpoints a little to make the unit
	  appearance more realistic
	* Gave each player a buggy with full experience and extra armor
	* Added tips to the readme file

	Version 2:
	* Added different difficulties
		* Hard: Added airstrikes and an extra wave
		* Brutal: Added airstrikes and 2 new waves
	* Added extra features on the map (fences, roads, ect)
	* Added readme file with map info & more
	* Fixed the bugs in the hunting script
	* Fixed the intors + added color
	* Improved map code