UPDATED VERSION - OCTOBER 15, 2004

SCRIPTING PROBLEMS FIXED FROM THE ORIGINAL



                          When Idiots Attack
                             The Mission

This is a mission map for Command & Conquer Generals Zero Hour. This is based on the movie map series i make "When Idiots Attack".They can be found to download in cncden.com. The story is about a man named JK aka Jarmen Kell saving his old buddy,old pal, a guy named Bob. He was captured by American and Chinese forces and its up to JK to save him! It is essential to watch the When Idiots Attack series before you play this mission to make sense. The mission is easy from the beginning but gets harder each stage. Please follow the installation instructions below to play this map. May i also include that you must pay attention to the breifings and radar. Trust me. 
_________________________________________

Installation:

First of all, extract the files contained in this compressed folder.

The Audio folder goes into your C:\Program Files\EA GAMES\Command & Conquer Generals Zero Hour\Data folder (do NOT remove anything from the Audio folder.)

The Music.ini file goes into your C:\Program Files\EA GAMES\Command & Conquer Generals Zero Hour\Data\INI folder.(dont mess with it.)

The folder,When Idiots Attack:The Mission, goes into your Documents\Command and Conquer Generals Zero Hour\Maps Directory.(do NOT remove anything from this folder.)

Every other file in this map, leave as is.

_________________________________________

To people that cant do a thing,
	If you have questions how to beat this or that, email me and i'll tell you. But at least try.

But here are some tips i'm willing to say,
1)pay attention to the radar when it is on.
2)when fighting the 1st boss (yes there are bosses) use your technical to ride around him to get the salvage crates first.
3)Take care of JK and the car!
4)When delivering the 5th pizza (an objective), it wont show a radar informal so go to the junkcars and continue delivering.
5)When you're in the stage to save JK's grandma from the demo traps, use the technical to take out the traps. Be quick too!


The map and all that is scripted is made by yours trully. And the Map.ini is made and provided by Derek.

People might say what i have against hobos. I dont want such commentary, i only put them in my maps to be killed for comedy reasons.


For any questions or comments contact my email:
joeyserrano@dslextreme.com
(Please no hate mail)



-Yuug254


