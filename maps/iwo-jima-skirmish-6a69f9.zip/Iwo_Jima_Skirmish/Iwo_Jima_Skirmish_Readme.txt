  You Downloaded A Generals Zero Hour Map:                        Great with: ZERO HOUR REBORN
             Iwo Jima Skirmish                                                NAVAL WARS
              By. sgtmyers88
  PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!!



To gain access to the island:
	extract, copy, and paste the Iwo Jima Files to your Generals Zero Hour map data Directory.
Good Luck, relive history, and most of all... HAVE FUN!!!

OVERVIEW:
10 fun reasons to play this map... (technically it would be more, but I put some together)

1.)4 players human or AI.
2.)This map is based on my Invasion Of Iwo Jima Mission.
3.)Its been cleaned up and modified for skirmish and/or mutiplayer games. If you havent played the mission and are intrested in trying it, let me know.
4.)Awesome Wave effects and details.
5.)This Map is large and spacey. (almost 600x600 tiles)
6.)Lots of supplies, bunkers, arterilly platforms, and 2 airfields for control points!
7.)Has a Hilly and Jungle terrain all in one.
8.)There is alot of ocean for the NAVAL WARS MOD!
9.)Has Planes and some Ships moving freely!
10.)LOTS OF OTHER MOD POSSIBILITIES!

REMEMBER: Some MODS may not work together and may screw up the map,
mission and/or crash the game.

Problems/BUGS:
"Might" be a problem on slower computers (pentium II or less)
due to my idea to make the island nearly to scale. (ACTUAL SIZE COMPARSION: 1:3 Scale)

NOTICE: 
YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!!
MAP MADE BY: sgtmyers88 July 2005

Requesting: SPECIAL FX MODS and WWII VEHICLE MODS for historical accuracy.

Questions, comments, suggestions, and other info for Command & Conquer and/or my maps
e-mail or instant message me at sgtmyers88@yahoo.com 







 