Credits and thanks to:

Newgate
Adriane
... and anyone else over at the C&C ZH Wordlbuilder discord channel who helped answer my random questions

----------------------------------------
   GAMEPLAY
----------------------------------------

- Like any regular FFA map

----------------------------------------
   MONEY FIELDS
----------------------------------------

- All traditional eco from supplies, oils, and secondary eco (Markets/Hackers/Drop Zones) have been removed and replaced by Money Fields.
- Place ground units on these fields to earn $/sec relative to the number displayed on that money field.
- The value of each money field will be doubled if you control the x2 multiplier in the middle of the map!

----------------------------------------
   DISABLE POINTS
----------------------------------------

- There are disable points located around the map, 2 at the rear of each base and 1 in between each player overlooking the middle.
- Ground units placed on these points will disable the Money Field(s) that they are connected to (Highlighted by roads).
- These points will disable both the Money Field income AND Wizard summoning abilities.
- The in-between-player Money Fields are the only ones on the map that cannot be disabled.

----------------------------------------
   MONEY FIELD WIZARDS
----------------------------------------

- Money Field Wizards will be summoned on money fields that you occupy. 
- These infantry units effectively replace secondary economy - They will earn you $10/second (Equivalent of two vet 3 hackers).
- The Wizards behave like hackers even when moving and will make money as long as they are alive.
- The higher combined value of units on the Money Fields the faster the Wizards will be summoned. Every $1000 of units on the field increases the summoning speed (Capped at $9000+).

----------------------------------------
   TECHNICAL NOTES AND FUNCTIONALITY
----------------------------------------

- Buildings cannot be built on Money Fields.
- Ground units inside chinooks are still treated as ground units to activate money fields.
- Mines cannot be dropped on Money Fields.
- There is a sneaky entrance around the back of each base for combat bikes to use.
- Wizards are like walking internet centers with a vet 3 hacker preloaded into them.
- The Wizard count is capped at 200 at which point they will stop spawning. If exisitng Wizards die they will begin spawning again.
- Every player has an "Interest" counter for each Money Field. This increases by 1-10 per second based on combined unit value on the Money Field. Once the Interest reaches 450, a Wizard will spawn. This means at the highest rate of 10 Interest per second you can summon a Wizard at most every 45 seconds. Your counters will continue where they left off if you lose control of a Money Field.
- Because each player has their own Interest counter per Money Field, a shared field can summon Wizards for different players concurrently.

----------------------------------------
   MAPPER NOTES
----------------------------------------

- Money Fields use the AsianFarmer objects to apply the fog effects. Damage is applied to change the effect for the middle multiplier.
- Objects are sunk into the ground to prevent buildings being placed on Money Fields.
- Due to scripting limitations the Wizard scripts are extremely bloated. Editing the map is painful unless you remove the scripts first. 