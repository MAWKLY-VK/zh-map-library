Genome D-Day
==============
Attempted remake of normandy invasion -----> I know it sucks.
Bombardment at beaches, lots of money and buildspace, some nuke trucks
and a train running around. Artillery and bunkers are hard to kill, oil
cant die.
==============
<C> to me
