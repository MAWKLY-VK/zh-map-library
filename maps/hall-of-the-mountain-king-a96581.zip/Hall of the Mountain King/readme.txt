
www.wilsonswebdesign.com

Map Name: Hall of the Mountain King
Map Author: Matt Wilson
Author's E-Mail Address: mattw379@yahoo.com
Released: July 02, 2003
Map size: 350 x 350
Players: 4
Skirmish Compatible: Yes

Map Description: This is a simple straight forward map.
Great for some heavy multiplayer battles and the AHAI
makes for a nasty skirmish.

Extra Comments: This map is great for online and skirmish.
This map incorporates the Almost Human AI By RVMECH.

Directions for Installing: To install this map simply extract the contents of the downloaded .zip file to your \My Documents\Command and Conquer Generals Data\Maps\MAPNAME folder on your hard drive. The MAPNAME will of course be the name of this map.