                      ========================
 		      = The moment of truth  =
		      ========================
		      = Map made by Kingnino =
		      ========================

Release date: sunday, June 28, 2009


Map info
--------

Size: 		300x300
Maker: 		Kingnino
Type:		AoD (Art of Defence)
Players:	4 human and 1 GLA cpu

How to istall?
--------------

  You will have to drag the map to C:\Documents and Settings\Administrator\
  My documents\Command & Conquer Generals Zero Hour Data\maps. now you will 
  have to run the game to to maps and click on unofficial maps. there you 
  will have to find it.

How to uninstall?
-----------------
  
  You just delete the folder ''---AoD--- The Moment of Truth (by Kingnino)''
  in C:\Documents and Settings\Administrator\My documents\Command & Conquer 
  Generals Zero Hour Data\maps

How to play?
------------

  The host must choose a GLA computer player and place him the top position 
  of the map. Four human player try to stop the gla. If you don't or can't 
  stop the gla you will lose.

Can i use it for Generals?
--------------------------

  You can't use it for generals because, it's made with the zero hour 
  worldbuilder.


Contact
-------

  Email: questionshere@hotmail.com

  Youtube account: www.youtube.com/chill876




