You Downloaded A Generals Zero Hour Map:                          No Mod Problems yet
         Battlefront (desert)
           By. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!


To Gain Access:
extract, copy, and paste the Battlefront (desert) files to the Command & Conquer Generals Zero Hour map data Directory

OVERVIEW: 
2 players AI or multiplayer
I have played many times in the multiplayer system and mastered many single player maps and missions
and have become a good artistic map maker I also have taught some people new to multiplayer 
so i decided to make a couple of multiplayer practice maps.
Two areas of high ground for the bases and a trench warfare kind of valley. 
A small but simple map designed for beginning players to practice strategy in multiplayer.



Problems/BUGS: none detected yet

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!!

place a question, or comment via email or instant messenger to sgtmyers88@yahoo.com

PRACTICE WELL AND HAVE FUN!!!


2005 sgtmyers88
