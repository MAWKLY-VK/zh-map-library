:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Triple Threat"
[File Name]    = 004-Triple_Threat.map
[File Size]    = 76 KB
[Map Size]     = 267 X 279
[Players]      = 3-4 only
[Time Setting] = Afternoon
[Field Intel]  = Urban
[Resources]    = High
-----------------------------------------------------------------


--< NOTICE >-----------------------------------------------------
Keep in mind that this map is designed for a three-on-one 
battle.  Therefore, it is advised that this map should only be 
played with 4 players.
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Ukrayina Commander Kherson
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

General, we are glad to hear from you.  We heard that Commander
Flippster sent you to check on things here.  Actually, you 
happened to come at the right time!  There's no time to lose; 
time is of the essence!

You know the situation of the recent violent situation in 
Zaporizhzhya, Ukraine and the setup of the new Ministry of 
Defense HQ at the Military Consulate, which is the site of the
former fortress of Aleksandrovsk.  Unforunately, the violence has 
gone too far. Rebels have managed to join forces and set up bases 
near the Consulate.  The compound has little defense, for it has 
only existed for a year.

We need your help in defending the compound at all costs.  This
will be the hardest job of the Alliance yet, for we have detected
three insurgent bases.  The U.S., partly forseeing the effort of
establishing the compound, has lent their technology to the
Austrians for assistance.  Use these tools to help defend the
Consulate.

General, the fate of the Austrian government and the country lies
in your hands.  Good luck.

  //--[ Ukrayina Alliance HQ    ]--\\
 |A|--[ Kiev, Ukraine           ]--|A|
  \\--[ ** European Division ** ]--//

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Superweapons are banned in this area by order of the U.N.
:: The Consulate has only one way to get in and out.  Build and
   concentrate your defenses on that area.
:: The Consulate has already some U.S. and tech civilian
   buildings inside.  Capture them all ASAP.
:: The castle's walls cannot be occupied by troops, nor can they
   be destroyed.
:: There are other tech structures within the city limits.  Be 
   advised that the insurgents could get hold of them first and 
   defend it well.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@mail.com
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================