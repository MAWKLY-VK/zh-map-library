Mission Name: BLACK HAWK DOWN
Game: C&C Generals Zero Hour
Author: Murdock modified for Zero Hour by Starduster
Map Size 250 x 250


Info: SinglePlayer mission. Use the rangers to rescue the hostaged pilot. Destroy the toxin depots in the northeast of Mogadishu with Thunderbolts. If you have reached the inner city with your troups the market will be attacked by B52 bombers.
The pakistanian allies will attack if your rangers try to infiltrate the city from the northwest.

Take care of traps everywhere in the streets. Lots of houses are garrisoned by Aidids militia. 

Be careful with your Comanches, you can't build them. You also can't build Tomahawks and an uplink cannon.  

To reach your goal is rather difficult but not impossible.

If you don't have a high performance comp reduce graphic details.  