Map Name: Death's Summit
Author: Halkeye/Hawkeye 
My email: jfowl007@yahoo.com.au 
Number of players: 5


PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!
YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!


Map Description:

This map has a mountain in the middle with a plateau. One player on each corner
and one in the middle. There is eight tec oilderrics surounding the mountain and
a tec renforcement pad on the East and West sides. Watch out for the train because
unit could get run over.

Directions for Installing:

Extract to My Documents\Command and Conquer Generals Zero Hour Data\Maps
