EXTRACT THE FILE TO:
My Documents/C&C Generals ZH/Maps
Create by romie88
Copyright� Reserve 2004
Thank You and Enjoy your defeat.