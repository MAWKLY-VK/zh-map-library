Name:Lake side destruction
Author: timmy029
File Size: 191kb 
Map Description: This map is a dTemperate map with a Lake in the middle aand 2 mountains packed with supplys and a few oil derricks up for grabs
a few oil derricks and 2 oil refinerys
The map also has waves so remember to keep the .WAK file in the folder.

Directions for playing: To use the map, look in your computer for a folder named C:/My Document/Command and Conquer Generals data/Maps. If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and comeback. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the C:/My Document/Command and Conquer Generals data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section. You can use the map for online play or skirmish against the computer (AI). Works great both ways. If you use it for skirmish play, use hard or brutal army for the AI difficulty level.


Author's Email: timmy_029@yahoo.co.uk

This map uses RVMECHs almost human AI so id like to thank him 