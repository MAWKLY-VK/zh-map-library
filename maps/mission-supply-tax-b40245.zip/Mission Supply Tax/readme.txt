Mission Supply Tax by beng

This is a single player mission for Zero Hour

It was made to demonstrate how to make a supply stash steal cash from the enemy.

Once you upgrade with supply lines upgrade, your supply stash can either hack cash or "tax" the enemy supply centre.

Jarmen kell has 3 weapons: a long range sniper rifle, a vehicle sniper rifle, and an anti-material rifle that is good against base defences and aircraft. However, he will unstealth when firing the anti material rifle. He also has powerful TNT.

The avenger can shoot down enemy arty shells.

There are some other changes, you will see them when you play.

I advise you to buy the scud launcher science and build a couple of those vehicles as you will need them.

The AP rockets upgrade makes trhe scud missiles tougher.

To win, just destroy the enemy.

