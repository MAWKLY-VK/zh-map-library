Con Yard MCV mission for Zero Hour
===================================
by beng

Needs Zero Hour version 1.04
This map may not work if you have other versions of ZH or have
mods installed.

Installation:
Put the directory in 
I:\My Documents\Command and Conquer Generals Zero Hour Data\Maps\
The map will then appear listed in your skirmish maps (user maps section).

This mission reproduces early CnC games con yard and MCV behaviour so
you can see what it is like playing Generals with the old way of building.

You start off with an MCV which you must drive to a suitable base location
and deploy into a construction yard.

You can also undeploy the con yard back into a mobile construction vehicle.

The con yard can build buildings and more MCVs (these are also good as
armoured combat vehicles, armed with toxin guns). Their guns are upgraded
by veterancy.

There will be 2 pink circles around your con yard to show you the radius
within which you can build. The con yard can build most buildings within
the inner circle (the centre of the building must be in the circle).

Inside the outer circle the con yard can build base defence buildings:
tunnel networks, stinger sites, and demo traps. These buildings will
build by themselves so once you have placed them you can stop the con
yard from trying to build them and have it build something else.

If you build a base defence building outside the outer circle, it will
self destruct and refund you the money.

To repair damaged buildings inside the inner circle, just select the
con yard and click on them, it will repair them like the dozer.

To repair damaged buildings (or units) inside the outer circle, select the
con yard and force fire (Ctril + click) on them, it will repair them
using a healing weapon. If 2 con yards force fire on the same object it
will of course heal faster. You can also use the healing weapon inside
the inner circle to repair buildings but the dozer repair method is faster.

Use the con yard repair weapon to also heal friendly units that are
fighting on your base perimeter and get damaged. This can help hold off an
enemy attack.


Acknowledgements:
------------------

I learnt of the status weapon method of constructon (used here for base defence
buildings in the outer circle) from Slye_Fox:
http://forums.revora.net/index.php?s=&showtopic=38935&view=findpost&p=608111

Basically with the status weapon method the con yard sends out a pulse of
status damage and structures it builds have a lifetime update. If they
die with the status given by the con yard status weapon, they OCL a real
structure. Else they OCL cash refund crates.
