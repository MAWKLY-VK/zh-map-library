MAP ::  Close Quarters

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1 or 2vs2

STYLE :: SYMETRICAL [THUNDERSTORM][NIGHT]

AI :: SDI TEAM [AGGRESSION UPDATE]

ONLINE READY ::  YES

INFO :: 

* Heavy Thunderstorms roll into this Small Valley.
* The Storm has GROUNDED all Fighter & Bombers.
* AirFields are NOT permitted by the Script.
* 2 Hidden ARMORED Nuke Trucks.
* Certain Buildings are much stronger then normal.
* $$$ Crates and Hidden Crusader Crates can help u win.
* Thunder & Lightning by ThomasAlan @ cncmaps.
* Beta Tested July 2006.

MORE MAPS AT WWW.FASTGUILD.COM

This Map is SHOCKWAVE READY !!!