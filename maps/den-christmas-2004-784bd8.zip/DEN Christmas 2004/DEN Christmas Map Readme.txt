You downloaded this map from CNCDEN - http://www.cncden.com
email: dalion@comcast.net

CNCDEN covers everything in the Command & Conquer Universe of Games.

This map is for the game Command & Conquer: Generals Zero Hour

Map Name: DEN Christmas Map 2004
Map Author: Lion (Webmaster - Den Games Network)
Released: December 20, 2004
Map size: 300x300
Players: 2-4

Map Description: This is a 4-player team based multi-level Snow map. Plenty of room to expand your base, and an adequate supply of cash to keep your army on the go. Each player starts with two supply docks.More money on the battlefield to fight over. A variety of tech structures and some goodie crates available (money and tank crates). Lots of strategic possibilities with back entrances to the enemy. A few buildings on the battlefield to garrison. Enjoy!

Directions for playing: To use the map, look in your computer for a folder named C:/My Document/Command and Conquer Generals Zero Hour data/Maps. If this directory doesn't exist, play a skirmish map and comeback. The folder should be there now. Extract the COMPLETE FOLDER included in the map zip file in the C:/My Document/Command and Conquer Generals Zero Hour data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section. You can use the map for online play or skirmish against the computer. Works great both ways! Enjoy the map...


This map was made by Lion, webmaster of the DEN Games Network. The map is exclusive to CNCDEN and is copyrighted 2004. I made the map and have the right to say where it gets downloaded from. You may use it for personal use. Please do NOT modify the map and call it your own. I spent many hours creating the map.

Long live the memory of Westwood Studios...