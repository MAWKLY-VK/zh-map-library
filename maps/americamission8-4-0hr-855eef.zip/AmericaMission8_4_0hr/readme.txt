America Mission 8 for Zero Hour (Operation Last Call) v 1.0
===========================================================

General Alexander, intel reports that the GLA have stolen equipment from the Khazakstan state circus, and also agricultural aircraft from cotton farms near the Aral sea. They also raided the nuclear Chinese base to the south, and stole a consignment of Overlord gattling cannons before the Chinese could mount them on their tanks. We do not know what they have done with this equipment. It is up to you to defeat the GLA in this region and demonstrate that America is the only superpower in the world.

This is a modified version of EA's America Mission 8 from the original Generals America campaign modified for Zero Hour by beng. Feel free to use the map.ini stuff for your own maps.

You start with a Superweapon General base, with a Nuke General base to the south which you can requisition.

There are some new unit types on all sides.

Installation:
-------------
Unzip and put the folder named "AmericaMission8_4_0hr" in your map folder, usually:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

Start Zero Hour, go to Skirmish, Select Map, Unofficial Maps, and load the map AmericaMission8_4_0hr.

Bugs:
-----
Game may crash when you que up more than one burton or lotus unit together.

New Units:
----------

Units from China Mission 7 for Zero Hour:
-----------------------------------------
You get a Super Lotus who can climb cliffs and kill enemy infantry with her lotus fist kung fu. She can also kill stinger site crew though she will get damaged in the process.

NEW:
****
Super Lotus can now call in a napalm air strike every 3 minutes. If all 8 planes make it to the target, this should make a firestorm. The planes start from the closest edge of the map to Lotus.

You also get a new hero type, the Chinese Secret Agent. He speaks with an American accent because he is trained by the School of the Americas in counter-terrorist bomb making techniques. He can build 2 types of bombs:

1. The INEMPD (Improvised Nuclear EMP Device) explodes a tactical nuclear bomb similar to the helix nuclear bomb in yield. The blast pumps a high power microwave (HPM) pulse generator which immobilises nearby vehicles, forcing them to stay in the radiation field from the blast. It also disables nearby buildings for 30 seconds. This bomb defaults to manual mode, but can be switched to proximity detonation.

2. The Neutron Booby Trap is a bounding mine that explodes with neutron effects, killing all nearby infantry including the drivers of vehicles and infantry in garrisoned buildings. It defaults to manual mode too. Immobilised vehicles can block those narrow city streats and create traffic jams.

3. The secreat agent can also attach improved TNT charges to vehicles and structures like the tank hunter. Whilst less powerful than Col Burton's C4 charges, these can usually incapacitate a base defence with one blast, and is useful for finishing off GLA building holes left by nuclear missile strikes.

The agent can also defuse enemy demo traps and mines using his made in china tools, and climb cliffs.

The Nuke General's Mig has been given better weapons. The default EA Games version has Nuke_MiGMissileWeapon (damage=100) to start with and gets Nuke_NukeMissileWeapon (damage=150) when the tactical nuclear Mig upgrade is purchased. The version in this map gets Nuke_NukeMissileWeapon to start with, and is upgradaded to NukeMissileWeapon (damage=300).

Migs also get a command button that lets you fire just one missile, useful for engaging two targets on 1 sortie.

American UAV spy drones can be selected and moved around.


New/changed Units for this map:
-------------------------------

Pathfinders and Jarmen Kell are more evenly matched. Those who are waiting in ambush have an advantage over movers.
Jarmen now stands a good chance in counter-sniper actions.
Jarmen ranges:      weapons: 225, sight: 250, stealth detection: 250
Pathfinder ranges:  weapon:  300, sight: 300, stealth detection: 225
American Sentry Drone                         stealth detection: 225
Chinese Radar Outpost                         stealth detection: 300

Avengers shoot down tank shells and Scudstorm missiles in addition to the usual missiles and planes.

Aurora bomber starts with an improved tactical nuke bomb with better standoff capabilities and flight profile.

When laser guided missiles upgrade is purchased, Aurora bomber gets high brisance tactical nuclear air launched cruise missile with greater yield.

Stealth fighter gets a button to fire only 1 shot so it can clear 2 buildings in 1 sortie. It also has improved smart missiles with a flight profile optimised for fighting in built up areas and greater standoff range.

C-130 cargo plane has been upgraded to AC-130 standard. It carries gattling guns and a howitzer and has a self-defence laser.

A new unit, the portable laser cannon / laser drone can be built at your Superweapon General war factory. The drone has a laser tank gun but can be converted into a laser cannon building. This building can then be converted back into a drone and moved somewhere else. If you manage to get a chinook exactly above it, the laser cannon building can also be loaded into the helicopter. The laser building can shoot down ballistic missiles. Make sure you have sufficient power stations before building more drones/lasers.

The paradrop general's power now drops these laser drones instead of rangers. It drops 1, 2 or 3 drones depending on the level of special power purchased.

Superweapons are limited to one of each kind.

Airfields are limited to one of each kind.
