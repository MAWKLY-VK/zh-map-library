Map name: STORM-CATCHER (Vers. 1.9)
size: 300x400
Players: Single Player Mission
Weather: Temperate
Time of day: Morning
Author: Judds
Scripting: Starduster
Email: Judds@cncmaps.tk
Created Soley for www.cncmaps.com all rights reserved. �

 To install this mission follow the simple instructions below:

1.Unzip the file 
2.Highlight and right click on the Storm-Catcher folder
3.Select copy
4.Open my documents
5.Open the folder called "Command and Conquer Generals Zero Hour Data"
6.Then open the dolder "Maps"
7.Finally paste the file into here.
8.Close all windows and go load up the game and enjoy getting a kicking in the mission.

 Story:

 General, The Chinese have had word that the GLA have built a Biochemical Facility and have got 3 Scud Storm Launchers, They are primed and ready to fire at the USA civilians.

China have taken this facility by force and have de-activated all scuds from the launching countdown. 

Latest update:

General, there has been a mutiny within the chinese ranks and the chinese army as we know it has been taken over, Some of the Chinese Generals have allied with the GLA and formed a new organisation, they call themselves the China Liberation Army (CLA). They have killed all soldiers who refused to join them and have re-activated all Scud Launchers. General America is in grave danger and must be protected against these threats.
USA Officials have ralieghed up a Delta Force team and have got them on route as we speak. You will be dropped into the immediate area and have your team rebuild the old USA base that has been neglected, You will have 60 minutes General to stop this threat and destroy all 3 Scud Launchers. The CLA is supprisengly strong and has grown to become a real threat, they have a large arsenal of weapons and Technology along with the GLA these Terrorists are going to try there best to out whit you. Be prepared General for early attacks.

Be strong, show no mercy, God Bless America.  Good Luck!!!

   *******************************************************************************************************
                                                                           Credits

I would like to thanks Starduster, of www.cncmaps.com for all of his help and support throughout the creation of this mission. With his expertese he brought my idea to reality. You will witness some really excellent battle tactics with the AI scripting that he developed whilst helping me create this mission.

Starduster you have been a real good friend to me over the past weeks, and i would like you to know how much i appreciated your work in evolving this misssion. Thanks bud i owe you a lot.

  *******************************************************************************************************

Email :  Judds@cncmaps.tk

Thanks, Judds. 