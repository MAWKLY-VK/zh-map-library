.------------------------------.------------------------------
| Map Name:                   / ***Infantry Fighting Arena***
|----------------------------/--------------------------------
| Version:                  / *** Version 1.0 ***
|--------------------------/----------------------------------
| Aurthor(s):             / *** By Server557 and Alertren ***
|------------------------/------------------------------------
| Contact Details:      / Contact Us Via Email:
|                      /--------------------------------------
|                     / Server557: server557@gmail.com
|                    /----------------------------------------
|                   / Alertren: renagade1221@hotmail.com
|------------------/------------------------------------------
|                 /
|                / Thankyou for taking on this multi-player
|               / assignment, General. Before you proceed,
|              / you must know, that you will be commanding
|             / the basics of all units. This includes 
|            / infantry and dozers. You will also be limited
|           / to basic structures. These are Power Plant's,
|          / Barracks' and Supply Centre's.
|         /
|        / You will be breifed in-game for more information
|       / on your current assignment.
|      /
|     / Good Luck General, Mission Commission Signing Off
|    /
|   /
|  /
| /
|/

Other Notes:

You have permission to use the scripts contained within this
map for your own personal use, providing you give us credit
for making them.

You have permission to freely distribute this map providing
this ReadMe file and all copyright notes stay intact.

You do NOT have permission to change the content of this map
or any scripts contained within it without our permission
first.

You have no permission to change the string's file contained
within this map without our permission.

You may contact us at our email address' if you require any
help or need any clarification.

Contact Server557:      Server557@gmail.com
Contact Alertren:       Renegade1221@hotmail.com

Reguards,

Server557 and Alertren