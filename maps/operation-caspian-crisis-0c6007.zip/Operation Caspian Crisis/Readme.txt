
================================
Operation: Caspian Crisis

COmmand & Conquer: Zero Hour
================================

Created by WaTeR_BoY 2005
atlas_kwei@hotmail.com

________________________________

Many thanks for downloading this map

Installation: 
Unzip the contents of this folder and extract the files to: 
My Documents/Command and Conquer generals zero hour data/maps

Requirements:
This map is for Zero Hour only and will not work in the original Generals.

_________________________________

Map size	: Large 
Players		: 2
AI supported	: YES

Map Description:

This is a SKIRMISH and MULTIPLAYER map despite its title. It is a 'role playing' map, complete with a background storyline which carries on from the final mission (China mission 5) of zero hour. In brief, it is about a biochemical attack on a nuclear power facility in Azerbaijan in an attempt by the GLA to capture nuclear warheads from Russia scheduled for reprocessing (for more details, read storyline.txt). 

This map is set in a vast oilfield in Azerbaijan, which includes a large petroleum processing facility and a nuclear reactor complex. As you might have guessed, there's an extensive network of offshore oil derricks just waiting to be captured. So, cash will not be a problem provided you guard them well. Also, nuke trucks are available for capture ... giving you new ways to annihilate your foes (some of my favourites ... suicide chinooks and kamikaze helix). 

This is my very first map but I took every effort (and many late nights ..) to ensure that it is up to the standard. I have included a great amount of detail in the map to make it as realistic as possible. Hope you'll enjoy playing it as much as I had making it.

Note:

I have included a mission briefing at the start of the game. You may choose to ignore it .. it's just for 'drama'=) . The objective is the same as for any skirmish map ... wipe out your enemy.

Recommendations:

The map is designed specifically for the human player being on the USA side and the AI on the GLA side (preferably toxin or demo general), in accordance with the storyline  (but that of course is up to you). For the best gameplay, go against GLA demolition general advanced AI mod hard difficulty (they'll drive you nuts .. ). Advanced AI mod can be downloaded from www.cncgeneralsworld.com/page.asp?page=advancedaimod

________________________________

Special features:

i) 	Includes a short intro movie (which will give you a rough idea of the storyline).
ii)	Nuke trucks available.
iii) 	One battleship available for capture (but using it comes with a 'price' as you shall see).
iv)	All oil and gas tanks WILL EXPLODE and BURN once destroyed. 
v)	Destroying the nuclear reactor or any coolant station will trigger a nuclear meltdown. (meaning a very BIG nuclear explosion .... think Chernobly .. 1986)
vi)	Permanent biochemical contamination in certain areas. Poison field will persist throughout the game.
vii) 	Supply docks nearest to start locations have been reset to contain 70000 cash.
viii) 	A surprise special effect! try blowing up the oil tanks at the offshore dock.

________________________________

Known issues (nothing major - will not cause error during gameplay):

i) 	Permanent poison fields will turn 'invisible' during the course of the game for some inexplicable reasons. Meaning it is still there (infantries will still die) but you just can't see them clearly.
ii)	Some oil derricks appear submerged in the intro movie.
iii) 	If you're playing against AI players, they WON'T capture nuke trucks or battleships, contrary to the 'mission briefing' in the beginning. The funny thing is AI players actually did capture nuke trucks in the initial version of the map, but that doesn't happen anymore for some unknown reason.
iv) 	AI players will have a headstart due to the intro move (I have no idea how to pause AI players temporarily, just haven't found a script that will do just that) ...... which makes the gameplay all the more interesting, doesn't it?

Apart from that, have lotsa explosive fun!

_______________________________

Special thanks to:
 CNC Den ... for providing the many good quality maps from which I have learnt a great deal.
 C&C Generals WORLD forum .... for their answers to my mapping querries. 

This is my first map. I would appreciate any feedback, help regarding the above 'issues', or report on any bugs occuring during gameplay.

email: atlas_kwei@hotmail.com

_______________________________

3 December 2005.
Copyright of WaTeR_BoY. All rights reserved.


