You downloaded this map from CNCDEN - http://www.cncden.com

email: dalion@comcast.net

CNCDEN covers everything in the Command & Conquer Universe of Games.

This map is for the game Command & Conquer: Generals Zero Hour Expansion

Map Name: Lion Island ZH
Map Author: Lion (Webmaster - Den Games Network)
Released: November 6, 2004
Map size: 300x300
Usage: Online or Skirmish mode against the computer
Players: 3

Map Description: This is a 3-player map taking place in the morning on an island. Sand dunes, small mountains, bridges, and water make up the landscape. Plenty of room to expand your base, and lots of cash to keep your army on the go. Easily defendable base locations. Defensive structures and buildings scattered around the map. Oil Derricks available for capture. Some goodie crates scattered around the map. Use this map for online play or skirmish against the AI.

Directions for playing: To use the map, look in your computer for a folder named C:/My Document/Command and Conquer Generals Zero Hour data/Maps. If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and comeback. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the C:/My Document/Command and Conquer Generals Zero Hour data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section.


This map was made by Lion, webmaster of the DEN Games Network. The map is exclusive to CNCDEN and is copyrighted 2004. You may use it for personal use on your computer or trade it online with your friends.