MAP ::  Blockade (4)

AUTHOR :: WACKWARDS

PLAYERS :: 2vs2, limited FFA

STYLE :: Abstract [NIGHT][SNOWING]

AI :: SDI TEAM [AGGRESSION MOD]

ONLINE READY :: YES

INFO :: 

* A small snow map with Amphibious Craft and PT Boats.
* All Building have more HP's.
* Bridges are indestructible.
* Artillery is placed in critical positions.
* Crusader Crates are all hidden in city...Center is KEY to victory.

WWW.FASTGUILD.COM for more info.