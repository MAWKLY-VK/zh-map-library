Credits and thanks to:

Newgate
Adriane
kABUSE
... and anyone else over at the C&C ZH Wordlbuilder discord channel who helped answer my random questions

----------------------------------------
   GAMEPLAY
----------------------------------------

- Like any regular FFA map

----------------------------------------
   MONEY FIELDS
----------------------------------------

- All traditional eco from supplies, oils, and secondary eco (Markets/Hackers/Drop Zones) have been removed and replaced by Money Fields.
- Place ground units on these fields to earn $/sec relative to the number displayed on that money field.
- The value of each money field will be doubled if you control the x2 multiplier in the middle of the map!
- Your teammate shares and field you own.
- There is a key in the center of the map that actively shows the ownership of each money field.

----------------------------------------
   TECHNICAL NOTES AND FUNCTIONALITY
----------------------------------------

- Buildings cannot be built on Money Fields.
- Ground units inside chinooks are still treated as ground units to activate money fields.
- Mines cannot be dropped on Money Fields.
- Various money-related upgrades have been removed. 

----------------------------------------
   MAPPER NOTES
----------------------------------------

- Money Fields use 4 different infantry objects, one for each color. Damage is applied to change the effect for each fog style.
- Objects are sunk into the ground to prevent buildings being placed on Money Fields.
