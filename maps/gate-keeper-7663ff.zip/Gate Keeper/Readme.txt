Map Name: Gate Keeper v1.1
Map Author: RABIES 
Email Address: RABIES@satx.rr.com
Released: 11/21/03
Players: 4
Compatability: Zero Hour Only

Description: This map is another one of my 4 player maps. It features large stepping hills in the middle wit rivers running on them, draied by pipes into another river. Then eventually into two separate rivers. Gate keeper will make you think, you might think you have the upper hand, then you find yourself in a pickle. Hope you all enjoy the lights I included...

Updates for v1.1:
-Lightning
-Slight Snow
-Towers are gone/replaced with turrets
-Tech is no longer immortal

Installation: You should be OK by just unzipping it into your maps folder under My Documents--->Command and Conquer Generals Zero Hour Data--->Maps.

If it does not create a separate folder called "Gate Keeper" then make one!
