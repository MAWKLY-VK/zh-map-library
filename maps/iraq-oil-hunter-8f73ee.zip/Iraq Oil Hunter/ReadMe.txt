| Downloaded from http://downloads.cncnz.com | Visit http://www.cncnz.com for more |
--------------------------------------------------------------------------------------

Map Name: Iraq Oil Hunter				
Map Author: David Grassi (ViperG)
Author's E-Mail Address: viperg@pacbell.net		
Released: 4/16/03	
Map size: 350v350	
Players: 4
Skirmish Compatible: yes

Map Description: Simple territoial FAST mutliplayer/skirmish map that allows you to capture iraq oil rigs scattered throughout the map. There is hardly any terrain defense, so It's up to you to protect your base and oil rigs. The success to winning is being able to hold the most oil rigs. The oil rigs are not destroyable, allowing infinite resources.
Can support up to 4 players and/or AI controlled players which uses the Almost Human AI written by RVMECH.

Extra Comments: 
This is my first map :)
Uses RVMECH AI script "Almost Human"
Bug: The ai will try to attack the oil rigs. This should be fixed in the next ai update.

Directions for Installing: To install this map simply extract the contents of the downloaded .zip file to your \My Documents\Command and Conquer Generals Data\Maps\MAPNAME folder on your hard drive. The MAPNAME will of course be the name of this map.
