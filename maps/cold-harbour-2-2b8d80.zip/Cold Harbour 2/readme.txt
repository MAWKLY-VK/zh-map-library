
Map Name: Cold Harbour 2 for Zero Hour ONLY!!
Map Author: m00kboy
Author's E-Mail Address: group6@mweb.co.za
Released: September 29, 2003
Map size: 300 x 200
Players: 6
Skirmish Compatible: Yes

Map Description: Cold Harbour where there is no warm welcome.

Extra Comments: The best and more fun is to play against Brutal Skirmish, while there is no Superweapons available. Good challenge u know ;-)

Directions for Installing: To install this map simply extract the contents of the downloaded .zip file to your \My Documents\Command and Conquer Generals Data\Maps\MAPNAME folder on your hard drive. The MAPNAME will of course be the name of this map.
