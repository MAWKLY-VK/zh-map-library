*********Extreme War readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        Extreme War
Created by:  snowy007
Players:     4 players




installation:
--------------

unzip and put the folder in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

This is a 4 player skirmish map. Each player has 1 suply dock, 1 oil derrick, 1 artillery platform, and 3 unmanned
base defenses(2 EMP patroit systems and 1 Infantry General bunker). There are also 5 unmanned sentry drones in each base.
-There is a train running trough the map that can be garrisond. 
-There are 4 unmanned boss dozers on the field.
-The oil derrick now gives $5.000 when captured and $3.000 every 30 seconds. Thanks to the ini file made by: 'Me Myself & Pi'
-The artillery platform now shoots with spectra gunship cannons. Thanks to the ini file made by: 'thomasalan'
-The sentry drones now use dragon tank flame weapon and inferno cannon weapon. Thanks to the ini file made by: 'DestroyeR'







