COMMAND & CONQUER Maps

=======================================================================
Zero Hour
Map Name: Tournament Island 2
Author: [Goo]fert
Description: 
This is a simple 6 player map with 2 oil derrick for each player

and a paradrop pad and a oil raffinery in the center

its the same map as the original tournament island but for 6 plyr

no script added so it for multiplay only and zero hour only

**********************************************************************
INSTALLATION
Place contents of this folder in: "\Command and Conquer Generals Zero Hour Data\Maps"
**********************************************************************
=======================================================================
