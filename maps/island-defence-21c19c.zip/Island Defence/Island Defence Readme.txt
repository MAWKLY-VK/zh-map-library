You Downloaded a Generals Zero Hour Map:                    Great With MOD: Zero Hour Reborn
           Island Defence                                      OK with MOD: NAVAL WARS
           by. sgtmyers88
PLEASE DONT EDIT THE MAP WITHOUT MY PERMISSION!


ACCESSING:
extract, copy, and paste the Island Defence Files to your Generals Zero Hour map data directory.

OVERVIEW: 4 player AI skirmish and multiplayer south pacific island map is complete with 
jungles, villages, oceans, and plenty of supplies.
The beaches are normal except in the Southwest Corner where there are cliffs.
Its your island... now defend it!

questions, comments, suggestions relating to Command & Conquer and/or my maps
contact me via email or instant messenger at sgtmyers88@yahoo.com 

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN! 

PROBLEMS/BUGS: no known issues 

2005 sgtmyers88

ENJOY!
