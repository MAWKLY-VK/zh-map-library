MAP ::  Drydocks

AUTHOR :: WACKWARDS

PLAYERS :: 2vs2 TEAMS

STYLE :: SYMETRICAL [MORNING]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* Custom Color Water added.
* Battleship is very deadly.
* Carrier is capturable if TEAMWORK is used carefully.
* This map is all about attrition and capturing TECH bldgs.