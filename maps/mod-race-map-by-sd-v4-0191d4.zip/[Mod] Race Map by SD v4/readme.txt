
|---------------------------------------------------------------------------------|
|                                                                                 |
|                             Race Map by SD v 3.2                                |
|                                                                                 |
|---------------------------------------------------------------------------------|

This is my 3th Race Map for CnC Generals Zero hour. This map is fully scripted 
with a lot of stuff.

The way my versions will go:
Version 1.0: New map.
Version 1.1: Added new stuff or fixed bugs from the v 1.0 map.
Version 1.2: Added new stuff or fixed bugs from the v 1.0 and v 1.1 map.
Version 2.0: New map.
etc.

|---------------------------------------------------------------------------------|
|                                 Version changes:                                |
|---------------------------------------------------------------------------------|

Version 3.2 Changes:
- Removed the Helix special random power-up, it caused a game crash when more than
4 players where playing the map due too many 'players' in the game.
- Decreased random power-up timer from 175-250 secs to 100-175 secs.
- Increased random power-up timer 'Indestructeble' from 20 secs to 30 secs.
- Increased random power-up timer 'Stealthed' from 45 secs to 60 secs
- Fixed HP of Terrorists on Medium Track part.
- All players get the Junk Repair upgrade.

Version 3.1 Changes:
- Added in a random special ability bonus for your tech.
- Changed the lap counter lay-out (player 1 on top and player 8 on bottom instead
of the other way around).
- Changed the MOAB and Carpet/EMP bomb area hittings. Now they won't appear if
someone else is in that area.
- Changed the Scud Storm into Demo Scud Storm to remove the anthrax.
- Changed the locations of the 2 TH in front of the last Checkpoint.
- Changed the location of the Technical respawn of the last Checkpoint.
- Changed the Battleships (the ones near the start/finish) shooting area 
locations.

|---------------------------------------------------------------------------------|
|                               Before you start:                                 |
|---------------------------------------------------------------------------------|

Be a fair player and do not use any cheats of all kind AT ALL! Maphack can cause
a mismatch on this map.

On this map you can only play as a vanilla GLA faction, which means you cannot 
pick USA, China, Demo, Stealth or Toxin. You have to race against the other 
players, a little bit of combat is included too.

This version has an anti force-fire script. If you force fire on another racing
player then your vehicle will die and you ahve to start over again.

Picking teams does not matter, everyone will see everyone as neutral, no matter 
how you set the game up. You get Emergency Repair 3 on this map for free, use it 
wisely since you need to use it on certain locations in order to survive.

Try to have at least a good PC or you will cause massive lag. There are a lot of
scripts in this map, not all active at the same time, but still.

|---------------------------------------------------------------------------------|
|                               The game set-up:                                  |
|---------------------------------------------------------------------------------|

The host is the driver of the Humvee on thr gith top side of the map. He will
chose the game set-up. It's fairly common sense what everything stands for.

The host has to set these 3 things:

Difficulty mode:
Easy: This will be a very easy game. Use this to learn the map.
Medium: This will be a harder game than on easy. The AI will have Bombardment
strategy enabled. Also there will be a few random General Point and SW droppings.
Some things have been upgraded with upgrades and Speaker Towers have been added.
Hard: This will really be a challenge. The AI will have Bombardment, Hold the Line
and Search and Destroy strategies. A lot of random General Point and SW droppings.
Also a lot of things have been upgraded with upgrades.

Track length:
Short track, medium length track or long track.
This really needs no explanation.

Amount of laps:
The amount of laps you need to race with 1 being the least and 10 being the
highest.

Tip: don't set the amount of laps too high, it will take a very long time to 
finish it then. Only use high lap amounts with non-quitting friends.

|---------------------------------------------------------------------------------|
|                                   The Race:                                     |
|---------------------------------------------------------------------------------|

You will race with a Technical where you need to dodge a lot of different things.

You can kill the enemy (grey troops), but not the other race players. The things
that you cannot lock-on are unable to be destroyed (unless you have the stealth
power-up).

The winner is the person who crosses the finish line first with the amount of laps
selected. That person is also the only one that can claim his victory. On this 
way you can continue racing on if you like. More fun for people who finish quickly
and want to wait for the others to finish.

Tip: if you accidently zoom in then move your worker on the camera reset area
place. This will reset the camera zoom out for everyone.

|---------------------------------------------------------------------------------|
|                                      Other:                                     |
|---------------------------------------------------------------------------------|

Please don't edit my map without my permission. If you find a bug on my map 
then send me a Personal Message on www.gamereplays.org account name; StefanDeath
You could also send me an e-mail to stefan-death@hotmail.com

There is no need to mention that the Terrorists sometimes don't attack. This is 
an in-game bug which can only be fixed by a new patch.

Have a look at www.gamereplays.org so you can become a pro player at gaming.

Special thanks to GooGle, PePsI., l2aider and herbplant to help me test out some 
stuff.

This map has been made by StefanDeath aka -DeaD|-Wraith^ 
� October 2011