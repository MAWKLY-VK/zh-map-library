Map layout and design created by- Joey
AI, train, and water glitch fixes by- RVMech

________________________________________
This map was downloaded at 



       CNCDen 
                    and/or 
                            WWExp.

________________________________________
Email me at smagee2001@msn.com for permision
to upload this map to your site.
________________________________________
YOU MAY NOT-UNDER ANY CIRCUMSTANCES
EDIT AND/OR ALTER THE CONTENT OF THIS
ZIP!

Have a nice game!