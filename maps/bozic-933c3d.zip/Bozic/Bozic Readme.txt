Map name: Bozic
By Pivac

Players: 2 (Multiplayer online or skirmish-AI enabled)
Game: Zero Hour Expansion

E-mail: pivac91@email.t-com.hr

 
-Installation:

    Extract the complete folder included in the map zip file into 
    C:/My Documents/Command and Conquer Generals Zero Hour Data/Maps
    (if you followed the default installation for the game).
    If folder Maps does not exist, create it.