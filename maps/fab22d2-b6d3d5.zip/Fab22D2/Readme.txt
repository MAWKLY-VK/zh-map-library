FAB22 by orca

This is a small 2-4 Player desert map set in the morning.
Map contains 2 Supplies on each Side, 4 Oilderricks, 1 Repairpad, and the FAB22:)
There is something going on there, you may like to find out what...

2004orca