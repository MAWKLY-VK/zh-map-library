THE PAPERS

Created by Private Jim

Story:
General Ironside has been entrusted with the Gov. top secert papers(so top secert that I don't even know whats in them)
& has been ordered to get them to FBI HQ's, but first he decided to go to the officer's club, meanwhile the GLA has
taken over his house in search for the papers. Get Ironside home & retrive them and make the delivery..Good 
luck!!

Tips to help keep the mission on track:
Try not to let the Stealth fighters roam, use them for helping take out the GLA camp and clearing the way to Ironside house
and on to FBI HQ's, in that order.

You only have one supply drop so watch your funds or you might have trouble later in the game.


Mainly have fun!!



