MAP ::  Black Ice

AUTHOR :: WACKWARDS

PLAYERS :: 2vs3

STYLE :: Symetrical

AI :: SDI TEAM

INFO :: 

* Snowy Map with a Train in the center.
* Tech Buildings are balanced.  
* The 2 Reinforcement Bays can alter the outcome.