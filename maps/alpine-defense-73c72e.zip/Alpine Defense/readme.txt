E-Mail: Unreal_Raptor@hotmail.com

This map has been created for Command and Conquer generals zerohour.

Map Name: Alpine Defense
Map Author: Zire
Released: November 4th, 2003
Scenario: MOuntains
size: Small
Scripts: Snow and Intro
Resources: Few
Usage: Online and skirmish.

This map is build for online play and it has AI programmed however its my first map so don't expact that it's perfect.  

How to install: look in your computer for a folder named C:/My Document/Command and Conquer Generals Zero Hour data/Maps. If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and return to windows. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the C:/My Document/Command and Conquer Generals Zero Hour data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section.
 

you may use this map for personel use on youre cpu and trade it with online friends. It may not be used for commercial goals (like selling it) without my permission.