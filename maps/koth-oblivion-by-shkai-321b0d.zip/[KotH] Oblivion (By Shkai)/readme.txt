Map Name: [KotH] Oblivion (By Shkai)
Author Name: Shkai
Auther Email: shkai@shkarian.net
Max Players: 8
Game: Command and Conquer Generals Zero Hour
Type of Map: Multiplayer / Skirmish
Description: 

This is King of the Hill. All the money is in the center of the map.
Hold the hill with 3 or more units, gain generals xp.
Works with CPU players.

How to install... 
Extract zipped file into your Command and Conquer Generals Zero Hour Data Maps folder
Launch the game and play.

Have fun!