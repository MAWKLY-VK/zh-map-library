YOU HAVE DOWNLOADED A GENERALS ZERO HOUR MAP:                       NO MOD PROBLEMS YET
             Dynamite Dunes
             by. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!!

Gaining Access:
extract, copy, and paste the Dynamite Dunes files to the Generals Zero Hour map data Directory.

OVERVIEW:
4 player map multiplayer or AI
Has plenty of supplies and tech buildings
And (Coughs) sandy= sand and sand dunes ...Cough...Cough, and no water!

...but still try to have fun.

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!

you can place a question, comment, or suggestion about Command & Conquer and/or my maps
at sgtmyers88@yahoo.com

2005 sgtmyers88


