:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Shattered Bliss"
[Author]       = flippster06
[File Name]    = 009-Shattered_Bliss.map
[File Size]    = 112 KB
[Map Size]     = 270 X 270
[Players]      = 2 only
[Time Setting] = Morning
[Field Intel]  = Urban
[Resources]    = High
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Alliance Chief-in-Command Flippster
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

This war-torn area used to be the properous city of Sibiu, 
Romania.  The city was an unforunate victim of war. Seven years 
ago, rebel factions rose and took control of the city. It took 
the combined efforts of several nations to put them down, but at 
a high cost. Most of the city laid in ruins. Today, the streets 
are still empty, and people still say that there are still 
mines left on the ground, waiting to blow up on an poor person 
passing by.

General, there's a reason I'm sending you to this area. Two 
weeks ago, our agents stumbled over a GLA cell in Cairo, Egypt. 
After analysis of the data that was recovered in the raid, our 
engineers stumbled over some data of Sibiu and the Russian KGB.
The data tells that the KGB has a base of operations somewhere 
in the city.

At this time, the Alliance does not know the purpose the KGB is 
there, but they must be stopped nevertheless. Your job is to get 
in the city and destroy the KGB base by any means. Be warned 
that the KGB has stolen much technology from the US, Chinese, 
and the GLA, so prepare to encounter any kind of units.

The KGB are as much as a threat to the world as the GLA. Stop 
them with everything you got. I'm counting on you.

        ______
  >>>>>/_____/>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  >   ______   **** ALLIANCE HQ ****         >
  >  /  ___/   Chief-in-Command Flippster    >
  >>/__/>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Caution is advised while traversing through the city. There 
   are still live mines that can go off if your units step on 
   them.
:: Most structures are heavily damaged. Repair any structures 
   that you need garrisoned or captured.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * Alliance website = http://alliance.cncdepot.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================