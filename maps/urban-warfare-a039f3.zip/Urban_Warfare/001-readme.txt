:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Urban Warfare"
[File Name]    = 001-urban_warfare.map
[File Size]    = 57 KB
[Map Size]     = 282 X 282
[Players]      = 2
[Time Setting] = Night
[Field Intel]  = Urban
[Resources]    = High
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Alliance HQ
  [To]        = General ~
  [Time Post] = ~~:~~:~~ 6/05/~~

Welcome, General.  We are glad that you will be the one to
accept this mission.  Time is not on our side, so let's get to
the details.

The city of Kotovya, Russia has been under high tensions lately.
It almost looks like a gang war out there.  Both have high
positions in the city government, and both have been split on
several issues.  This is causing several uprisings during the
last few months.

The Chinese are worried of this situation, because the supply 
transit lines run through this city.  Diplomats were sent to 
resolve the situation, but rumors indicate that they are either 
held hostage or left dead.  The Chinese responded with a small 
army, but did not anticipate getting in the middle of the
conflict.  Word is that the army was defeated in a uprising
involving stolen mitilia tanks.  Survivors are currently held
hostage.

We believe that one of the forts located in the city may be the 
source of the manufacture of weapons and tanks.  We have done
one part of the job already by taking over one of the other
forts.  It is your job to eliminate the enemy base and bring
this conflict to an end.  The Russian primer has given orders
to anyone to bring the conflict down by any means as possible.

This is our chance.  We will soon reveal to the whole world
what the Alliance can do to "serve for the better cause."  Good
luck General.

 /===================\
  *** Alliance HQ ***
 \===================/

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Take advantage of the base at the center.  Supply trains
   frequently stop there to drop off supplies.  Secure and 
   capture if necessary, but be warned for any supply trains.
:: Be warned when traversing through the streets.  Guards might
   attack anyone not friendly.  Eliminate anything that poses a
   threat.
:: It might be possible to capture the abandoned nuclear
   power plants.  Be warned - they will explode with force if
   destroyed.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@mail.com
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================