Maddog's Revenge [day version] By Dave MADDOG Mortensen
Multiplayer and Skirmish
frikin_maddog@hotmail.com
This map is the intellectual property of Maddog
Copyright MADDMAPS 2003� all rights reserved

You're free to play the map, decompile the map, inspect the map,
and anything else your heart desires, but give credit where credit is due. 

This is a well balanced 4 player Multiplayer/Skirmish map taking place in the day. Plenty of room to expand your base, and a good amount of cash flow and capturable tech buildings. The map contains one train moving around the map. Be careful, the train will destroy a squad of tanks and troops if they stand on the rails at the wrong moment. Control of the middle of the map can make a big difference.

The folder contains 5 files, the map file, the .str file, the readme file, the TGA preview file and the .ini file.

To use the map look in your computer for a folder named My Document/Command and Conquer Generals data/Maps. If this directory doesn't exist, play a skirmish map and comeback. The folder should be there now.  Extract the COMPLETE FOLDER included in the map zip file in the My Document/Command and Conquer Generals data/Maps. Fire up the game and you should be good to go. 