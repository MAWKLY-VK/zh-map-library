
Headstrong Attack (ZH) (a skirmish map for C&CG Zero Hour)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________
	
	This is a 1 on 1 temperate map that is great for a quick skirmish game or 
	online matchups against friends.

	It has rain and lightning and thunder for weather effects. The time is set to 
	morning.

	The map can be played online or in a skirmish game. The map was designed so
	that the AI has a good idea of how to play.
_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.  
_____________________________________________________________________________________

Notes from the author
_____________________________________________________________________________________

	This map may require a high end computer (depending on the type of graphics
	card you are using). You can tinker around with the graphics settings in the
	'Options' section of C&C Generals Zero Hour. 
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) @ cncden.com
	Wastegrounds(ZH) @ cncden.com

New Maps

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) @ cncden.com

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour skirmish map was created by Dean K on the 11th of December
2003. This map is copyright Dean Krause 2003.