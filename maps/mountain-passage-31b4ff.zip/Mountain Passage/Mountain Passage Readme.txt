Command & Conquer Generals: Zero Hour Map

================================================================
Title                   : Mountain Passage (originally mountain pass)
Version                 : 1.0
Filename                : Mountain Passage.map
Author                  : cncplyr
Email Address           : cncplyr@blueyonder.co.uk                          
Description             : This is a 2-player map set in some snowy mountains. Look out for the pass!

Enjoy!!!
================================================================
--- Play Information ---
Game                    : Command & Conquer Generals: Zero Hour
                                 
Level Name              : Mountain Passage (Mountain Passage.map)

Game Type               : Skirmish
Single Player           : Yes (skirmish players supported)
Multiplayer             : Yes (hopefully)
Known bugs              : None known

--- Construction ---
Editor(s) used          : Worldbuilder
Base                    : Scratch

Requirements
------------
None.

Special Thanks
--------------
RVMECH for his scripts and stuff i downloaded from cncden


Installation
------------
To use the map, look in your "My Documents" for a folder named "Command and Conquer Generals Zero Hour data/Maps". If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and comeback. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the "/Command and Conquer Generals Zero Hour data/Maps" folder. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section.


Copyright / Permissions
-----------------------
This level is copyrighted by 'cncplyr' 2004-2005.
Authors may NOT use this level as a base to build additional levels, unless they have my permission (if ya ask nicely I'll probably let you).

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!

You MAY distribute this BSP through any electronic network (internet,
FIDO, local BBS etc.), provided you include this file and leave the archive
intact.

----------------------
All trademarks and trade names are properties of their respective owners.
