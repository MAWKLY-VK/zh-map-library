Tomahawk Storm
--------------
ver 1.1
by beng

Single player mission for CnC Generals Zero Hour version 1.04

To install, put the folder in:
\My Documents\Command and Conquer Generals Zero Hour Data\Maps
Then open the map from the Skirmish menu.

This was made mainly as a test map to illustrate how to implement
the Tomahawk Storm using a map.ini. Map makers and modders may be
interested in this. The tomahawk storm really is just another
scud storm.

I modified the GC_Chem scud storm into the tomahawk storm, and
the GG_Chem scud storm missile into the tomahawk storm's cruise
missile.

This missile flies to it's target, flying over hills and around
structures that have KindOf = AIRCRAFT_PATH_AROUND because it
is an aircraft.

Also, it can be attacked and shot down by all units which have
anti air weapons, not only those which are allowed to attack
BALLISTIC_MISSILE kind of objects.

When the missile dives over the target, it releases five combined
effects munitions, which spread out to spread their devastation.
They have explosion, shockwave, and incendiary effects.

As a mission it is pretty easy but still fun.

You start off with 2 tomahawk storms and basically win by destroying
all the enemies on the map.

Version 1.1 changes:
--------------------

The tomahawk missile submunitions will not all explode. Some will
be duds and remain unexploded on the battlefield. These will then
explode at random intervals for some time, and also explode if
enemy units go near them. This mimics real cluster bomb behavior
where some submunitions always fail to go off and pose a hazard
after the battle is over.

The ambulance and dozers can try and defuse the unexploded ordnance.
