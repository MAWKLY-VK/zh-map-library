
Bring it On! (ZH) (a skirmish map for C&CG Zero Hour)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________
	
	This is a one on one challenge map for skirmish or online play. Throw down
	the guantlet to your friends and show who's more powerful!

	The map is designed to make online play more fun by loading fast and running
	quickly. Supplies are laid out in such a way that plays are forced quite quickly
	to resort to securing supplies on the battle line.

	The oil derricks are booby trapped so you should clear them first.

	* Oil derricks are booby trapped
	* Supply docks are indestructable
_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.  
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) @ cncden.com
	Wastegrounds(ZH) @ cncden.com

New Maps

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour skirmish map was created by Dean K on the 22nd of December
2003. This map is copyright Dean Krause 2003.