
Fight for All (ZH) (a map for C&CG Zero Hour)
_____________________________________________________________________________________

News Item
_____________________________________________________________________________________

	This map is a 3 player map in a snowy environment. Oil derricks are nearby
	each player. A lot of resources are available for each player. Runs in
	skirmish or online modes.

_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the manual on page 41.
_____________________________________________________________________________________

Previous Work
_____________________________________________________________________________________

	Generals Zero Hour Maps:
	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml

_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au

_____________________________________________________________________________________

This C&C Generals Zero Hour skirmish map was created by Dean K on the 5th of November
2003. This map is copyright Dean Krause 2003.