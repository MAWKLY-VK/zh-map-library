This file contains credits about Chaos Islands [Tidal Map].
Please leave this file in place as a sing of respect for the authors.

Author: [NED]DEMO
Xfire: dreamoralizer

Author: [RTS]BN+VS*
Xfire: bn2vs
Website: www.tiko-world.com & www.bn2vs.com



=========================================================================
Installation Instructions:
=========================================================================
	Place the Chaos folder in your "My Documents/Command and Conquer 
	Generals Data/Maps/" and you're ready to go.
	Make sure that within the Maps folder the .map and .tga file are in 
	its own directory which has the exact same name as the .map file.


=========================================================================
map Info:
=========================================================================
	Players: 4
	Playable via Multiplayer and Skirmish
        This is the firsth map of its kind!
        Enjoy the amazing detailed terrain as wel as the chaos effects
        like the weather that will effect the waterlevel.
        No rush or SW during the first 8 minutes. After that it'll be chaos!


=========================================================================
version Info:
=========================================================================
       This is the readme file of
       "Chaos Islands [Tidal Map] v2.0 - tournament edittion"
       Updates can be found at generals.bn2vs.com and generals.tiko-world.com