:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Hell Hath Fury"
[File Name]    = 005-Hell_Hath_Fury.map
[File Size]    = 106 KB
[Map Size]     = 250 X 250
[Players]      = 2-4
[Time Setting] = Unknown
[Field Intel]  = Unknown
[Resources]    = Unknown
-----------------------------------------------------------------


--< WARNING >----------------------------------------------------
Due to the extreme nature of this map, this map is only 
playable online.  There are heavy restrictions that will affect 
gameplay on this map.  See "Additional Intel" for further 
details.
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Alliance Base Camp Assistant Commander
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

General, we've almost arrived at our destination.  Currently, we 
are still in the tunnel, about 5 meters below the surface.  We 
are still a few miles from our destination.  Right now, our 
intel unit has returned with some grim news.

"If hell was the center of the earth, where we're heading is 
too close to it.  There's burning lava everywhere.  Some say 
that the magma could spew out any minute.  I caution building 
anything here.  Our men could get seriously hurt from all that 
lava."

From the report, the area looks unstable, but our job remains 
clear.  We have to secure as much Oil Derricks as possible.
And, from what the situation looks like, we'll have to achieve 
it at any cost if necessary.

God, I hope we know what we're doing...

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Lava can purge forth from the surface briefly, spewing lava
   and radation.  Any unit that is close to the eruption could
   be seriously damaged or destroyed.
:: Due to the unstability of this area, the following can only 
   be built:
   - Command Centers
   - Any Power Plants (if app.)
   - Barracks
   - Supply Centers / Stashes
   - War Factories / Arms Dealers
   - Any Defense Buildings
:: In addition, the following is in effect:
   - All Supply Centers / Stashes come with 3 Toxin Supply 
     Trucks.  No additional trucks can be purchased.
   - Everyone is limited to 1 Supply Center / Stash
     facility.
   - Only the 'Emergency Repair' powers are allowed in this 
     area.
   - Full revealed radar is available to everyone.
:: TO ALL GLA GENERALS: Fake Structures are not available.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@att.net
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================