"Baghdad Outskirts" is a good facelift of the custom map "Saddam City" 
(http://commandandconquer.filefront.com/file/Saddam_City;49385#Download)
for the game Command & Conquer: Generals

Map Name: Baghdad Outskirts

Map Author: Lucker23 Email: lucker23@hotmail.com

Released: originally 23/10 2005, updated 03/03 2007

Usage of Map: Multiplayer Online or Skirmish mode against the computer

Players: 2-4; 2on2 and 1on1 recommended

Setting:
2003, the outskirts of Baghdad.

Start Conditions:
- 6 Supply docks, each player 1, 2 to be captured and secured
- 2 Oil Derricks for each player
- 1 hospital, to be captured and secured
- 1 oil refinery, to be captured and secured
-> balanced


map preview:

northern part of map:
Sadr City; a wealthier district of Baghdad; UN embassy

--------------Tigris River-------------------------------------------

southern Part of map: 
"Saddam International" Airport; desert landscape; highways leading to Saddam City








Installation: extract the "Baghdad Outskirts" folder to a folder called:

X://My Documents/Command And Conquer Generals Data/Maps/
