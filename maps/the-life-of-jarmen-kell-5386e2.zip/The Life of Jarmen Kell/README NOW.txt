
***********************************************************************
                         THE LIFE OF JARMEN KELL
***********************************************************************

By Jack Darby AKA Darbyjack. get it?

Email: thedarbyjack@yahoo.co.uk   Please send me your comments and ideas! I like to know!

To install is very simple, just copy and paste the mission folder into your maps directory which would be like:

C:\documents\command and conquer generals zero hour data\maps

***********************************************************************
                        HINTS AND HELP etc
***********************************************************************

I know that this mission is quite hard but it is possible. Screaming at your screen and hitting your keyboard might get you a bit further and is proven to help stimulate the mind.

Also email me for help AND if there are any mistakes, please tell me.

11/feb/04