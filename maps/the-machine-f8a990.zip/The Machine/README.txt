The Machine

A single player mission for C&C Generals Zero Hour

created by spyVspy

You command an ICBM silo base in North Dakota.  Your goal is to keep the missiles secure from capture or sabotage.  You have defense forces in place and the ability to build more as needed.  Your defenders include conventional forces, and new fighting drones.  The mission begins when an intruder has been detected entering the base...

Tip: There is a powerful laser wall shielding the doors to the underground silos and launch control facility.  
To prevent intrusion you must keep your base powered up.


comments welcome: spyvspy@ix.netcom.com