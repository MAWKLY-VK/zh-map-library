YOU DOWNLOADED A GENERALS ZERO HOUR MAP                                    NO MOD PROBLEMS
        Battle on The Airfield
            By. sgtmyers88
PLEASE DO NOT EDIT THIS MAP WITHOUT MY PERMISSION!

TO GAIN ACCESS:
extract, copy, and paste the Battle On The Airfield files to the Generals Zero Hour Directory.

OVERVIEW:
A Large Airbase consisting of several individual airfields that you can capture and use for your army
has some nice details and extras for 4 players, AI skirmish or miltiplayer.


BUGS/PROBLEMS:
None Yet.

Questions and comments can be posted via email or instant messenger at 
sgtmyers88@yahoo.com


YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!


HAVE FUN!

2005 sgtmyers88