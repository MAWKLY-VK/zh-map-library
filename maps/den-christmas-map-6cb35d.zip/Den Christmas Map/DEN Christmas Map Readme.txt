You downloaded this map from CNCDEN - http://www.cncden.com

email: webmaster@cncgames.com

CNCDEN covers everything in the Command & Conquer Universe of Games.

This map is for the game Command & Conquer: Generals ZERO HOUR Expansion

Map Name: DEN Christmas Map 2003 (Zero Hour Expansion)
Map Author: Lion (Webmaster - Den Games Network)
Released: December 22, 2003
Map size: 375x375
Players: 2-4

Map Description: This is a 4-player detailed map taking place in the late afternoon in a Snow environment. There's also a large Christmas Tree on the map that divides the players. Lots of goodies on the tree! Plenty of room to expand your base, and a good supply of cash to keep your army on the go. Concrete bunkers scattered near the perimeter of the each player's base. There are buildings to garrison at various locations. Oil Derricks available for capture as well as some other tech structures. Some goodie crates scattered around the map including money crates and free Crusader Tank crates. Use this map for online play or skirmish against the AI. If you use it for skirmish, play either Hard or Medium Army for the best action. 

NOTE: There are two versions of this map available for download from the DEN. In this map it is snowing...we also have a version where there is no snow for those of you who prefer that.

Directions for playing: To use the map, look in your computer for a folder named C:/My Document/Command and Conquer Generals Zero Hour data/Maps. If this directory doesn't exist, play a skirmish map and comeback. The folder should be there now. Extract the COMPLETE FOLDER included in the map zip file in the C:/My Document/Command and Conquer Generals Zero Hour data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section. 


This map was made by Lion, webmaster of the DEN Games Network. The map is exclusive to CNCDEN and is copyrighted 2003. You may use it for personal use.