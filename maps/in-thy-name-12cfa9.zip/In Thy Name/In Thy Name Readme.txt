Map Name: In Thy Name (single player mission map)
Auther: VGsatomi

Worst case scenerio has happened, and the Chinese Red Army has at last mobilized
to invade and Annex Taiwan. The small contingent of US troops stationed there now
must work frantically to prepare defenses to fend off the onslaught. The Chinese
will be sending small waves to help soften the defenses until the brunt of their main
body arrives fifteen minutes after the beginning of combat operations. If
those forces arrive, there will be no stopping them. The only hope US troops have it
to destroy the five battleships stationed in the bay that are being used as obsevation
posts for command & control. If they can disrupt combat coordination, then American
troops will have a fighting chance. There are two American bases further inland that
can be freely utilized for the war effort.

Mission Objectives: 
-Destroy the five battleships. 
-Use the ICBM silo thats alongside the cliffs just north of the road. Be sure to aim 
 center mass of the ships to ensure a clean kill. The silo has a two minute cooldown.

Mission failed if: 
-American troops fail to destroy the 5 ships before the time limit expires.
-The Chinese secure the beach. That means all friendly troops (not including buildings)
 at the front line are destroyed.

Hints:
-Don't forget to choose your strategy at the strategy center!
-Train additional snipers and missile defenders to further reinforce the front line.
-Use chinooks and humvees to carry troops the long distance to the front.
-To prevent the Chinese from securing the beach, make sure you have at least one unit
 in the area of the beach at all times.
-The battleships will relentlessly bombard any friendly units that step foot on the
 beach, so keep your men up on the cliffs.
-Use planes to pick off incoming transports to releive pressure off the front line.
-Keep aircraft away from the gunboats!

Good Luck! A nation is counting on you!

Changes made in updated version:
-Carrier can now be destroyed
-Bunkers automatically garrison at start
-Power Plants automatically upgrade at start
-"Bombardment" strategy automatically selected at start
-Slightly more units in enemy waves
-Slightly more terrain
-Chinese now get infantry paradrops
-Un-used generals abilites removed
-Enemy waves weaken out as bunkers are destoyed, allowing players to still have a 
 chance at victory even though defenders are dying
-More cosmetic detail
-Fixed small bugs


