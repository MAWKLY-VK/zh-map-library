Map Name: Lake Of Death.
Map Size: Can't Remember.
Map Author: Gee

This is a 1vs1 map, not to big, not to small. features rain, and the rain sound effect. 
Each player gets a battle ship to fight with, although the AI dosent get one, for unknown reasons. 
Waves are included and it is set on a bright night.

Enjoy the map......