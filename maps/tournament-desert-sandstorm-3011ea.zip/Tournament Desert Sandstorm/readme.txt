---------------(Section 1)---------------
Map: Tournament Desert Sandstorm
Players: 2
Date first released to community: 6th December 2021 (UK)
Map Maker: Jundiyy
Contact: the-onejundiyy@hotmail.com
Thanks: To everyone that helped me in the past, especially to my good mates Kobane, E-3 and Punisher for helping with many of my maps.
Also thanks to Anaconda for some of my maps.

I used my full remake of Tournament Desert, Tournament Desert Revived and edited it a bit to make this version.
---------------(Section 2)---------------Scripts in this map---------------(See section 5 for details)---------------

No scripts in this map.

---------------(Section 3)---------------
Contact: the-onejundiyy@hotmail.com
YouTube: https://www.youtube.com/Jundiyy
-----------Maps-----------
Survival maps: https://bit.ly/2XIf35v
Standard maps: https://bit.ly/3dbuNEB
Micro Maps: https://bit.ly/2AedzaW

---------------(Section 4)---------------PERMISSIONS/USE---------------

You are free to use my maps and scripts, please don't take the credit for them, as they are still my work and they belong to me.

Sometimes I may edit a map, this will be told at the begining of the map, something like Welcome to xxxxx by xxx edit/revised by The-One/Jundiyy.

---------------(Section 5)---------------Scripts/Features on my maps---------------

What do they mean?

Give money to teammate - This script allows you to transfer $1000 on to the map as a cash crate, which can be collected by anyone. A player must garrison the outhouse and then have a unit placed in each coloured square near it.

Ghost Market/Hidden Market - This is a off map market which is given to the players, if the player dies or surrenders, this market is destroyed.

Defence is the last buidling - This script only allows the player to die once EVERY building has been destroyed, including
                               all defences, just like it is in the Command and Conquer Generals.

Carpet Level 3 - AirForce General Carpet is enabled at level 3. Usually once the player is Rank 3, Carpet will become available, if not, it will need you to purchase A10 Level 1.

Super Hacker - This is an Infantry General Hacker with 501 HP (Kell needs to snipe 2 times to kill it).

SSSDDZ - Super Strong Supply Dropping Drop Zone - This is a non captureable drop zone with 4000 HP (5000 HP for Contra) - this means it is just over 2 times stronger than an oil.

SSDZ - Super Supply Drop Zone - Same tech as above however only havin 2500 HP.

Double HP Oil - Oil has 4000 HP (double health) instead of 2000 HP

Free Tunnels - This gives players free tunnels on the map.

Respawning oils - Some or all of the oils will respawn after a given timer, this is usually 3 mins.

Respawning cash crate - Some or all of the cash crates will respawn after a given timer, this is usually depdent on the amount of cash receievd. $100 cash crate will respawn every 60 seconds.

Respawning units - Certain units will respawn after being destroyed.

Give money to teammates - This scripts allows you to give money to your teammate, simply by enterting one unit into the outhouse (or whichever building may be used) and having units in the squared
                          patches of land near the building, (usually 2, but can be any amount). The outhouse will respawn once destroyed. At the moment this does not work on shockwave 1.1.

---old script---Money giving huts - These are huts which give money when garrisoned, usually:-
                    - The grass huts give $20 every 15 seconds
                    - The wooden huts give $35 every 15 seconds.
                    - The large grass huts (MarketHuts) are equivalent to a market.
                    - The huts will usually give double the amount of money in shockwave.
                  However it is possible that this rule isn't followed in every map.
                    The huts will respawn.

---new script---Money giving huts - These are huts which give money when garrisoned, usually:-
                    - The grass huts give $20 every 5 seconds
                    - The wooden huts give $35 every 5 seconds.
                    - The large grass huts (MarketHuts) are equivalent to a market.
                    - The huts will usually give double the amount of money in shockwave.
                  However it is possible that this rule isn't followed in every map.
                    The huts will respawn.

Grass huts - Usually all NON MONEY giving small grass huts have 250 HP.

Respawning Supplies - These supplies will respawn on a timer after depletion.

---------------(Section 5)---------------All my published maps---------------(Anything with the letter R are full revisions of other maps).
-----------Standard:-----------
---2 player---
Alpine Assault v2
Ammars Sandcastles v3 (Revision of Ammars Sandcastles v2)
Annihilation
Artic Lagoon (Revision of Lagoon)
Blizzard Badlands (Revision of Barren Badlands Balanced)
Blizzard Badlands Reloaded (Revision of Blizzard Badlands)
Desert Scorpion
Eagle Eye
Evergreen Lagoon (Revision of Artic Lagoon)
Forgotten Ruins
Frozen Ruins
FrogPrince v2 (Revision of FrogPrince)
FrogPrince v3 (Revision of FrogPrince v2)
Gold Cobra
Hidden Treasures
Hidden Treasures v2
Hardened Earth
Imminent Victory (A full remake of Natural Threats (no edits)
Mountain Mayhem
Lost Valley
Refuge
Sand Scorpion (Revision of Sand Serpent)
Snowy Drought (Revision of Gorge Drought)
Sovereignty
Storm Valley 
Storm Valley Hailstone
The Survivors
The Victory
Tournament Desert Paradise (Revision of Tournament Desert Revived)
Tournament Desert Revived (A full remake of Tournament Desert)
Tournament Desert Sandstorm (Revision of Tournament Desert Paradise)
Uneven Heights
Winter Arena (Revision of [NMC]Summer Arena)
---4 player---
Bursting Asunder
Circle Of Death 4
Green Silk
Hidden Pearls
Horizon Heatwave
Island Of Chaos
King Of The Ring
Rubies and Pearls
---6 player---
Defcon 6 v2
-----------Survival:-----------
---2 player---
Annihilation Survival (2)
Annihilation Survival (2) v2
Annihilation Survival (2) v3
Area J1 Survival
Area J1 Survival v2
Blasted Blades Survival
Blasted Blades Survival v2
Blasted Blades Survival v3
Desert Desert Survival (2)
Desert Desert Survival (2) v2
Desert Desert Survival (2) v3
Hardened Earth Survival (2)
Hardened Earth Survival (2) v2
Hidden Treasures Survival (2)
Hidden Treasures Survival (2) v2
Hideout J3 Survival
JTC Jundiyy's Training Camp Survival
JTC Survival v2
JWF Jundiyy's Walled Fortress Survival
JWF Survival v2
Natural Lands Survival (2)
Natural Lands Survival (2) v2
---4 player---
Annihilation Survival
Blasted Blades Survival 4
Central Rush Survival
Circle Of Death Survival 4
Desert Desert Survival
Desert Island Survival
Hardened Earth Survival
Horizon Heatwave Survival
Island Of Chaos Survival
Mountain Mayhem Survival
Natural Lands Survival
no money 1v1v1v1 Survival (R)
Standard Survival
Sudden Combat Survival
Surviving the Ultimate
The Lost Valley
Uneven Heights Survival
-----------Micro Maps-----------
BattleBus - Horizon Heatwave
BattleBus - Tournament Desert
BattleMaster - Circle Of Death
Helix - Island Of Chaos
Helix - Tournament Desert
Humvee - Mountain Mayhem
Humvee - Tournament Desert
Mortar Buggy - Death Canyon (Contra)
Rocket Buggy - Forgotten Ruins  (Contra)
Quad - Forgotten Ruins