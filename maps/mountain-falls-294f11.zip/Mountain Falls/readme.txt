
Mountain Falls - by Andrew

This is a multiplayer or skirmish 4 player map for Command & Conquer Generals Zero Hour
basic 4 corner setup.

There are 4 oil derricks, 2 oil refinery's, and 2 repair bays up for grabs..

Also scattered around the map are small supply piles for a little extra cash..

The players who are on the right of this map have to cross bridges to get to the other
players and vice versa.. makes a great 2v2 map..


           Hope u Enjoy the map
                And thanks for dowloading it..


                              Andrew...  