Casino - Resurrection Two by Haubibban & cetx.

Map introduces a famous Casino gamemode: players can get units for entering casino structures!
Casino prises consist of different units or cash.

Map Features:
  - Casino spawns on player's island and in the middle. Over 50 unique prizes available!
  - The longer the game goes, the shorter casino cooldown will be. 75 seconds for Main Casino and 150 seconds for Middle Casino at the start
    and up to 40 seconds for Main Casino and 90 seconds for Middle Casino.
  - High tier prizes (Boss Dozer, Super Stealth Worker, 20000$, Super Stealth Jarmen Kell) can only be obtained via Middle Casino.
  - Dynamic Oil Derricks: Oils will change their positions over time to be captured by players!
  - Low money gameplay: funds at the start are very limited, and secondary economy can only be built when Oil Derricks are in the Middle.
  - All player positions are revealed at the start of a game. Knowing who are you against is vital in casino.
  - Map brings different feeling of the game WITHOUT using map.ini.
  - Minor changes: certain units got Guard and Guard Air buttons for more comfortable control.

Game balance:
  1) Auroras are removed. (except Boss' ones)
  2) Airforce Carpet Bombing is available only at Rank 3.
  3) Superweapons activate only after 30 minutes (except Boss).
  4) Demolitions Upgrade can only be researched in Boss General's Scud Storm.
  5) Stealth Comanche Upgrade is removed.
  6) Nuke General's MiGs are replaced with vanilla napalm ones.
  7) Bunker Busters and Tactical Nuke MiG upgrades are granted at the start for free. (Nuke MiGs can only be obtained via Casino)
  8) Tank General's Hackers price changed to 625$.
  9) Boss General can build Nuke Overlords, Laser Paladins and Demo Bikes instead of vanilla ones.
  10) Super Stealth (GC_Stealth) can build Scud Launchers right after Arms Dealer being built.
  11) Upgrades from Chinese Nuclear Missile are moved to Propaganda Centers.