
Communication Breakdown (ZH) (a SP mission for C&CG Zero Hour)
_____________________________________________________________________________________

Breifing
_____________________________________________________________________________________

	Small cells of GLA have taken control of key buildings in Bejing.

	The building under control of GLA force thus far are:

	1. SBC TV Station
	2. A key government building
	3. Shin Fai nightclub
	4. Tsing Shi Tao train station
	5. Bejing townhall
	6. Ta Hun Hwai mega mall

	The majority of civilians have been evacuated from Beijing. A temporary
	outpost has been set up in the South of Beijing. 

	Local law enforcements and units from the Chinese Liberation Agency are
	providing security for the remaining civilians in the city.

	Objective 1: Recapture all buildings captured by the GLA by garrisoning them 
	with your infantry

	Objective 2: Protect all recaptured buildings from attack

	Objective 3: Capture the GLA Command Center to the NE

	* You must keep civilian casualties to a minimum
	* Difficulty is set to Hard

_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Multiple chances at using various tactics to win
	- Mulitple routes to AI
	- Ambient sounds set mood
	- Moving light traffic
	- Nighttime setting
	- Industrial areas
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Recapturing Buildings

	To recapture buildings effectively use a Dragon Tank to clear the building and
	then stop attacking. Fill the building with appropriate infantry.

	Then fill the surrounding buildings with infantry to support the defence of
	the building.

	Hint #2: Defending

	When defending use your surroundings to your be advantage.

	Hint #3: Money supplies

	Look around the map for alterior methods of gaining cash for spending on your
	units.
_____________________________________________________________________________________

Requirements
_____________________________________________________________________________________

	This is a high detail map!	

	This map contains a lot of units, buildings and other objects that are in
	a concentrated area. For this reason you should run this map on a modern
	PC. You can change your settings in the main menu by clicking "Options". 	
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION @ DK Online
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour SP map was created by Dean K on the 30th of January
2004. This map is copyright Dean Krause 2004.