
Mountain Valley (ZH-ProGen) (a SP mission for C&CG Zero Hour + Pro:Gen 2.1)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________

!---------------------------------------------------------------------------!

IMPORTANT NOTE: You need to have ProGen 2.1 for Zero Hour installed for this
mission to work properly. The very popular mod is available at: 

http://deezire.net
	
!---------------------------------------------------------------------------!

	Your objectives for this mission are:

	1. Recapture the Chinese base
	2. Capture 4 radar stations
	3. Eliminate all GLA Demo forces
	
	* If any of the radio stations are destroyed the mission is a failure
	* If you lose all of your forces the mission is a failure

_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Ambient sounds set mood
	- Snowy setting
	- Waves on shoreline
	- AI trigger attacks
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint 1: Cave Networks

	Caves are present on this map and they should be used to get your forces from	
	one side of the map to the other quicky.

	Hint 2: Capturing enemy buildings

	Capture enemy building that will be useful for your mission.

	Hint 3: Tread lightly

	Ensure that you have sufficient units to attack before you attempt to get
	into the enemy's base.

	Hint 4: General abilities

	Upgrade your General Abilities to achive the mission quickly.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

New Maps

	Communication Breakdown (ZH) SP MISSION @ cncden.com
	Sudden Strike (ZH) SP MISSION @ cncden.com
	Cobra Cell (ZH) @ cncden.com
	Level Playing Field (ZH) @ cncden.com
	Snow Storm (ZH) @ cncden.com
	Survivor (ZH) @ cncden.com

NOTE: All my maps are available from my website, DK Online and some from genmaps.com

-------------------------------------------------------------------------------------

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour skirmish map was created by Dean Krause on the 15th of February
2004. This map is copyright Dean Krause 2004.