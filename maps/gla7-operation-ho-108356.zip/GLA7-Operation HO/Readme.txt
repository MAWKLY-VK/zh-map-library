Map Details:
Game: Generals Zero Hour
Number of players: 1
Name: Operation: Homeland Offense
Side: GLA
Difficulty Level: Hard
Creator: Warren 'DiscoScrew' Berry
Edited by: Mr. Toxin
Date: 4/8/2009

________________________________________________________________________________________________

Description
________________________________________________________________________________________________

This is the 7th mission of my GLA campaign. It takes place in Mexico, after GLA has finally set
stronghold in Europe. First GLA stops Chinese-American negotiations in New York, and then they
attack Baja, Mexico. First mission is to destroy American Base, second is to secure fuel trucks 
for Rocket Pad. Optional mission is to find some lost SCUD Launchers. Final mission is to defend
Rocket Pad from vast American army from Mexico borders. This was all created thanks to Warren.

I edited mostly terrain, since he had many unblended textures, misplaced buildings, uncompleted
things. I created some wandering civilians near Gas station in the east of map and a Supply Warehouse.
In the next version, I'll add more civilians, cars, objects, enemies, etc. I might also script 
more missions and wanderers.

________________________________________________________________________________________________
Credits
________________________________________________________________________________________________
Special thanks to Warren Berry for creating the main missions and terrain. He has done most of
the things for this map. He published his map in 2004.
________________________________________________________________________________________________

Bugs and problems in the game
________________________________________________________________________________________________

If you find any bugs, PM me on www.cncmaps.com and explain what it is and it'll be fixed.

________________________________________________________________________________________________

How to install
________________________________________________________________________________________________

To install this map, just place the folder to your My Documents/Command&Conquer Generals Zero Hour Data/Maps.
Then start Zero Hour and go to Unofficial maps.

________________________________________________________________________________________________

Copyrights
________________________________________________________________________________________________
If you want to publish my maps on your site or wish to edit them, please PM me on the 
www.cncmaps.com for permission.

Copyright cncmaps~Mr.Toxin 2009

________________________________________________________________________________________________

Contact
________________________________________________________________________________________________
If you have any questions how to pass my maps or some suggestions and ideas, PM me on the
www.cncmaps.com.