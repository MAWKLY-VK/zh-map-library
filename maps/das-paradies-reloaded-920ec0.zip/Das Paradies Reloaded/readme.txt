Map Info:
---------

-Map Made for: C&C Zero Hour expansion
-Date: 12.3.2004 
-Map: Das Paradies Reloaded
-Author: Sisslik (http://www.CnCHQ.de)
-Players: 6
-Type: Singleplayer/Multiplayer/Skirmish KI F�hig!

Das Paradies Reloaded ist eine 6 Player Map f�r Zero:Hour, die alte Map �Das Paradies� wurde als Vorlage genommen 
und es wurde alles ver�ndert bis auf die Struktur der Karte. Jetzt schimmert das Wasser sch�n Hellblau, es Donnert und Regnet leicht. 
Au�erdem wurden sehr viele Texturen verwendet um die Karte auch sch�ner zu gestalten.

Jeder Spieler hat ausreichend Platz zum bauen und nat�rlich auch gen�gend Ressourcen um seinen Feldzug zu finanzieren. 
Au�erdem gibt es noch eine Entsatzzone, Raffinerie, Reparatur Plattform und nat�rlich auch einpaar Gesch�tzt�rme. 

Die Karte wird von Oben nach unten gespielt, ideal f�r ein sch�nes 3vs3 aber auch f�r ein 2vs2 Match bei der Ihr auch etwas Tropische 
Abwechslung genie�en k�nnt.

Diese Karte ist Skirmish Tauglich! Bittet beachtet wenn Ihr die Karte mit anderen Leuten spielen wollt und diese ebenfalls 
jedes kleine Feature genie�en wollen, dann sollen alle die Karte Downloaden statt im Game.


Installation:
-------------

Unzip the complete map folder in: my documents/command and conquer generals zero hour data/maps

Diese Map darf nur bei http://www.cnchq.de als Download angeboten werden.

Visit us:

Command and Conquer Headquarters - http://www.CnCHQ.de

IRC: #CnCHQ @ QuakeNet

Email: Sisslik@CnCHQ.de