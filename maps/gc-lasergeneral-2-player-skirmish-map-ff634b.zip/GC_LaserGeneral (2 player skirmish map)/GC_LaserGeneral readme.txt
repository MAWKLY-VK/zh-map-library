*********GC_LaserGeneral readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        GC_LaserGeneral
Created by:  snowy007
Players:     2 players




installation:
--------------

unzip and put the folders in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

the official Laser General map of the Generals challenge. placed some 
Laser General power plants you cann take over. there are also some laser 
defences but you can't use them. 

i liked it most whith an enemy gla computer player in the middle







