:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "008 - pWn3d"
[File Name]    = 008-pWn3d.map
[File Size]    = 72 KB
[Map Size]     = 324 X 198
[Players]      = 2 only
[Time Setting] = Morning
[Field Intel]  = Urban
[Resources]    = Medium
-----------------------------------------------------------------


--< WARNING >----------------------------------------------------
Due to the extreme nature of this map, this map is only 
playable online.  There are heavy restrictions that will affect 
gameplay on this map.  See "Additional Intel" for further 
details.
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = "Black Barons" Alliance HQ
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

Hello, General.  We have heard of your fine performance with 
many of your battles.  We hope will it continue through this 
assignment...

In the small town of Lindenburg, there was a former castle 
rumored to be former residence of a Nazi commander.  Two years 
ago, German officials and the European Union converted the 
castle into a nuclear power plant.  The people in town today 
benefit from the income the town generates from this facility, 
but there still is disagreement among the people.

A week ago, scientists and workers discovered a problem with one 
of the reactors.  They are currently in the process of fixing it.
However, we have lost contact with them.  To make matters worse, 
spy sattlites have reported enemy units heading toward the 
facility.  If they reach the reactors and damage them, we could 
have a meltdown on our hands, and we cannot let this happen.

Your job is to get to the reactors first and then eliminate any 
resistance as possible.  We cannot cause any serious harm to the 
town, so you'll be limited to the units you can use.

I hope you can end this threat before they cause serious harm. 
Good luck, General.

  //--[ "Black Barons" Alliance HQ ]--\\
 |A|--[ Berlin, Germany            ]--|A|
  \\--[ ** German Sector HQ **     ]--//

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Due to limited space, the following can only be built:
   - Command Centers
   - Any Power Plants (if app.)
   - Barracks
   - Supply Centers / Stashes
   - War Factories / Arms Dealers
   - Any Defense Buildings
:: In addition, the following is in effect:
   - All Supply Centers / Stashes come with 3 Toxin Supply 
     Trucks.  No additional trucks can be purchased.
   - Everyone is limited to 1 Supply Center / Stash
     facility.
   - Only the 'Emergency Repair' powers are allowed in this 
     area.
   - Full revealed radar is available to everyone.
:: TO ALL GLA GENERALS: Fake Structures are not available.
:: The power plants are unstable. An explosion can wipe out 
   most of the town. Approach with extreme caution.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net
   * HQ E-mail = flippster06@gmail.com
   * Alt. E-mail = flippster06@att.net
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================