You downloaded this mission from CNCDEN.com


Command & Conquer
Generals: Zero Hour

Creator: romie88 aka [GFX][Anthrax]
Map name: Homeland Defense 2 (ZH)
Type: Single Player Mission
Objectives: Defend The USA Base 

To use this map: Just place the included map folder into your /my documents/C&C Generals Zero Hour/maps . Fire up the game and look under "Unofficial map" for the mission. Select it and your all set to go!
