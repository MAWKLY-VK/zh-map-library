Map Name: Way To The Other Side
Author: vlado32
E-mail: wowa566@azet.sk
Max. Players: 2
Game: Command & Conquer Generals Zero Hour
Type of Map: Skirmish
Description: Both players are starting on cliffs with 2 Civilian Bunkers to capture, sole way to enemy cliff is valley among cliffs, on this way you can find 4 Oil Derricks and Oil Reffinery.