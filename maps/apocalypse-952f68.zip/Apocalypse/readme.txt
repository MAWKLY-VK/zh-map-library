Mapname:  Apocalypse

Spieleranzahl: 3

Autor: - Stefan "germanpio" Piotrowski
       - Kevin Jendral

Die Map ist f�r Zero Hour gedacht

KI: ja

e-Mail f�r Ruckfragen:  ea-fan-pio@web.de