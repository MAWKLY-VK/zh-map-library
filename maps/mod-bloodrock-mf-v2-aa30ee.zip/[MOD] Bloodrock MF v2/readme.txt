----------------------------------------
   GAMEPLAY
----------------------------------------

- Like any regular FFA map

----------------------------------------
   MONEY FIELDS
----------------------------------------

- All traditional eco from supplies, oils, and secondary eco (Markets/Hackers/Drop Zones) have been removed and replaced by Money Fields.
- Place ground units on these fields to earn money.

----------------------------------------
   MONEY FIELD WIZARDS
----------------------------------------

- Money Field Wizards will spawn from money fields that you occupy. 
- Wizards will begin to spawn 10 seconds after you occupy a money field.
- Per field, there are 3 tiers of spawning speeds (10/20/30 seconds). Each 2 wizards increases spawning speed by 10 seconds.
- These infantry units effectively replace secondary economy - They will earn you $5/second

----------------------------------------
   TECHNICAL NOTES AND FUNCTIONALITY
----------------------------------------

- Most buildings cannot be built on Money Fields. Only small structures like defences.
- Ground units inside chinooks are still treated as ground units to activate money fields.

----------------------------------------
   MAPPER NOTES
----------------------------------------

- Money Fields use the AsianFarmer objects to apply the fog effects. Damage is applied to change the effects.
- Sandbag objects are placed on the fields to prevent buildings being placed on Money Fields.