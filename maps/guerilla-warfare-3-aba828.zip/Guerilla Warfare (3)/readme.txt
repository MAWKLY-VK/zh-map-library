MAP ::  GUERILLA WARFARE

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1vs1

STYLE :: ABSTRACT ISLAND [AFTERNOON RAINSTORMS]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* Custom Color Water added.
* No CITIES, just a MAX Elevation Mountain.
* Hovercraft await capture near an abandoned section of the Island.
Use your FREE CRUSADERS WISELY -- Attacking might be RISKY!!!
* BUILDINGS have been ALTERED to increase HP's.

=========================================


WWW.FASTGUILD.COM


=========================================