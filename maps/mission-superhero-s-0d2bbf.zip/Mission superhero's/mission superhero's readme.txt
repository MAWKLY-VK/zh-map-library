*********mission superhero's readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        mission superhero's
Created by:  snowy007
Players:     1 player




installation:
--------------

unzip and put the folder in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

this is a 1 player mission. the gla have taken over a chinees base. your main objective will be to recapture the chinees 
base from the gla. you will have collonel burton, black lotus and jarmen kell at your command. the chinees base is havily
defended. find a way to disable the base defences. when you entered the chinees base you must destroy the propoganda towers
and the internet center. all other buldings you must capture with black lotus. note: you only need to capture 5 power plants 







