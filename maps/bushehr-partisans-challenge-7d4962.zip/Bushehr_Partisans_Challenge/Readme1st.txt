Bushehr: Operation Partisans' Challenge V.1.5
=============================================
A C & C Generals Zero Hour single player mission (tested on ZH version 1.04)
by Beng, June 2006

Author & Version: Version: 1.5, June 2006, by Beng.

Copyright: Feel free to distribute this map, modify it, borrow code from
map.ini for your own maps, do whatever you like with it. But if you make
changes, please note them down in this or another readme file.

Scenario: The Americans have invaded Iran and have captured the coastal
city of Bushehr. The GLA only have a few buildings left in a small base and
no room to build more, but they have some new secret weapons up their sleeve.
Read also:
http://news.bbc.co.uk/1/hi/world/middle_east/4895212.stm


Features: Waves, new units with new abilities (using some of EA's unused models),
new special powers, naval warfare, cut scenes, new special effects.


Updates in Version 1.5
----------------------
Thanks to some feedback from DeadDrone i decided to make some changes to make the map
more challenging. I also made a lot of other modifications along the way. I can't
all the changes i made but the fact that the map.ini file has expanded from 9006 lines
to 14,144 lines of code should give you some idea of the magnitude of the changes.
The map itself has also been changed to make the Americans have more advantages. I
think this makes the map more challenging and fun.

Some of the changes:

* The bug that caused saved games to crash when units were inside a hovercraft has been fixed.

* The bug that caused saved games to crash when the Crop Duster was piloted
by a kamekaze frogman has been fixed by making it non-pilotable by such units.
Instead it comes ready to fly. You just have to drive it along the horizontal road
near your base, towards the arty platform, to take off.

* GLA boats given a bit more health.

* US missile gunboats now can make 2 smart torpedo-mines. Use the Hellfire drone
button to make 2. When they have been used up the parent boat can make more.
They appear in the hold as passengers and you make them exit to use them.
You can command them to attack enemy ships or to guard areas. For attacking
large ships it is best to make them swim under the ship and manually detonate
them as their magnetic proximity fusees may explode them prematurely otherwise.

* New special powers added. In addition to the Partisan ambush, when you research
the nuclear missile and recapture the nuclear facilities intact, you can now get
2 new special powers. The Black Market Nuke Drop is an air-dropped nuclear bomb.
You can drop one every 5 minutes. The EMP Nuke Strike calls in a special fighter
that launches a cruise missile nuke that has a large EMP effect, this recharges
every 3.5 minutes. The USA side have their own superior versions of these powers
which they will use if you still own the battleship after theirs is sunk.

* THe USA gets a new fighter aircraft, the Atomic Aurora. This launches two
sea-skimming atomic cruise missiles which also have a small EMP pulse effect
similar to Superweapon's Patriots. You may get to experience this plane if your
battleship lives long enough and the US airfield is still there. This plane has
been optimised for the anti-ship role so it has a low altitude flight profile.

* The unmanned battleship has been made harder to salvage. It also becomes
nearly impossible to keep it once the US gets determined to sink it. You still
can use it if you are clever, i will leave it to you to devise a strategy to
do so.

* The Aircraft carrier and US boat factories now have point defence lasers
capable of shooting down the battleship's shells. Avengers can also do this.
The aircraft carriers get 2 gattling turrets and a laser turret to better
defend themselves.

* Cargo planes have been improved. The GLA's has slightly better health,
an ECM suite, and a dorsal gunner who fires a machine gun at any nearby
enemy units. The US C-130 has been upgraded to something resembling AC-130
Spectre standard. This should encourage you to capture the reinforcement
pad as soon as possible once it appears. The US B-52 now sports an
air-launched tomahawk cruise missile. The B3 Spirit has a self-defence laser,
you only see this when the US uses its nuclear bomb. The cargo planes also
eject crew when shot down.

* The GC_Stealth Battle Bus has been fixed. You now get these bus types.
They can be disguised like bomb trucks. This should help you transport the
rescued POWs with some added safety. It comes with a laser target
illuminator.

* There are other cosmetic and gameplay changes, you will have to play
the map to see them.


Reference: Nuclear Weapon Yields
--------------------------------
numbers mean primary damage for radius, secondary damage for radius

NukeMissile weapon: 2 Used by Iranian nuclear Cessna: 300 for 75 from the weapon itself
medium radiation field

StealthJetMissile: used by USAF Aurora, 2 wingtip-mounted sea-skimming cruise missiles: 600 for 25, 400 for 50
(DemoTrapDetonationWeapon). medium radiation field + SupW Patriot missile's EMP effect

CINE_ScudMissile (SLCM from submarine): 300 for 50, 50 for 100 from the weapon itself,
then ChinaPowerPlantDeathWeapon 400 for 50, 50 for 100, ie:
totals to 700 for 50 and 100 for 100; medium radiation field

AirF_AuroraBomb (tomahawk style cruise missile mounted on hardpoint under left wing of special power
F-15 strike eagle): 2 for 4 from the weapon itself, then SupW_FuelBombDetonationWeapon deals
900 for 70; medium radiation field + large EMP pulse (same as for China's EMP bomb)

Nuclear Cessna suicide: DaisyCutterDetonationWeapon 1000 for 100, then
Demo_ScudStormDamageWeapon 600 for 75, 150 for 200; large radiation field

BlackMarketNuke (parachute delivered from GLA's bomber): 2000 for 150 (similar to MOAB),
large radiation field

SupW_TomahawkMissile, used by American Nuke Drop (air dropped bomb from a B3): 
3500 for 60, 200 for 210 (only slightly less than Chinese nuke ICBM whic does 300 minimum damage)
large radiation field


Known Bugs:
-----------

When loading saved games, the ocean waves disappear. Can't fix that.

Sometimes saved games will crash the game. Save often in different slots so
that hopefully an earlier saved game will work if the most recent one crashes.

Even when saved games load, the battleship fire to target units command
(artillery icon) will not work, only the fire for area effect (battleship icon)
will work.

When building the new units like Partisans, you need to have enough cash but
then the money is not deducted from your account. Again i cannot find out
how to fix that.

Also, i tried to limit the number you can build to 4 of each type of partisan
but if there is space in your build queue you can build up to 9 or more if
you keep pressing build, until 4 are built. So if you are quick you can build
up to 11 or 12.


Installation:
-------------
Unzip and put the folder named "Bushehr_Partisans_Challenge" in your map folder, usually:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

Start Zero Hour, go to Skirmish, Select Map, Unofficial Maps, and load the map.


Strategy Tips:
--------------
The in-game instructions are important. Periodically review them by pressing
the speech bubble icon to see briefing text.

The first objective is to protect your base and sink the 2 nuclear aircraft
carriers so that the US boatyard will stop building naval attack teams.
First of all send Jarmen to snipe the garrisoned buildings along the nearby
coasts that will sink any of your boats that go too far out.

If a nuclear submarine appears you must sink or snipe it as soon as possible or
it will destroy your base.

Buy the radar scan upgrade ASAP so you can find the nuclear submarine when it comes.

If all your partisans die or your base is destroyed you lose.

Use kamekaze frogmen to take over sniped boats on the water that land based
infantry cannot reach.

Your militia tanks will be reinforced by air if destroyed, each costing $800.
These tanks have anti-missile lasers and toxin nozzles for clearing buildings.

Your battle bus will be replaced by air drop in the same way, cost $2000 for 2.
Units inside a train can only fire from the train if they are also
inside a battle bus or humvee.

For fast cash use some gattling girl partisans to cash hack the nearby supply centre.

You can build 3 different boat types from your boat factory. The junk is good
against raptors, the toxin tugboat has a missile jammer so it can go near to
coastal bunkers or enemy boats (and then maybe detonate it as a bomb).
The missile trawler has long ranger missiles. None of them are much match against
US missile boats except when used in a suicide mission or in a group.

The repair pad can repair land and sea vehicles. The junk repair upgrade also helps.
When junk repair is purchased, missile gunboats can repair nearby units
(like ambulance).

When you clear the triangular road area near your base of all US forces including
demo traps and the artillery platform (kill or capture it), a toxic crop-duster
will be supplied. Use a kamekaze frogman to pilot it. It costs $2000 to replace.
When shot down the frogman will bail out. Use him as a terrorist then.

When attempting to rescue the prisoners, do not send heavy weapons dudes or
toxic crop-duster planes as these have area effect weapons that may accidentally
kill the prison inmates whilst shooting at the prison guards.

Amongst the prisoner is one unique guy who is a nuclear scientist, the in-game
briefing will give you more details.

If the scientist is killed, if the american dud missile is lost, or if the nuclear
power station buildings are not captured intact, you can still play the game
but will not have access to the nuclear kamekaze plane.

Like the crop-duster, the nuclear kamekaze plane must be piloted by a frogman
to fly. If you buy the missile upgrade it then holds 2 mini nuke missile that
you can fire before pressing the suicide button to detonate the plane.

Be careful not to destroy the nuclear power station in the city and the buildings
in its compound, you may need them. Again keep heavy weapons dudes away from it.

Save at least one generals point to use to purchase the new special power:
GLA Cartoon Drop. You get this from one of the buildings you will garrison if you
follow the in-game instructions. This power, once purchased, can be triggered
from your palace. It calls in a cartoon bomber which air-drops infidel cartoons
on an area of your choice. The Americans will stop to read the cartoons but
the local people will be incensed and rise up in rebellion against them.


Other maps by Beng:
* Guantanamo Bay: Operation Cuban Freedom
* Super Units
