Civilian and GLA units implementation notes for Zero Hour map makers
by Beng, June 2006
--------------------------------------------------------------------

The map.ini file in this folder is to configure the following units that have not been
properly implemented and are therefore not used in Zero Hour. There are yet more
unused units than can be implemented in the future including some Chinese infantry models
(NI*.W3D). Not all the features of the map.ini are documented here, but this gives you
some idea:

Located under Civilian units in World Builder:

All Partisans are stealthed when not firing, and have 400 health which means it takes 2 shots
from a Pathfinder or a Jarmen to kill them. They have Infantry General's armor which is slightly
more resistant to radiation and toxin than standard human armor. It costs $1500 and 15 seconds to
build them if you add building ability to any buildings.

Partisan01 - Guy in a hoodie packing 2 machine pistols
I've given him the quad cannon's weapons after it has 2 salvage upgrades.
He also has Demo Kell's C4 charges

Partisan02 - Guy in a hoodie with a single shot gun
I've given him the firebase howitzer and black napalm canon, you switch between them using buttons.
He also detects stealth up to 200 feet (same as sniper) and can do so when in buildings or vehicles.

Partisan03 - Girl packing a machine gun
I've given her gattling canons (the same as the China base defence building)
She also has Lotus capture building and cash hack abilities

MilitiaTank - a small tank with a round turret
This now has the starting marauder tank gun and the toxin general's tunnel netowrk gun,
and a point defence laser effective against missiles. It also benefits from junk repair
upgrade and no longer tries to shoot through buildings and hills.

CarSUV01Nuke - changed this into an all-terrain skidoo that moves on water, cliffs and land, and
shoots Missile Defender laser missiles and combat bike machine gun. Unlike GLA's bike this can
shoot whilst on the move as it has a turret.

CINE_TrainEngine - If you put this on your map it automatically generates some carriages
behind it that can be garrisoned with units, and also an exploding oil tank carriage.

CivilianVehiclePTBoat - Now packs a cruise missile launcher and a rocket barrage to attack land targets and comes with a crew of 3 toxin stinger soldiers

Other Civilian Boats militarised: all have bomb truck detonation plus other weapons, and
new damage and death effects:

BoatAsianFishing - has a gattling gunner

BoatFishingTrowler - has a patriot missile gunner

BoatTugboat - has a toxin network gun and stinger SAM and ECM missile jammer

Located under GLA Vehicles in World Builder:

GLAVehicleDozer - A strongly armoured  dozer that only repairs buildings, doesn't build anything
or clear mines You can put this in cities and towns on the PlyrCivilian side and it will repair
damaged buildings within a radius of 200 feet. Useful for keeping towns from being destroyed too fast.


Located under Stealth infantry in World Builder:

GC_Slth_GLAInfantryJarmenKell - Generals Challenge Stealth Kell with garrison sniping ability
and faster firing sniper rifles than the standard Kell. He now shoots his garrison sniping
weapon from his gun instead of his feet and it has new special effects.
He can use Demo Kell's C4 charges if you edit the map.ini and change his CommandSet but
by default he does not as the Partisan01 has those abilities.

I made GC_Slth terrorist to be an amphibious unit that can plant TNT charges, build demo traps
in water, and run faster when you buy the worker shoes ugrade.


Others:

For this map i also made the lazer general's supply centre build hovercraft (which collect
supplies and have a laser), and his war factory build missile gunboats and all terrain skidoos.
The GC_Chem war factory builds the GLA boats, and the GC_Slth barracks builds the partisans and
naval terrorist. I made some improvements to the CINE_AircraftCarrier to make it easier to target
in the game and to have damaged smoke. There are various other changes which you can find out by
reading the map.ini file.


V1.5 additions
--------------
GC_Slth's battlebus fixed and improved

Crop Duster made non-pilotable by terrorist - crashes saved games.

Hovercraft fixed. No longer crashes saved games when units are inside it.

Some buildings strengthened.

AirF B52, AirF B3, and AmericaJetCargoPlane and GLAJetCargoPlane given weapons which they
will use as they fly past from dropping off crates or whatever. Some also eject crew
when shot down.

Torpedos now air drop into the sea properly.

2 new special powers added, and GLA and USA have different versions of each.
Nuke Drop and Black Market Nuke have been combined into one working special power
which can be purchased from a valve station (in the game it is granted to the
player by a script). Napalm Strike becomes EMP nuclear strike. Special F-15E
(MiG model) delivers EMP nuke cruise missile.

AirF Aurora has atomic missiles and new flight profile.

Aircraft carriers have self defence guns and lasers

Laser General's supply centre and war factory have anti-shell and anti-missile lasers.

Avengers shoot down shells.


Installation:
-------------
Put the map.ini file in the samne folder as your map, then you can add these units to your map
and they will work properly.

If you already have your own map.ini file there, just copy the contents of this one and paste it
into yours. You can customise it by changing bits of it or leaving some bits out. For example the
building of the new unit types has some bugs including the non-deduction of cash when you build them
so you may wish to leave out the bits about command sets for buildings to build them and just
place them on the map using world builder or scripts.
