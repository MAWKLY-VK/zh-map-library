This map is a very interesting map.
In the middle parts of the map are various types of vehicles to capture and use against your enemies before they use them on you.It also has the rvmech ahai which makes it a great map for skirmish play against the comps. It is a 400x400.
With the time of day set to morning.Lots of room to build and plenty of money.Each base has 2 oil derricks and 2 supply depotsand 1 refinery,more supply depots are on the map as well as oil derricks.
Have Fun.!!!
