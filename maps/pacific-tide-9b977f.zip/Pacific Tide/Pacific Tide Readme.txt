
Pacific Tide (ZH) (a SP mission for C&CG Zero Hour)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________
	
	Welcome General,

	Your mission is to elimnate any GLA forces in the pacific region.

	You can land forces on the beaches when GLA defences are removed from them.
	For this mission you have control of 2 destroyers and 1 aircraft carrier.

	Mission Objectives:

	1. Destroy all GLA coastal defences
	2. Eliminate any GLA forces

	* All GLA forces must be destroyed
_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Ambient sounds set mood
	- Temperate Environment
	- AI trigger attacks
	- Scripted timed attacks
	- Waves
	- Clear objectives
	- Advanced tehnology of the Americans
	- Time set to afternoon
	- Pacific theatre
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint 1: Grouping

	Grouping units (i.e Ctrl-1, Ctrl-2 etc) gives quick access to units or teams
	that you need to command often. Grouping takes little time to do and will help
	your reaction time since you don't need to look around the battlefield.

	Hint 2: General Points

	Use your points wisely and spend them on abilities that help you achieve the
	mission.

	Hint 3: Be offensive

	Be aggressive in this mission use all of your unit in effective attacks.

	Hint 4: Be in control

	Control is key to any mission. Know how many units you have, how many units
	your enemy has, control the mission by attacking their weaknesses.

	Hint 5: Get intel

	Intelligence on the battlefield is gold! Use your intel based abilities
	to scout your surrounding (to see through the soup [as EA say]).
 
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

Pack of Ten [Map Pack #3]

	Communication Breakdown (ZH) SP MISSION @ cncden.com
	Sudden Strike (ZH) SP MISSION @ cncden.com
	Cobra Cell (ZH) @ cncden.com
	Level Playing Field (ZH) @ cncden.com
	Snow Storm (ZH) @ cncden.com
	Survivor (ZH) @ cncden.com
	Mountain Valley (ZH) SP MISSION @ cncden.com
	Prisoners of War (ZH) SP MISSION @ cncden.com
	Rockets in Russia (ZH) SP MISSION @ cncden.com

NOTE: All my maps are available from my website, DK Online and some from genmaps.com

-------------------------------------------------------------------------------------

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour mission was created by Dean Krause on the 23rd of February
2004. This map is copyright Dean Krause 2004.