@@@@@ Genome's Base War 2v2 @@@@@
=============================================================================
Map has a river in the middle, 2 bridges that are
the only way to get to the enemies base (not including
air units) And lots of cash + oil. Artillery platforms in the center
of the map are indestructable and so are each player's oils. Alot of space
to build.

Copyright 2004 to Genome852 and all that other stuff.

Good luck General ^.^
=============================================================================