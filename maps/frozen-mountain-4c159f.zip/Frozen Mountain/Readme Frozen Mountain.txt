

Readme f�r �Frozen Mountain�


Map-Daten: 
Map Name: Frozen Mountain
Map Author: RedBasti
Author's E-m@il-Address: RedBasti@team-gamestar.de
Released: 23.07.2003
Map Size: 460x460
Players: 4
Time: Afternoon
Terrain: Snowy
Skirmish Compatible: yes


1.	Screenshotbeschreibung
2.	Kartenbeschreibung


�Frozen Mountain� wurde f�r die Teilnahme am Map-Contest an Planet Generals gesendet.
Screenshots der Karte sind in der Datei �Screenshots.zip� zu finden.

1. Screenshotbeschreibung:

1: 2 KI-Gegner bek�mpfen sich gegenseitig in einem der kleinen Vororte.

2: Basis eines KI-Gegners im Aufbau. Die KI-Gegner bauen sich wie auf dem offiziellen General Karten auf.

3: 2 Sniper sichern die Br�cke an der rechten Seite der Karte. Auf der anderen Seite der Br�cke wartet der Feind.

4: 2 KI-Gegner treffen in einer der h�heren Regionen des Berges aufeinander

5: Karte im Editor.

2. Kartenbeschreibung:

"Frozen Mountain" ist f�r 2vs2 Gefechte ausgelegt und stellt eine Winterlandschaft dar.
Ein Team startet am oberen Kartenrand und eins am unteren.
In der Mitte der Karte befindet sich ein Berg, der in mehrere Stufen unterteilt ist.
Auf einigen der Stufen sind Rohstoffe oder kleine D�rfer zu finden.
Rechts und links vom Berg werden die Teams von einem Fluss getrennt, �ber den eine breite Br�cke f�hrt. 
Das besondere an der Karte ist, dass es extrem schwer ist sich einzubunkern.
Der Spieler wird dazu ermutigt fr�h Au�enposten zu errichten. 
Die eigentliche Basis hat 5 Eing�nge, allerdings kann man durch ein schnelles Vorr�cken die Anzahl der Eing�nge reduzieren.
Allerdings muss der Spieler dann �ber ein gr��eres Gebiet wachen.
Flankenangriffe sind daher gut durchf�hrbar. Auf dem Berg selber haben alle Parteien gute Chancen.
Die USA k�nnen durch ihre Flugzeuge schnell agieren und die Klippen �berbr�cken. 
Die GLA kann durch ihre Tunnelsysteme schnell Nachschub heranziehen und China kann seine Feuerkraft 
auf kleinen Ebenen voll ausnutzen. Die Karte ist symmetrisch und garantiert somit ein faires Spiel. 
Auf die 4 Spieler kommen 8 (jeweils 30.000 Credits) Nachschublager, 2 �lpumpen und 4 kleine Lager im Wert von ca. 11.000 Credits.
Die KI baut sich komplett auf (inklusive Superwaffen) und f�hrt auch gr��ere Angriffe gegen den Spieler
und andere KI-Gegner durch.




