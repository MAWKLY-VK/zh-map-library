:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Close Quarters"
[File Name]    = 006-Close_Quarters.map
[File Size]    = 96 KB
[Map Size]     = 328 X 210
[Players]      = 2 only
[Time Setting] = Noon
[Field Intel]  = Urban
[Resources]    = High
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Red Eagle Alliance HQ
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

General, it is good for you to come here on such short notice. 
We have a dangerous situation developing nearby in Edmonton.

A GLA sect just became active a few weeks ago over there.  Our 
agents were able to thwart most of their efforts, but the GLA 
were able to steal a few dozers from some of the supply depots. 
We have to face the possiblity that by the pattern of what was 
being stolen, we believe that they might establish base and take 
over Edmonton.  We fear that with the supplies they have on 
hand, they'll go with their plan soon.

We don't have much time.  You'll have to match them move by 
move.  Establish a base and rid the threat as soon as possible. 
Even with the possibilty that the city will take heavy damage, 
we can't risk using superweapons in the area.  Nevertheless, 
this kind of stuff isn't new to you, so we are counting on you 
to save Edmonton from the GLA... before we have a huge disater 
on our hands.

  //--[ Red Eagle Alliance HQ        ]--\\
 |A|--[ Fort McMurray, Alberta       ]--|A|
  \\--[ ** Head Canadian Division ** ]--//

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Superweapons are banned in this area.
:: The only thing that seperates you and the enemy is a river. 
   There are only two bridges that cross it.
:: The distance between you and the enemy is quite short.  You 
   must act quickly to set up defenses before the enemy crosses 
   the bridges.
:: Agents report of suspicious houses that have an illegal 
   stash of drugs.  If you can wipe out the house, you'll have 
   access to its huge money stash.  Use this info to your 
   advantage.
:: Beware of busy traffic.  Cars can run over our infantry.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@att.net
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================