README
C&C Generals ZERO HOUR

Map Name: Island Battle
Map Author: Splitter
Email Address: splitter@fsmail.net
Released: 6/9/04
Players: 4
Skirmish?: Yes

Description: My first attempt at a map. A fairly simple island design with one starting supply depot with one to fight over between players. Also contains 4 oil derricks and a refinery. It's also set up for skirmish players. Great fun!

Installation:
Simply copy this folder and paste it in: C:\Documents and Settings\My Documents\Command and Conquer Generals Data\Maps