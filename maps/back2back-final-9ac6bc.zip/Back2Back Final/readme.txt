Map Name: Back2Back Final
Map Author: Dragonne
Author's E-Mail Address: Dragonne@ClanTriad.net
Released: 10/13/2003
Map size: 300x400
Players: 4
Skirmish Compatible: Absolutely

Map Description: A simple map, with a lot of land for building. The theme here is two teams on either side of a large mountainous ridge.
Early attacks may come from around the sides, but watch for the major hits and sneak attacks coming over the mountain. A good map for
turtlers, but a good solid rush can do wonders as well.

Extra Comments: It's quite a large map for 4 players. There was an occasional slow down during testing, but it did tend to speed back up
after a few minutes.

Directions for Installing: To install this map simply extract the contents of the downloaded .zip file to your \My Documents\Command and
Conquer Generals Zero Hour Data\Maps\MAPNAME folder on your hard drive. The MAPNAME will of course be the name of this map.
