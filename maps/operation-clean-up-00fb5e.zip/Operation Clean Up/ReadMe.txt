HOW TO INSTALL:

1. Paste the "Operation Clean Up" folder into your Generals save folder in: Desktop - My Documents - Generals Zero Hour Data - Maps 
2. Play the mission in Skirmish mode, Unofficial Maps

- To make the video more fun, don't move the camera until it zooms out for your control
- Press F9, it make it better to watch

ENJOY!