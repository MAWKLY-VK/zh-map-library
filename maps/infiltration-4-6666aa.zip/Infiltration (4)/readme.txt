MAP ::  INFILTRATION

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1vs1

STYLE :: ISLAND MIGRATION [NIGHT THUNDERSTORMS]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* DIFFICULT ISLAND WAR
* Many ways to win...Carrier is MOST dangerous.
* Use Anti-Air if ENEMY captures the Carrier, then RE-CAPTURE it from him.
* Nuke Trucks exist so be CAREFUL !!!
* Other factors exist, such as Amphibious Craft, PT Boats, & Battleships!!!

=========================================


The FINAL MAP created for "A.I. ONSLAUGHT" 30 MAP PACK !!!