MAP ::  Frozen Falls

AUTHOR :: WACKWARDS

PLAYERS :: 2vs2

STYLE :: Symetrical

AI :: SDI TEAM

ONLINE READY :: YES

INFO :: 

* The carefully designed WATERFALL gives this map it's name.
* Fight thru a small quiet town in this Snowing, night map.
* Influenced by Snowy Tracks Map -- Nice map also !!!

Details ::  

* The Snow is falling lightly in this Night Alpine Assault Map
* One large river ends in a Waterfall splitting into 2 canals, with a Train tunneling thru the river.  
* A small Alpine Village exists for garrisoning as well as a small Toxic Industrial Park.  
* Hidden Cash & Tech Buildings are balanced for even play.
* The AI is very aggressive and garrisons well, even grabbing up money and crusader crates.
* The Train is very dangerous in the North, with Toxic Hazards to the South
* The GLA Supply Depot adds a twist to the map as it allows for GLA Building for the captor.
* Designed for ONLINE compstomps and Team Games.
* TESTED 2006 - Passed very well in 2 humans VS. 2 CPU.

