Name: Mickey
Author: MadTaz90
Game: Generals: ZERO HOUR (Expansion) 
Size: 350*350
Climate: ????
Players: 3
Type: Skirmish Mode (AI) and Multiplayer Online

Description:  Each player is separeted on an island with good buldspace.
on each side is a brige leading to some oilderics and in the center is more money trying to get it.
Ai makes good work.
Build for fast game play.

Good play and have fun
Markus"MadTaz90"

