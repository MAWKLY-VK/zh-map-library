You Have Downloaded a Generals Zero Hour Map:                           No Mod Problems yet
           Chokepoint Chaos
            by. sgtmyers88
DO NOT EDIT THIS MAP WITHOUT MY PERMISSION!



To Gain Access: 
extract, copy, and paste the Chokepoint Chaos files in the Generals Zero Hour map data Directory.

Problems/Bugs:
None

OVERVIEW: This map can have 4 players in skirmish or multiplay
the map has a unusual shape you will be battleing through a four way canyon, and at the ends of the canyons
is where the bases are, there is sufficent room and supplies and there are some tech buildings.

SPECIAL NOTE: I added another piece of humor that I 
dont want to have people take as a threat, it just relates to the maps unusual topography.
(i.e. don't choke to death)

Suggestions, questions, and comments you can send me via email or instant messenger at sgtmyers88@yahoo.com

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!

GOOD LUCK AND HAVE FUN!!!

2005 sgtmyers88