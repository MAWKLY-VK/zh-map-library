You Downloaded a Generals Zero Hour Mission:                    Good with: ZERO HOUR REBORN MOD
            "Blasting to safety"
               By. sgtmyers88
    DO NOT EDIT THIS MAP WITHOUT MY PERMISSION!!


        Shizu Tank Column
 -----EMERGENCY TRANSMISSION-----

SHIZU SQUAD LEADER: GENERAL!... WERE BEING ATTACKED!!!
    Several units lost... GLA out numbering us... we need your assistance!

EVA: Comrade General, our forces in the China/Kazakhstan Border have ran into superior 
GLA forces and possibly a base. General You must help these forces survive the onslaught 
and reach our allies across the border. YOU DONT HAVE MUCH TIME, YOU MUST GO!

-----END TRANSMISSION-----


SGTMYERS88: General, EVA is correct, you dont have much time, I shall instruct
you on getting to the battlefield and establishing battlefield control ASAP.
The men in this tank column entrust your experience and tactical skills.
	To access battlefield: extract, copy, and paste the Blasting to safety files to your 
Command & Conquer Generals Zero Hour Directory.

Basic info:
	General the Squad Leader is in his Trademark Tank "The Emperor" its a 
advanced overlord concieved and manifactured by the well known General... General Kwai.
 OBJECTIVE: Save as many men as you can and try to knock out the GLA Base if
 they are not too strong.
	Then head into the mountains to EVAC ZONE.



BUGS/Problems: none detected 
If you encounter one let me know ASAP and i will fix it ASAP
You can use it with MOD: ZERO HOUR REBORN you can use other mods but it
may screw up the mission and/or crash the game.
This Mission isnt too bad on memory and graphics. (i.e. lag, skipping, etc.)

Place a question, comment, suggestion, or other information relating to Command & Conquer
and/or my maps at sgtmyers88@yahoo.com using e-mail or instant messenger.

August 2005 THIS MAP AND RELATED FILES WERE MADE BY SGTMYERS88
YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!!
EVEN THE COMMAND & CONQUER GENERALS ZERO HOUR GAME YOU PLAY IT ON IS NOT YOURS
Command & Conquer, Command & Conquer Generals, Command & Conquer Generals Zero Hour EXPANSION PACK are all 
property of WESTWOOD STUDIOS AND EA GAMES.
2003 WESTWOOD STUDIOS and EA GAMES 
the EA GAMES and WESTWOOD STUDIOS logo are registered trademarks and are of
an electronic arts brand.





  