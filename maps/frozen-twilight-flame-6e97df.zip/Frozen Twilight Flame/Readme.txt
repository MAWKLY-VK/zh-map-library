Maker:Ground Demon
Author:Unknown(who made CnC Twilight flame map to begin with)
NOTE:
If there are any problems please Email me
Milnr12@hotmail.co.uk

---Install Instructions----------------------------------------------
To install simply put Frozen Twilight Flame Folder in this 
directory:
My Documents\Command and Conquer Generals Data\Maps

Basicly all of the credits go to me apart from the actual 
making of the original map.

---Credits------------------------------------------------------------
All of the new scripting and base layouts was done by Ground Demon,
The original map was done by EA,
 I would like to give a Special Thanks To Drummin for pointing out my design flaws at the begining.
----------------------------------------------------------------------
I hope you enjoy my map, try 2 vs 4 brutal AI`s- IT`s HARD!
-Enjoy ;)