ReadMe_English

This is a 2vs2 map, i spend more than one week on !
There are two supplies ans two oils in each base.
There are two oils and one hospital in the town.
Try to destroy the big power plant in the town :) (100 auroras).
The action is in night while it's raining and lighting.
A very hard AI, so noobs don't play in Hard ;)

Thank you for downloading my creation !

PS : Don't forget to visit our site :
http://www.gam.ht.st

[G@M]ReYdEn




ReadMe_Fran�ais

Voici une carte 2vs2, j'ai pass� plus d'une semaine dessus !
Il y a deux r�serves et deux derricks dans chaque base.
Il y a deux derricks et un h�pital dans la ville.
Essayer de d�truire la centrale nucl�aire de la ville :) (100 auroras).
L'action se passe dans la nuit pendant qu'il pleut ete qu'il y a de l'orage.
Une IA tr�s d�vellop�e, donc novices ne jouez pas en Difficile ;)

Merci d'avoir t�l�charg� ma cr�ation !

PS : N'oubliez pas de visiter notre site :
http://www.gam.ht.st

[G@M]ReYdEn