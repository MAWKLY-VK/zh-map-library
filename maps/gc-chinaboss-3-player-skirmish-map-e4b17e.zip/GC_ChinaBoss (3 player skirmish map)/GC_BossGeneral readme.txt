*********GC_ChinaBoss readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        GC_ChinaBoss
Created by:  snowy007
Players:     3 players




installation:
--------------

unzip and put the folders in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

the official Boss General map of the Generals challenge. i made a second 
enterence to the base at the bottom of the map. also i made an other route
to one of the bases at the top. (its very hard to find becouse you can't 
see it) 







