******
INDEX
******

1. MAP DETAILS
2. STORY LINE
3. INSTALLATION & LOADING NOTES
4. WORDS FROM THE DEVELOPER
5. ACKNOWLEDGEMENTS
6. ACTIVATE/DEACTIVATE IN GAME SNOW WEATHER


****************

1. MAP DETAILS:

****************


Map Name:         Nuke Star Meele
Map Type:         Single Player Mission
Map Platform:     Command & Conquer Generals: Zero Hour (ONLY)
Map Theatre:      Snowy Mountains

Map Developed by: RobinS Always (robinsCNCgenerals@yahoo.co.in)

Created on:       Tuesday, 23rd of May 2006

Special Thanks: 	
1) EA Games (for the astounding Command & Conquer: Generals / Generals Zero Hour game)
2) RVMECH (for Snow Weather Effect)
3) Headcracker, for Background music, and
3) YOU, for downloading and trying my work.


**************

2. STORY LINE:

**************


You start as an American Laser General.

A renegade Chinese Nuke General wants to take over the world with his nuclear arsenal. He coordinates the launch of nuclear warheads from two control stations.

A rouge GLA Demolition General is also trying to capture the stations and use it against you, posing a considerable threat to your forces.

The mission objective is to capture those control stations before:
1) the control stations being captured by the GLA forces, or
2) being annihilated at the hands of the enemy.


***********************************

3. INSTALLATION & LOADING NOTES:

***********************************


1)  Unzip the contents of the file "Nuke Star Meele.zip" to "../My Documents/Command and Conquer Generals Zero Hour Data/Maps" folder

2) Start the Game Command and Conquer Generals Zero Hour.

3) Go to "SOLO PLAY -> SKIRMISH -> SELECT MAP -> UNOFFICIAL MAPS" and select "Nuke Star Meele.map"

4) Click "PLAY GAME" & Enjoy............


********************************

4. WORDS FROM THE DEVELOPER:

********************************


Dear All,

First of all, Thank you once again for downloading & trying my work.

This is my first ever attempt at developing a map for any game. I started with C&C Generals: Zero hour, because it fascinated me the most.

I have seen pretty work of various developers and am really inspired by the same and appreciate the amount of hard work and time invested in the making.

I�ll highly appreciate any feedback regarding my work.

I hope that my work is able to meets the gamers� expectations.


Thanks & Regards

RobinS Always
(E-mail: robinsCNCgenerals@yahoo.co.in)



*************************

5. ACKNOWLEDGEMENTS:

*************************


Cheers! to my wife and my parents for maintaining their cool during the map development.


**************************************************

6. ACTIVATE/DEACTIVATE IN GAME SNOW WEATHER:

**************************************************


Destroy the only GAS TANKER in the WEST of the map to activate/deactivate in game snow weather effect.


