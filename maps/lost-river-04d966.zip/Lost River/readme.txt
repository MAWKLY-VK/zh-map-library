This is a map of excellence. It is multilayered and features beatiful texturing, custom water color, and offers many strategic possiblities for any faction.

By NoVaCaiNE