
Black Squadron (ZH) (a mission for C&CG Zero Hour)
_____________________________________________________________________________________

Briefing
_____________________________________________________________________________________
	
	>>> BEGIN TRANSMISSION >>>

	Greetings General,
	
	5 Black Squadron pilots have been ambushed by RPG troopers and are being held 
	in seperate prisons in the city of Basra, Iraq.

	Col. Burton and a small team of US elite forces will be inserted into the
	mountain area of the region to rescue them.

	They will be malnoursihed and very paranoid, for this reason they will need
	to meet Col. Burton himself to be rescued and need medical attention. 

	When you have rescued a pilot patch them up with the medical vehicle.

	From our limited intelligence we can tell that the Black Squadron leader is
	being held in the urban center. The other Black squadron pilots have been
	taken to smaller prisons on the citys edges.

	Once you have rescued all the pilots bring them to the extraction point in
	the SW corner of the map (where you began).

	[There may be civilian forces that are willing to join your force for amnesty
	in the mountaineous towns]

	** If any of the pilots die the mission will be a failure
	** If any of the pilots are used to upgrade a vehicle the mission will be a
	failure

	** If Col. Burton dies the mission will be a failure
	** If the medic is destroy the mission will be a failure

	- Good Luck General

	<<< END TRANSMISSION <<<

	Breifing Summary:

	1. Recruit rebelious civilians in the mountain areas
	2. Rescue the 5 pilots from their prisons
	3. Bring all of the pilots back to the extraction point (marked with blinking 
	red lights)

_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Knifing

	Col. Burton has a stealthed knife attack that come in very handy in taking 
	out small patrols. They won't see it coming!

	Hint #2: Formation

	Formation of your small team can be the difference between a success and a
	disaster.

	Hint #3: Garrison

	Garrisoning a building can be a great way of being able to take more damage
	and still being able to attack effectively. But when doing this keep an eye
	out for units that can clear buildings out.

	Hint #4: Clearing

	Clearing the area before rescuing a pilot is vital since if the pilot is
	rescued and there are enemies around that could kill them off.

	Hint #5: Getting a lift

	Col. Burton can still capture pilots whilst in a vehicle. This can be helpful
	since this offers Col. Burton some protection. You can also place units in the
	Medic vehicle to heal them.

	Hint #6: Civil Assistance

	Many of the civilians in the region have seperated from the GLA fanatic cell
	and have started their own clans. They can help you in this mission quite
	effectively!

_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched an public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.  
_____________________________________________________________________________________

Notes from the author
_____________________________________________________________________________________

	This map may require a high end computer (depending on the type of graphics
	card you are using). You can tinker around with the graphics settings in the
	'Options' section of C&C Generals Zero Hour. 
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) @ cncden.com
	Wastegrounds(ZH) @ cncden.com

New Maps

	Mercury Falling (ZH) @ cncden.com
	

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour mission map was created by Dean K on the 9th of December
2003. This map is copyright Dean Krause 2003.