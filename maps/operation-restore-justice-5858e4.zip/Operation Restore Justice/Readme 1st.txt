Welcome to Operation Restore Justice' Challenge

This Is My First Map I made So Hope You Like It.

It,s All about the americans Taking Over The south Of China
Your Objective Is To Destroy 2 Aircraft Carriers
North Of Your Base..

Next Save your Friends From The Police Camp North East From
Your Position Rescue Them Then Go Back To Your Base.

Then Coming to your base Is A Nucler Sub Destroy It It Will Fire A
Missle At You It Will Malfunction You,s The Men You Rescued To Use 
There Tecnolagy Against Them.....

Then Just Destroy The American Base...