
Mercury Falling (ZH) (a skirmish map for C&CG Zero Hour)
_____________________________________________________________________________________

News Broadcast
_____________________________________________________________________________________

	This is a 1 on 2 map that is set in Winter. The lone player gets to start
	with closer access to oil derricks, slightly more supplies. 

	The purpose of this map is to see if two heads really are better than one.

_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Supplies
	
	Supplies are key to victory in this skirmish map, build supply lines early
	secure them. Check back on the condition of the supply lines and reinforce
	the ones that need help.

	Hint #2: Oil Derricks

	A constant cash resource is a great way of getting the edge over other
	players.After supplies run out the Oil Derricks really do help to keep your
	defensive and offensive lines stable.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched an public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.  
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Previous Work
_____________________________________________________________________________________

	Generals Zero Hour Maps:
	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) @ cncden.com
	

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

Notes from the Author
_____________________________________________________________________________________

	I was checking out some games online and was pleasantly surprised to find
	out that people where playing some of my maps :)

	In particular:

	- Minesweeper (ZH)
	- Mount Olympus (ZH)	

	I found out that some people are changing my maps and creating 'cheat maps'.

	This is a really bad thing since this stops people from wanting to play games
	with my maps in them. To ensure that you don't join a game a cheat map selected
	by the host, don't join games without people that you don't know personally
	or trust.

	- DEAN KRAUSE
_____________________________________________________________________________________

This C&C Generals Zero Hour skirmish map was created by Dean K on the 4th of December
2003. This map is copyright Dean Krause 2003.