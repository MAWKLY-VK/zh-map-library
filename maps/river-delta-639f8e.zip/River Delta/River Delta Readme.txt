River Delta
Skirmish for C&C Generals with RVMECH's AHAI-Script

Created by Starduster for Cncmaps.com


15/12/2003

----------------------------
2-player-temperate map. Several bridges crossing the arms of a river delta. 6 Supply docks. 9 Oil derricks, a hospital and a TechOil Refinery. 
Map Size: 400x425
Map Time: Early afternoon

The AI produces a lot of waepons in a very short time, so be alert.
A special is the activated battleship. It will be transferred to the player if he builds upgrades.
Local player USA:   Advanced training
Local player China: ChinaNuclearTanks
Local player GLA:   Toxin Shells

The battleship fires like a tank with both turrets. But be careful. It can be destroyed and it's impossible to build a new one.

---------------------------

All rights reserved. The map should be used for private purposes only. Publishing on other websites or in every other media is not allowed without permission.