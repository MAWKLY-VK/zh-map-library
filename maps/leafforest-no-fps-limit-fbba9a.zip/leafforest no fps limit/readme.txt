Save me.

MAP INFO:
------------------
Name: Leaf Forest (Previously was named: "SuperBuggyOverlord" and "SuperBoggyGoverlord v1.1")
Date Created: 11/4/2017
Made By: FireRainV
Email: youaredied1234@gmail.com

Last Time Modified: 19:43 5/4/2020 - (24 Hours Clock - D/M/YYYY)
This map was made with my love for Command & Conquer Generals Zero Hour.

If the map will ever be updated again (if the link isn't working, send me an email):
https://1drv.ms/u/s!AmkD3h0d2NSIgu8-dK0nbbvBPO0NKw?e=zC4xuJ




How to Play:
---------------------------------------------------------------------------------------------------------------
1) The map allows up to 8 players to play, but you can also play it by yourself.
   The starting place is too small but I'm sure you'll figure out what to do.
   (Tip: You can destroy the bio-weapon factory to increase the size of the map, but you'll need a lot of firepower).
   There're Supply Piles for each player (3 Players = 3 Starting Supply Piles), all worth 30K.
2) All players needs to be on the same team (No AI Players Needed).
   AI Players will "surrender" if being used, so you can play with as many armies as you want,
   but only your main army can use general powers (make sure to set all of them to your team).
3) The Objective is simple, eliminate any army who doesn't give you love back.
4) General Powers are unlocked overtime (You can't get xp from a civilian enemy).
   Because of the above reason, your units will never gain veterancy.
   I couldn't do anything about that without giving the players pilots in some way, which would only affect tanks and aircraft.
5) Setting the starting cash to $5000 will let you start with $ 99,999,999+ money.
6) Setting the starting cash to $10000 will start the game normally without the intro.
7) Setting the starting cash to $20000 will start the game on an even higher difficulty.
8) Setting the starting cash to $50000 will start the game normally with the intro included.
9) Getting Advanced Training will summon a Spectre Gunship that will auto-attack once.
10) Getting Cash Bounty will generate money overtime (As long as you have your GLA Command Center).
---------------------------------------------------------------------------------------------------------------



The CPU:
---------------------------------------------------------------------------------------------------------------
1) The CPUs are brutal, try your best!
2) On $20000 Starting cash as mentioned before, they'll start with even more money and...
3) The CPU will automatically capture the tech buildings when they bring a builder to the areas.
*) I couldn't use teams with civilian armies in skrimish, so this is a workaround.
   Originally, it was a singleplayer map that had so many things that couldn't work on skrimish.
   You would fight as a USA army with 3 other USA Allies, all starting at the same base.
   I know I could've used the civilian enemies just for the construction and a Skrimish CPU for the rest,
   but I wanted the map to support 8 players and doing it would break too much stuff because the world builder
   is a very buggy and missing a lot of featues and some things couldn't be done like in a singleplayer map.
4) The CPU will rebuild everything unlimited amount of times, unless they run out of funds.
---------------------------------------------------------------------------------------------------------------




About the Features:
---------------------------------------------------------------------------------------------------------------
This is the fun part of the map.
There are 7 of them around the map, some stuff needs to be destroyed in order to trigger them.
2 of them are just for the fun and they won't really help you, unless...
   List of all the features: (1) The Super Dozer, (2) The Overlord Boss, (3) The Magical Buggy, (4) The POW Truck, (5) Save the Worker,
   (6) The Money Troll and (7) The Soccer Thingy.
*) You will get the good ending if you get all the 3 main features active which are the first 3 in the list and keep them all alive before finishing off your enemies.
   You can park your Magical Buggy next to the spawner to prevent the spawned buggies from hunting.
*) The pixel art to the left of the players' base is "Cream the Rabbit" from Sonic Advance 2, the map was
   also renamed to the first zone from that game.
---------------------------------------------------------------------------------------------------------------





Good Luck & Have Fun!



















Load me.