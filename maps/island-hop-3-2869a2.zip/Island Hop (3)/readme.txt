MAP ::  Island Hop

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1vs1

STYLE :: ABSTRACT [AFTERNOON]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* CORRECTED Battleship Access, 2 or them were impossible to walk into.
* Custom Color Water added.
* The Islands are set-up evenly, but NOT symetrically.
* There are 3 KEY Islands that have a BIG impact on the game.
* This map is geared to FORCE Amphibious Landings.
* The A.I. is NOT set-up to utilize the NAVAL UNITS...as of initial release.
* LAST MAP to be added to the PACK...replaces STRONGHOLDS MAP which was prone to SYNC ERRORS.
* "Object" count is slightly over 500 objects...the map should run VERY smoothly.
=========================================


...MORE MAPS AT WWW.FASTGUILD.COM
