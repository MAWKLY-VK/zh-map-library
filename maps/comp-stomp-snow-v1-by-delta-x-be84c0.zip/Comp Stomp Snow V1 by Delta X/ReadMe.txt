Welcome to Comp Stomp Snow V1

This Map was created by Delta X And if you wish to edit or submit this map to other websites you will need my OK so E-mail me at Darkmagezolo@aol.com

Brief Description: this is a comp stomp map.  play this map by setting up five hard computers in the top above the river and three players along the bottom then play the game.
it has four bridges from which the computer attacks from. this map has snow and has a snow scheme

Installazation:

1 extract the file
2 coppy the file
3 paste the file in your command and conquer generals zero hour data/maps file
4 go to zero hour and play the map

I hope you like the map ;)
If you have any questions e-mail me at my e-mail listed above

HAVE FUN!!!!! 