
Prisoners of War (ZH-ProGen) (a SP mission for C&CG Zero Hour + Pro:Gen 2.1)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________

!---------------------------------------------------------------------------!

IMPORTANT NOTE: You need to have ProGen 2.1 for Zero Hour installed for this
mission to work properly. The very popular mod is available at: 

http://deezire.net
	
!---------------------------------------------------------------------------!

	Welcome General M. Granger,

	POW from a recent war need to be detained for questioning. Escort and deliver 
	the POW trucks to the detention camp in this region.

	* At least 1 POW truck must survive the journey.
	* The Detention Camp must survive
_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Ambient sounds set mood
	- Temperate Environment
	- AI trigger attacks
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint 1: Upgrade
	
	You are given quite a lot of starting money so spend it well, upgrade units
	that you WILL use in the mission.

	Hint 2: Own the air

	Build up your flying force and strike out the defensive positions of the
	GLA.

	Hint 3: Defend the POWs
	
	If all of your POW trucks are destroyed before reaching the detention center
	the mission will be a failure.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

New Maps

	Communication Breakdown (ZH) SP MISSION @ cncden.com
	Sudden Strike (ZH) SP MISSION @ cncden.com
	Cobra Cell (ZH) @ cncden.com
	Level Playing Field (ZH) @ cncden.com
	Snow Storm (ZH) @ cncden.com
	Survivor (ZH) @ cncden.com
	Mountain Valley (ZH) SP MISSION @ cncden.com

NOTE: All my maps are available from my website, DK Online and some from genmaps.com

-------------------------------------------------------------------------------------

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour mission was created by Dean Krause on the 16th of February
2004. This map is copyright Dean Krause 2004.