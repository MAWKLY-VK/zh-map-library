YOU HAVE DOWNLOADED A GENERALS ZERO HOUR MAP:                         No mod problems yet
           Grand Canyon Battle
              By. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!!!

To Gain Access:
extract, copy, and paste the Grand Canyon battle Files in the Generals Zero Hour map data Directory

OVERVIEW:
4 players
AI skirmish or multiplayer
Centered at the Grand Canyon Hoover Dam Reigon
Plenty of supplies 
A few tech buildings
Sneak attack path for infantry on the sides of the canyon leading all 
the way to the dam and back.
Dam Break Trigger included!
Relistic water breakage fx. and lake and river equlize depth (river fills up=lake goes down)
When Dam is destroyed the Sneak Attack Path is submerged forever 
(until you start or restart a new game of course)

Problems: well, I tried to make units be able to cross the dam 
(like the real hoover dam) but cant. Its a good allied assult map but can only cross and attack
through aircraft or tunnel networks. 
Unless you want to sit around and wait on superweapon timers. 
(thats fine too, but the conventional means is more interesting on this map even if you have to 
build 30 Chinooks, Helixs, or sneak attack tunnels)

Good Strategy Reference on this situation: 
Generals Challenge General Alexis Alexander.
You can only reach her base through the air and/or tunnel networks. 
Or just sit around and rely only on superweapons.

questions, comments, and suggestions contact me through email or instant messenger at sgtmyers88@yahoo.com

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!! 


Try my strategy AND your own and HAVE FUN!!!


August 2005 sgtmyers88