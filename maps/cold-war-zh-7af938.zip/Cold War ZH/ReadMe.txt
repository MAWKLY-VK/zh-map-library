Cold War ZH Map For C&C Generals Zero Hour
==========================================
Optimized For Zero Hour!

*NEW*
Now includes Snow Strom Weather and new Zero-Hour Tech Buildings! 

This is My second map. The map has three main areas - an Industrial area, a Residential area and a Misslie Base at the sides of the map. Within each area there are three Oil wells and some thing else nice! (Hospital, Oil Refinery or Crusaders & Cash). Each area is quite built up leaving the center of the map open for tank battles.


Map Info
========
File Size : 239KB
Map Size  : Medium
Afternoon Snow Storm, Snow Map, Hills
3 players
AI Support for ALL start points and ALL Factions
9 of Oil wells
1 Hospital
1 oil Refinery
1 Repair Bay
3 Reinforcement Pads
6 Supply Points (3 Protected by Artillary Platforms)
1 Train

Installation
=============
Unzip/RAR the Cold War ZH Folder into your "My Documents/Command and Conquer Generals Zero Hour Data/Maps" Folder

Start the game and the Map should appear in the Unofficial list.

Enjoy ;^]

Email: dratsab@gofree.indigo.ie
