Cold War
Skirmish for C&C Generals

Created by Starduster
mfgrube@t-online.de

4-Player-Map

----------------------------
Snowy mountainous map. 2 Supply docks for each player. 2 Warehouses in the small village.     4 Oil derricks, 1 TechOil Refinery. 

Map Size: 330x330
Map Time: Early afternoon
Weather: Winter

---------------------------


