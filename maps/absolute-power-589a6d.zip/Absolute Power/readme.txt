1v1 Absolute Power - by good_weather_by_sun (gowewisu@googlemail.com)

Map Description:
The players start in opposite corners. The Map is separated in six little areas (2x farm land, 2x town, 2x player base) which are split by rivers and mountains.

Specification:
6x Oil Derricks
2x Oil Refineries
2x Hospitals
4x Supply Docks (2x $30000, 2x $20000)
12x Supply Piles (each $3750)

Some additional Features were implemented:
* higher camera
* count up (e.g. for a no rush agreement)
* buildings without exit running parallel to map boundaries
* no super weapons (nuclear upgrades available in Propaganda Center)

is my first map ;)
Have Fun! Feed Back is welcome!