*********The Last Hope readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        The Last Hope
Created by:  snowy007
Players:     1 player




installation:
--------------

unzip and put the folder in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

This is a single player mission. for generals zero hour.
The USA and China Generals are on a party on a tropical island. they are celebrating that the GLA is almost defeated. The
Last hope to victory for the GLA is to kill the generals all at once using their scud storm. to be able to launch the scud
storm the GLA will need to transport their toxins to it using their toxin trucks. the problem is that 3 of the 4 toxin 
trucks where distroyed in an ambush. you will play as the GLA and your objective will be to get that toxin truck to your
other base and to make sure it survives.

you are able to build walls and you can't train a new jarmen kell if he dies.





