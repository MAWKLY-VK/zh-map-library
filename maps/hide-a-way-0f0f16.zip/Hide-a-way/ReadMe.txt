Created by: Private Jim
Title          : Hide-A-Way

    The story "Hide-A-Way" unfolds where the feared Red Army of Emperor Fang has chased JarmenKell (the beloved hero of the Global Liberation army)
and his band of loyalist, deep into the Carpathian Mountains.
    Knowing the reputation of JarmenKell and his ability to fight back and get revenge on all who embarrass him and his GLA Liberators, Emperor Fang
has retreated to his hide-a-way Palace, in the northwest corner of the continent, untill he has word that JarmenKell is no more.  


This mission has two objectives:
Mission one: Help JarmenKell get at least one or two workers out of the mountains alive.
Mission two: With your workers build a camp/army and destroy Emperor Fangs Hide-a-way.


Hints:
Follow the road out of the mountains and build your camp close to the supplies that you will find.
There are some oil derricks in the north east corner that will help.

Good Luck!!  


 