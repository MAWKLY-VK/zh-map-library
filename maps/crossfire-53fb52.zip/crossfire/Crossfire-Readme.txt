Map Name:  Crossfire
Author: LilBabyBitz (LilBabyBitz@yahoo.com)
Date: 2003-06-04

INSTALLATION NOTES

Unzip to your Command & Conquer Generals Maps folder.
(My Documents\Command and Conquer Generals Data\Maps)
That will allow the folder structure of the map to remain intact, including its contents.  Winrar
users may end up with an extra and undesired subfolder (Crossfire\Crossfire).  If you do,then
just move the contents from the Crossfire\"Crossfire" folder into the top Crossfire folder and
delete that extra subfolder.

DISTRIBUTION REQUEST

You are free to use this map and share it.  However, if you distribute it, please only give
out the original zip file, that contains the correct folder setup and all files.

COMMENTS ON THE MAP

* Layout
This is an 8 player 450x450 tournament map.  It has fairly symmetrical starting locations, 4 oil
derricks, and a few guard towers in a temperate daytime setting.  The map isn't too choked up.
There's a fairly wide entry point into the front of each base and about 5 other entry points to
avoid turtling.  The middle is structured for nice strategic possibilities.

* Resources
The map has more than adequate supplies for 8 players, 3 docks per base zone, with 4 oil derricks
and 2 extra supply docks in the middle area.

* AI
I added all necessary trigger areas, waypoints, etc to allow the computer AI to function properly.
It's a pretty fun time with brutals.  :]  I also incorporated all of the necessary items to allow
for the use of the "Almost Human AI" Script by RVMECH (www.cncden.com).  If you'd like to use the
AHAI script with this map, then you'd simply need to import the script into the map and save it,
preferably as a new name, like "Crossfire-AHAI".

* About
This is my third map.  It was inspired by a Starcraft map of the same name.  As always, I focus on
keeping my maps optimized and without too much eye-candy, that would bog down games with several
people and / or many units.  In other words, my main focus is map playability.

* Other Maps Created By Me
(obtainable from where you got this map, or you can email me for them)
- Nomads
- Theatre Of War