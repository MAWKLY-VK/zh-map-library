Thanks to Dr GOldfish for all previous versions of this map and Special thanks to Rmg | Armin Arlert for helping me with Snow effect.

Current version created by HARZO

Changes:
1. All units and Upgrades are instant.
2. Starting cash for Airforce General is 1000
3. Snowing Effect