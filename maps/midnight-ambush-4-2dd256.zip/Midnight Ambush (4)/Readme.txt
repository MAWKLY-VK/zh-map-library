MAP ::  Midnight Ambush

AUTHOR :: WACKWARDS

PLAYERS :: 2 vs 2

STYLE :: AMBUSH (NIGHT)(THUNDERSTORMS)

ONLINE READY :: YES

AI :: SDI TEAM {AGGRESSION MODIFICATION by WACKWARDS}

INFO :: 

* For playing a "Defensive" style game, select the MIDDLE 2 start locations.
* The China Nuke & USA SUPERWEAPONS Generals have been limited AIRFIELD ability.
* Some of the factories may be hazardous to your Homebase, watchout for TOXIC SPILLS!
* Lightning & Thunder have been tweaked GREATLY.  Randomized storms intensify then stop.

SECRETS ::

* The Train has 2 Garrisonable Boxcars & Stops at 2 locations.  Hotkey the BOXCAR to make it easier to unload.
* Make sure to DEFEND the bridges, the AI is set to EXPLOIT the bridges.
* SUPERWEAPON General & China NUKE have BUILD Restrictions on Airbases.
* Killing the Pimp Limo [Music Limo] & sparing the Cop's have rewards...as in the "Terrorain" Map.
* ONWERSHIP of Chemical Bunkers and Refineries gives you a STEADY $$$$ FLOW.
* Capturing RepairBays & Reinforcement Pads will allow for a 25% Experience Bonus.
* Not holding Repair Bays & Reinforcement Pads causes a -25% Penalty to Rank Experience.
* CROSSING the RIVER AT ALL [even on bridges] causes the AI to RUSH YOUR BASE !!!
* The Chemical Plants have UNDERGROUND LINES, chain reactions can occur when they are breached.

This version is an ENHANCED AI MAP, created June 26th, 2006 by Wackwards.

DEBUGGED & PLAYTESTED by WACKWARDS, LORD DANO, Bobonline, & Kid Genius.

BUILD TIME ::

CONTACT :: wackwards@yahoo.com