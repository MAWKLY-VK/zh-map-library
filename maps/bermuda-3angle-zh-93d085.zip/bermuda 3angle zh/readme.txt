Map Info:
----------

-Map Made for: C&C Zero Hour expansion
-Map: Bermuda 3angle zh
-Author: Rigel6669 
-Created: 03/10/2003
-Size: 300x300
-Climate: sand/tropical island 
-Time of day: Afternoon
-Players: 6
-Type: Multiplayer/Skirmish map 
-Resources: 14 supply docks, 15 oil derricks, 4 reinforcement pads
            2 tech repair bays,artillery platforms and repair pads 
 

A 6 player sand/grass island situated around the bermuda triangle area with lightening ( sound )
and rain effects ( sound and visually )
( Remake of the generals bermuda triangle map ) 
 


E-mail: rigel6669@yahoo.com

Special thanks to: Lyon for placing this map on the cncden site
                   Rvmech for making his lightening fx/intro script available  



Installation:
-------------

Unzip the complete map folder in: my documents/command and conquer generals zero hour data/maps


My other generals maps available on www.cncden.com:
--------------------------------------------------- 
Patchwork Mesa ( 6 ) - The crossroads ( 6 ) - Bermuda triangle ( 6 ) - China Wall ( 6 )
Bermuda 8 triangle ( 8 ) - Knife 8 fight ( 8 ) - Hover bermuda ( 6 ) - Fortified Canyon ( 6 )

 
I also have made 12 maps for the Emperor: battle for dune game that you can download at the
fan maps section of the fed2k website at www.dune2k.com


I hereby give permission to host this map on www.cncden.com 
Do not modify this map without permission of the author 
(c) 2003
 
