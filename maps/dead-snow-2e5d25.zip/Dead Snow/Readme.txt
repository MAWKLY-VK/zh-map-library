Map Name: Dead Snow
Author Name: Rempit2502
Author Email: war4sure@gmail.com
Max. Players: 6
Game: C&C Generals: Zero Hour
Type of Map: Skirmish
Description: As the war rages on,situation begins to heat up the snowy atmosphere as military forces begin to converge on
             this crucial mountain pass. The residents living in the nearby town have no idea that they are about to be 
             placed in an epicenter of a massive battle that about to lay waste to the valley.

             This map is designed in mind for a 2vs2vs2 setup where each team holds their spot while annihilating the 
             others. Each team got a fair share of tech buildings, and the oil derricks and supply docks are modified
             to ensure maximum cash flow for a long war.Based from a suggestion from a map reviewer I added some flanks
             to ensure generals to keep a watchful eyes on the base while raiding the others.Base entrance also have been 
             widen to solve some issues regarding base defenses.To make it up however I added several new towns near the 
             entrance.