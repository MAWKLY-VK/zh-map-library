Big Valley Conflict
Skirmish for C&C Generals with RVMECH's AHAI-Script

Created by Starduster
mfgrube@t-online.de

4-Player-Map

----------------------------
Desert mountainous map. 4 Supply docks,  2 Supply Warehouses and lots of small supply piles scattered around. 12 Oil derricks, 2 TechOil Refineries. The AI produces a lot of weapons in a very short time, so be alert.

Map Size: 330x330
Map Time: Late afternoon

---------------------------


