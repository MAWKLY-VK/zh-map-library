
Stealth (ZH) (a SP mission for C&CG Zero Hour)
_____________________________________________________________________________________

Introduction
_____________________________________________________________________________________
	
	Welcome General,

	You need to attack GLA positions and clear the region of all GLA forces and
	clear the area of demo traps.

	* All USA units MUST survive

	AUTHOR COMMENT:

	This map is a really fast loading fun map that is not meant to be taken
	seriously at all.
_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Ambient sounds set mood
	- Snipers
	- Fun gameplay
	- Nighttime setting
	- Rainy weather
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint 1: Snipers

	Snipers are really useful in detecting demo traps and also for taking out
	infantry at long range.

	Hint 2: Sentry Drone

	A sentry drone is also really good at detecting stealthed units.

	Hint 3: Gueriila Warfare
	
	'Gueriila Warfare' is tactic in which you make fast effective attacks and use
	the element of surprise against your enemy. Use that in this mission.

	Hint 4: Col. Burton

	Col. Burton has a knife attack, timed c4 attack and remote c4 attack.
	In this mission you should try to aatack defences in an akward angle
	for that defence position.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

Pack of Ten [Map Pack #3]

	Communication Breakdown (ZH) SP MISSION @ cncden.com
	Sudden Strike (ZH) SP MISSION @ cncden.com
	Cobra Cell (ZH) @ cncden.com
	Level Playing Field (ZH) @ cncden.com
	Snow Storm (ZH) @ cncden.com
	Survivor (ZH) @ cncden.com
	Mountain Valley (ZH) SP MISSION @ cncden.com
	Prisoners of War (ZH) SP MISSION @ cncden.com
	Rockets in Russia (ZH) SP MISSION @ cncden.com
	Pacific Tide (ZH) SP MISSION @ cncden.com
	Smackdown (ZH) @ cncden.com

NOTE: All my maps are available from my website, DK Online and some from genmaps.com

-------------------------------------------------------------------------------------

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour mission was created by Dean Krause on the 26th of March
2004. This map is copyright Dean Krause 2004.