Dune Attack
Skirmish for C&C Generals with RVMECH's AHAI-Script

Created by Starduster
mfgrube@t-online.de

10/09/2004

----------------------------
Simple Desert map. 7 Oil Derricks, 6 Supply docks. Enough money for a long and hard fight.
Map Size: 300x300
Map Time: Early Morning

---------------------------

Comments and critics to the above mentioned e-mail.
Keep on fighting.