Amphibious Stinger Bases
------------------------
v1.2
by beng

This is a single player mision for CnC Generals Zero Hour.

Put the "Amphibious Stinger Bases" directory in:
\My Documents\Command and Conquer Generals Zero Hour Data\Maps\

The USA has acquired new technology that enables their firebases to hover over sea or land.
The bunker upgrade will give them this ability. It will also load them with 4 stinger soldiers.
The GLA also have a few tricks up their sleve.

Be careful that your vehicles do not get trapped by the tide.

Tips:
If your stinger soldiers die you can buy the upgrade again to load 4 more.
Your Crusaders and Paladins can be upgraded by salvaging junk.
Some GLA units will leave special crates when killed.

v1.2 fixes a bug with the Crusaders firing backwards when upgraded twice.