Isla of White by RVMECH 


Theater :Snow..Heavy
Game: Generals Zero Hour
Lighting Scheme: Night, heavy blue (cold)
Map Assets:Moderate to Heavy
Min/Max Players: 2



Terrain info:
There are two starting points, the ground is rough and choppy.  Mountains and a frozen river seprate the two base areas.
There is a  river running from North to South  forded by two old  bridges. If you study the river carefully in the high detail mode you will note that the river does indeed appear to have ice over it as well as a thick layer of snow. there are also 2 frozen ponds on the map.

There Supply Docks are located close to the player starting area. There are 2 extra Supply Warehouses in the North. Various Tech buildings are scattered about.

The AI is enabled in this 2 player map.


Authors home pages

Isle Of White (c) copyright CNCDEN~RVMECH/2004 All rights reserved. 
Raden http://www.cncgames.com


CNCDEN http://www.cncden.com/

