June 2009

:: Brookside (by General_Specific) ::

----------
Description

This is a 6-player (multiplayer and/or skirmish) map for Generals
Zero Hour. The player starting positions are geared towards
3 vs 3 matches but other player combinations are feasible.

Players will find a canal running across the middle of the map.
This canal supports a town; lots of garrisonables here.
Additional supply docks could be found in town should the player
require more resources. Other capturables include 2 hospitals
and 2 reinforcement pads (these pads are surrounded by US
military hardware, by the way).

On more thing, search the town for a construction site and in it
you will find what appears to be an unmanned US dozer. It would
be in your best interest to acquire it. If not, you should try
getting a hold of it at least once *wink, wink.*

----------
Installation

Extract the entire folder to your "Maps" folder in My Documents.

Eg: C:\Documents and Settings\User\My Documents\Command and
Conquer Generals Zero Hour Data\Maps

Afterwards, play a skirmish game and check the Unofficial
Maps section. It should be there.

----------
Contact Info

billy_gun4 at yahoo dot com

... Spam me and you'll have the FBI at your back within 5 minutes.

----------
Special Thanks to:

- Filefront and the mapping community (I learned by viewing your
work and reading your tutorials. Thanks!)
- EA Games (... Hey, someone's gotta thank em.')
- Jesus
- ... and to you for downloading my map in the first place. Enjoy.

----------
Copyrighted by General_Specific