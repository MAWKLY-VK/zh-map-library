"Alpine Madness" by King of Nexus

This is a 4 player skirmish map set in a snowy/temperate climate.
Tech structures are located to the centre of the map (4 oil derreks and 1 oil refinery) and there is also a supply dock.

To Play:
Extract the file to "My Documents/Command and Conquer Generals Zero Hour Data/Maps" folder.
Go into user maps in skirmish mode to play!

Happy Gaming!

***Special thanks to Dratsab for the AI***
King of Nexus - Do not copy any part of this map :)
