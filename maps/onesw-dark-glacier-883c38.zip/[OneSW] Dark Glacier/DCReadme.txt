Dark Glacier

Map Creator: Blkwaltz3
#of Players: 6
Climate: Arctic
Available for Skirmish: Yes
Available for Multiplayer: Yes
Date Version Completed: 6/25/03
Email: blkwaltz3@hotmail.com


Description:  Dark Glacier is a 6 player snow map intended for team play, but can be a big kick for ffa!  Moderate money, Plenty of build space, tight battle spots, chilling sound, and AHAI make this a great Skirmish map.  Online Team play can be used for a 3on3 which, unfortunately, EAP only included 1 map.  Special Thanks to RVMECH for his AHAI Scripts and CopyKat for the One Super Weapon Map script.  


A Messege From the Creator:

As always, have fun!  I hope you enjoy this and all my maps that I have created and enjoy Generals to the fullest.  If you have any suggestions or questions, please send me an email.  Again, its all about fun!

All Blkwaltz3 map contain RVMECHS AHAI Map Scripts (latest version) and most contain something from my good friend CopyKat.  Please visit www.cncden.com and the DEN Games Network Forums at www.cncden.com/forums!


This map is copyright Blkwaltz3. Do not attmpt to post this without permission or alter it in any way without permission.