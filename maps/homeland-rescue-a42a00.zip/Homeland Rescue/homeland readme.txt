Single player ZH mission by romie88

Readme

Type : Single player

Title : Homeland Rescue

Objective : Rescue Col.Burton

Extract : All these files to my documents/C&C Zero Hour Data/Maps