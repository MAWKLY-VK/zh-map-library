 Almost Human AI By RVMECH
rvmech@cncgames.com

Although  you are free to use these scripts I would appreciate it if you would not offer them for download from your site. They were created for the fans and are offered from CNCDEN (http:\\www.cncgames.com)exclusively. I would also appreciate a bit of credit if you employ them in your map. Thanks, RV



The USA  AI will choose from three seperate startegies when the Strat center is built...just as you would. It will also choose from three seperate skillsets, or generals options depending on the points aquired....just as you would. It might decide to use the A-10 thunderbolts or it may decide to employ paratroops. It may even decide to use a combination of both. There is no way to tell until you are on the recieving end.
 It will choose different priorities to attack at random times..just as you would. It may decide to take out your defenses first and then work on your base buildings. It may decide to eliminate your tanks and infantry first then work on your base buildings. It may even just decide to go straight for your throat. No way to know until it happens.
 It also now attacks from four attack paths versus the normal three.
Armored teams now have Comanche air support to protect them from ambush. 
The Usa AI will also choose from three seperate "Generals style" templates.  You may find yourself fighting a general that relies heavily on ground troops and armored vehicles, you may find yourself fighting against a general that believes heavily in air power. The last general you may find yourself up against is a one that likes to employ balance between the ground troops and the air power. ONLY the balanced General will build and use the Particle Cannon Uplink. How will you know which is which?...If you see 8 Raptors, 4 Comanches, and tank division hitting your base then the Air power general is greeting you. If you find that you in the middle of the Mother of all tank wars then you may assume that the Ground General has sent his calling card. If you notice a ION cannon burnimg up your supply building then  the balanced general has come to visit.
The USA AI will also employ the normally unused upgrade available for some of it's units, IE Comanche Rocket Pods and Drone Armor.

The China AI will also choose from three seperate skillsets. It may use Artilley barrages or cash hacks, or a combination of the two. It may use Nuke Cannons or Cluster Bombs...just as you would.
The China AI will also make better use of it's Bunkers, over time it will fill them with tank hunters to augment its base defenses.
The China AI will also use four attack paths verses the normal three.
The China AI will move it's Hackers away from the barracks area and into a relitively safe area in order to steal cash, unlike the normal AI.
The China AI will , like it's counter part the USA, choose from three seperate  templates. One relies heavily on ground power , one relies heavily, very heavily , on air power, and the last one uses a balanced attack. Only the balanced template employs the nuclear silo. Only the AI knows which one it will choose from. 
The China Ai also employs the normally unsed Nuclear Tank upgrade and the Subliminal Messaging upgrade.
Lastly the China AI will employ the use of Cluster mines around it's buildings. There are four Cluster mine templates that it will choose from, all pof the buildings, base buildings, defense structures, or none. You win't know until you get close enough to find out...heheh,  good luck.

The GLA AI also chooses from three seperate skillsets. All three rely on the Rebel Ambush, but combine the Cash Bounty as well as the hijacker upgrades in different levels. The GLA general uses only one template...ground power. However, it uses them quite well. it employs more diversified attacks and uses the Angry Mob to it's advantage during the heat of the battle verses the end when it is almost defeated. The Angry mob is also upgraded to  "Arm the Mob' by 66%. There are also more of them. 
Bomb Trucks will now choose whether to use the biotoxin or high explosive upgrades. They also come at you in groups of no less than two.

All of the AI generals will build their respective bases in a more efficient manner. Base defenses surround the base area. Power plants are located on at least three sides. China will build two propaganda towers in a strategic manner. The GLA will build tunnel networks next to  Stinger Sites to provide added support in fending off assaults from the air and ground combination attacks.

Extra teams have been provided for the extra attack path. All brutal teams have been some what modified to reflect the General that employs them. Some teams are larger than normal some are smaller and some are very diversified inorder to provide for most situations.

This is beta version and I am open to suggestions and tweaks. Feel free to email me and give me your thoughts and suggestions.   


If you are making a map and would like to use the AI, you are free to do so, however a nice little acknowledgement would be inorder as I spent a lot of time developing this. 

To incorporate the AI into your map you will need to add one EXTRA attack path per player, this attack path is named "Special". It is applied in the same manner as the normal attack paths, IE Special1, Special2, Special3, etc. 

You will also have to install an extar Trigger Area labled "hack". This area is used only by the China hackers. They leave the barracks area and setupp in this area. It need not be large as it only needs to hold a few hackers. It should be placed in the rear of the player starting areas and a bit outside the InnerPerimeter. Again it is named in the similar manner as the normal ones, IE hack1, hack2, hack3, etc. In the center of each of these hack areas you will need to place a waypoint. The waypoint is used by the China hackers as a reference point to run too. This allows the Hackers to run towards the waypoint, which is in the center of the hack trigger area, when the first hackers in the team reaches it then he and the others will "setup" and begin hacking. This in effect strings them out a bit verses the normally bunching up that thestock AI does.

To install the scripts into the map itself simply make sure that you have included the Skirmish players from the Player list. Next go to the script editor and import them. They will then  be installed. Add the included map.ini file to the map folder and your good to go.


Thats it, RVMECH