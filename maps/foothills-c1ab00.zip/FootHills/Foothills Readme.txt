This map is for the game Command & Conquer: Generals

Map Name: FootHills

Map Author: Thrawn28  (Englands Biggest Slacker)

Released: 04/06/03

Map size: 200 X 300

Usage: Online or Skirmish mode against the computer

Players: 2

Description:a small map for quick blasts of combat 
the map has four oil derricks for you to fight over
and plenty of money to spend

Note:this map use's RVMECH's almost human Ai 


Installation: Unzip and place  folder in:
My Documents->Command And Conquer Generals Data->Maps
...and enjoy!

please send any comments to  de_thrawn@msn.com