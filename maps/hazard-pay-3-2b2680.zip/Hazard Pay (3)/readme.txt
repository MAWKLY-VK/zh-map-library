MAP ::  HAZARD PAY

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1vs1

STYLE :: ABSTRACT [EVENING THUNDERSTORMS]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* 4 BattleShips are Docked of the coast.
* Most of the resources are on the Industrial Islands.
* Hidden Crusader Crates are critical to victory.
* Buildings are much stronger then normal.
* Amphibs are VITAL to assaulting the ISLANDS and HOLDING them.

=========================================

