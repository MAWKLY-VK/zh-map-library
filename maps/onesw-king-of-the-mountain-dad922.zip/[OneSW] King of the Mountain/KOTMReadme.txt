[OneSW] King of the Mountain

Map Creator: Blkwaltz3
#of Players: 4
Climate: Alpine
Available for Skirmish: Yes
Available for Multiplayer: Yes
Date Version Completed: 6/14/03
Email: blkwaltz3@hotmail.com


Description:  King of the Mountain places 4 players atop a windy crag doing battle for ownership!  Tournament style map with adequate money (But not that 5 Docks per player crap...) and buildings and docks on the peak for players to do battle for.

Special Thanks to RVMech for providing the AHAI Scripts/INIs.  Also, Special Thanks to CopyKat for his One Superweapon [OneSW] INI.

A Messege From the Creator:

As always, have fun!  I hope you enjoy this and all my maps that I have created and enjoy Generals to the fullest.  If you have any suggestions or questions, please send me an email.  Again, its all about fun!






This map is copyright Blkwaltz3. Do not attmpt to post this without permission or alter it in any way without permission.