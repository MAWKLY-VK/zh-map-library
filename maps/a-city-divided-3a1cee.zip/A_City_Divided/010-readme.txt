:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::

:: WARNING!!! File is corrupt. Attempting to read file...      ::
         ____ 
         \   \==u8585h 53 ==================85u55hv94vn9  =======
       b$$ 1rnbir   \   \             gggoof444 +1      nnv=]]] 5
vjrn$$$_____       nbr   \     *** Alliance() [[[]L      ***    =
    /   /   \   \    An elatigehnnbuih5eon dedi[][][]00..     555
   /  ag9i49agiuagha4y /  oag5 the better cause"                =
Hrack 74          \                ...      ..''.'k54 ___+++==  1
 /___5548u4jg985ng5__________========LLLL00059 //==========__BERb


--< File_DD473 >----agg---------jgerlr--ar5v3478vh78hv-----------
[Name]]t s**-  = "A City Divided"   EOORORhd  a____ a     :) jf
[Author]       = flippster06           ++++==  0 0g90 *  *---- -* 
[File Name]    = 010-A_City_Divided.map 
[Fi]]=r=== re56          94r5***-+ge 7      /7+9       0.fff..f.
u98 953 uh ef]  []r[g] r656r14 e/b//r    gkiebojia5obh  _++ Tet 0
[Player$]      = 2 0n1y             ERROOR555+ === 4  aa       ''
5[[[[8588u            g&&&g5n  g]ea                 g] 5][e rg5
743]]]]]3tybu5 gj 358u     5g oi55 tg 4+          +4+ 4       095
[R            esourv         hhbv58   __A%G53ag
--v8u5hvq5h5----------8vj98h35v8vh---------hvh85375h578vhr---00--


--<___V % 5h9 pga gag0g 0 0 85-------=-={{{{R ]r ]]] [r wr-------

| [From] nvrvr::::: r*f54 6] Petropavlovsk, Kazakstan"" $T+%__A%    
aj5r5g*/aer1   a9e/g7*54            /a7g4 4 4==  -=-=r        
 r*gg/5/ e5           ll()\\|                  vr  4 1  * -* -*8

mvfv955  _G_% h g42 g|%$_G n5g o g       AT$E_G ajg   A_$G$A  4
_V$_4      A_G$4/*- */54    -a* 4ge  gra&& 494u  ____ $$]]\\\  r
We are in need of help... s44&4g1 6r0 r0e0r4__ _ _gsr r jrj7h r
hn____r===--= They could be watching 00404-204i ks rr g jgj4j  gp
The gl4 d  e 6s2      on the mo\/e *&(*(           __ _E nw r

Befor3 Uy er5345 GL4 uj   gwr   )  _+=== -=ea stop them at all 
costs!%168 6 84 4  w0| 4444+31 __________ g8 $g 80mb from ==4-4+
 48  a34 agj; ;_j0165w 1 1 11 0 001 48 0824 gur rgo for its' too 
l4t3! jgj49 1 0 0 0 ++++++++_____R  5 ))  %%%% #%^ @ 

G00 0d LU   yK G482h      !()_=

b8__   |$A__\\\0)__   ____)    )__|op ||     |Aj5rj5 """ 4 
KVRE   k 4-    4 -- *Alliance re10    4 kg94jg p4g    1r51r
\-0)__|         |)_|)_||   -= i 4-4i-j rn r 8a   41048g0 
|}{}{G}{Gr  ][][ aegiu9    5gj 74098 4||      \|a kgja4 a
  
-    -----||--gh43     _ __$=4==4( !#%$!%^$  85y9 5 0 0 95840 -||


_RG% %# a4t 44 aitional Intel >----------|----90 95e 555 --------
:: 84 4 35 5_ _% a4 4 foh 94h th ae54  _$_$_+ug  29 4t|rgsg  g 8
   e44 040 a0 a|0   : ::: G:4 g g4g 5 ag  a a ta  ag4 "SpySat" 
   v 4a5 /@@@ garrison! g 35 
:__Usperw34pons 2 34> banned 8__t55+ mission???0  --="
!: 8gf  4  jgh 8 64&5a3 1546"""", use these following contacts:
33.. PM at DEN Forums = http://forums.cncden.com
"  = Alliance website = http://alliance.cncdepot.net
----------g /0 560 56/03ehdv f4t q4tgb ert____------------  g494-

98 5 2 52 25  This map is property of the Alliance 5 3 55 6 6q-2
 754 125151___Alliance �2005 - All rights reserved. -====4 4  40 

==[ END ()(( 4 4 2 4g    + + + + + +R+R45447 4 052 4 24JJJJ======