map made by willietoo

Description:
i have add trees made it rain harder switch some of the stuff and the 
ampbious carriers now have 5000hp instread of 100000 i kno i had 10000 
in descript but i was wrong my bad people i have added a few more ampibious carriers also
and switch the oil refinery with a Boss Airfeild and their is still no air execpt the chinooks

if you have a map request plz send it to willietoo_on_zh@yahoo.com and thax for downloading my map
i hope you have fun on it ^^