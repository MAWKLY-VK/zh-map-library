YOU DOWNLOADED A GENERALS ZERO HOUR MAP:                             NO MOD PROBLEMS
       Little Big Lake
       By. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!


ACCESSING:
extract, copy, and paste the Little Big Lake Files to the Generals Zero Hour map data Direcory.

OVERVIEW:
 A 4 player multiplayer or AI skirmish map Consisting
of a medium sized lake in the center with a center island with some extra supplies
there is a dried up creek stretching through the middle, some farmland, and a airstrip for the crop duster.

Enjoy a nice day at the lake!

questions or comments can be posted via email or instant message me at sgtmyers88@yahoo.com

BUGS/PROBLEMS:
NONE!

SPECIAL NOTE:
this map IS based on the Command & Conquer Red Alert 2 skirmish map 
LITTLE BIG LAKE

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!
EVEN THE COMMAND & CONQUER GENERALS ZERO HOUR GAME YOU PLAY IT ON IS NOT YOURS
Command & Conquer,Command & Conquer Red alert, Command & Conquer Red Alert 2, Command & Conquer
Red Alert 2 Yuri's Revenge, Command & Conquer Generals, Command & Conquer Generals Zero Hour EXPANSION PACK are all 
property of WESTWOOD STUDIOS AND EA GAMES.
2003 WESTWOOD STUDIOS and EA GAMES 
the EA GAMES and WESTWOOD STUDIOS logo are registered trademarks and are of
an electronic arts brand.

2005 sgtmyers88
