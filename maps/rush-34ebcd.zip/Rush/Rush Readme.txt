
Rush (ZH) (a mission for C&CG Zero Hour)
_____________________________________________________________________________________

Briefing
_____________________________________________________________________________________

	>>> BEGIN TRANSMISSION >>>
	
	We need to execute a suprise attack under the cover of darkness on two key GLA 
	cells occupying the town of Bitburg, Germany.

	A fast-flowing river divides the two GLA cells. The setting is Spring.
	
	The two cells are getting prepared to use their Scudlaunchers to attack towns
	and cities in Germany. Their scudlaunchers are upgraded and can attack a number
	of key cities... including Berlin!

	We have created a makeshift base in the Southeastern corner of the battlefield.

	The Germans have requested the help of Col. Burton and a team of Americans to 
	solve the potentially horific problem. You have been chosen as the General to
	execute the mission.

	Black Lotus and a small team were sent in earlier, you may be able to find them
	hidden somewhere.

	Col. Burton MUST survive this mission.

	Good luck General...
	
	<<< END TRANSMISSION <<<

_____________________________________________________________________________________

Comments
_____________________________________________________________________________________

	Feel free to write up comments about this map or any other maps at CNCDEN.com 
	in the appropriate section.
	
	To reach the right section click "Comments" under the announcement on the
	main page of CNCDEN and then fill in the comment form at the bottom.
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Follow the objectives
	
	In this challenge you need only destroy the scud launchers to win, you do not
	need to destroy the actual bases.

	Hint #2: Analyse then attack

	Don't just barge into an enemy base and expect to clobber them with larger
	numbers... analyse the base THEN attack.

	Hint #3: Time is precious

	Time is against you in this mission, move fastly, enage in battle with only 
	enemies that must be attacked.

	Hint #4: Know the map

	It is vital that you know where everything is on this map.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched an public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.  
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Previous Work
_____________________________________________________________________________________

	Generals Zero Hour Maps:
	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml

_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au

_____________________________________________________________________________________

This C&C Generals Zero Hour mission was created by Dean K on the 1st of December
2003. This map is copyright Dean Krause 2003.