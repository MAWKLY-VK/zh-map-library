MAP ::  Highland Islands

AUTHOR :: WACKWARDS

PLAYERS :: 3vs3 // ?vs2CPU's

STYLE :: Abstract

AI :: SDI TEAM

ONLINE READY :: YES

INFO :: 

* Many High Mesas linked thru bridges.
* Particle Canon and MANY other Tech Buildings to Capture.  
* The Center 2 are NOT AI READY.
* PLAYTESTED July 2006 and PASSED.