Map name: CO-OP_GC_Demo_Easy_v1
Author: Sriracha
Date: 2021-02-12
E-mail: jonathan16153@hotmail.com

Game: Command & Conquer Generals Zero Hour


Description:

This is a custom generals challenge Co-op map made for 2 players. You will face the demolition general and traverse
his battlefield, which is filled with deadly demo traps.


Difficulty: Easy


About the map:

- This is an online 2-player custom generals challenge map against the Demolition General, General Juhziz.
  
- Choosing a Skirmish AI as a teammate will not work, the AI won't do anything. Good idea if you want to play it alone though.

- The map checks for playing players in the upper three slots in the game options (where you set up the game, like choosing map etc).

- Both playing players should be in the same team. Otherwise the game will end if one of the players is defeated.

- If the two playing players are in the same team, the game will be lost when both players are defeated.

- The colour of the AI opponent is orange.

- Shared experience points.

- No need to restart the game after map transfer, you can play right away.

- Recommended starting cash at least 10k.

- To conclude: The two players who will play the map needs to be in two of the upper three slots in the game options.
  They should be in the same team. The game will be lost if both players are defeated.
  The colour of the AI opponent is orange. Shared experience points.
  No need to restart game after map transfer.
  Recommended starting cash at least 10k.
  

The map has been tested and beaten.
If you find any bugs, you're welcome to report it to me by e-mail.

have fun!


Sriracha 
2021-02-12