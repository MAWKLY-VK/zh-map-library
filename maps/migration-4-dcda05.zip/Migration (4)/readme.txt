MAP ::  MIGRATION

AUTHOR :: WACKWARDS

PLAYERS :: 2vs2

STYLE :: SYMETRICAL [NIGHT THUNDERSTORMS]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* The Castles and Battleships are CRITICAL to Victory !!!
* Custom Color Water added.
* Features Hovercraft for transport.
* All sides start with a small GARRISONABLE ARMY.
* BRIDGES ADDED and I am opposed to them...OPEN your editor and DELETE them to recreate the original concept.
* BRIDGES are weak and should be destroyable, but it appears they need mutliple Nukes?!?!?

=========================================


WWW.FASTGUILD.COM for more maps...