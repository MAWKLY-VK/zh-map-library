----------------------------------------
   GAMEPLAY
----------------------------------------

- Like any regular FFA map

----------------------------------------
   WIZARDS
----------------------------------------

- Each player starts with 2 Wizards. 
- Wizards earn $1k/min, the same as an oil derrick.
- Send the Wizards into the fountains to be gifted a construction unit for the designated army.
- The Wizard houses are invulnerable, use them to keep your Wizards safe to use later. Wizards cannot earn money while inside the house.