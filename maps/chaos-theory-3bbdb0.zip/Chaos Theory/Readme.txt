Map Name: Chaos Theory
Compatibility: Zero Hour Only
Map Author: RABIES
Age: 19
Email Address: RABIES@satx.rr.com
Released: 1/4/04
Players: 4

Description: This is a large 4 player map, with an interesting prize in the center. Capture and hold what you can, each was left behind by a superweapon general. The AI is super smart in this map, and ruthless, so watch your back...

Installation: You should be OK by just unzipping it into your maps folder under My Documents--->Command and Conquer Generals Zero Hour Data--->Maps.

If it does not create a separate folder called "Chaos Theory" then make one :-)
