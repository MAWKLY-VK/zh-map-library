Operation Red Heat

Story: As the GLA are beaten back at the hands of the Chinese during the end of the war,
a small group of commandos setup a small base in Guangzhou....


Installation:  Extract the folder in the zip to your documents\generalszerohour\maps directory
Load it up in Skirmish and play away.  Dont forget to hit 5 on the numeric keypad after the initial 
movie.

Credits:

Warren 'Disco Screw' Berry






IMPORATANT!!!!!!

Before you read any further, I have identified a bug in the map
when you first start off(after the initial movie).
The camera doesnt go outside of the  Gla Base, so you will have to 
reset the camera to the defualt view.  On my computer this is done 
by double clicking my mouse wheel or by hitting the 5 on your Numeric 
Keypad(the one on the right hand side of your keyboard).  I cannot 
fix this bug, sorry for the inconvinience.


HOWEVER THIS HAS ONLY HAPPENED ON MY COMPUTER AND NONE OF THE OTHERS I
HAVE TESTED THIS MAP ON.