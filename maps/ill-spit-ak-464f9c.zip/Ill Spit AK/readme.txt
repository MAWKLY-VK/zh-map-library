just a little 2 player map i came up with, supplies are good enough, its not a money
map. its kind of minimalistic, but thats how i do.

comments, questions, nude photos(women only please), hate mail, send it to
econobeing5@gmail.com