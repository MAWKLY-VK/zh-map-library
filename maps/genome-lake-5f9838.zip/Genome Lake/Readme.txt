Genome Lake
=============
1v1 map with a lot of build space and supplies. Middle of map is oil
and some convoy trucks ready to be shot at.
=============
<C> to me