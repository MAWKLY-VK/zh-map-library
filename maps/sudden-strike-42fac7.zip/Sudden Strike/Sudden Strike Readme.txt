
Communication Breakdown (ZH) (a SP mission for C&CG Zero Hour)
_____________________________________________________________________________________

Breifing
_____________________________________________________________________________________

	Welcome General,

	The GLA has been setting up various cells in Tehr�n, Iran. They are currently
	in control of the major industrial areas oil, gas and water.

	For this mission you will be given limited reinforcements.

	The following are your objectives: 

	Objective 1: Destroy all gas, oil and water buildings

	Objective 2: Destroy the powerplants that power the city

	* Difficulty is set to Hard
_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Multiple chances at using various tactics to win
	- Mulitple routes to AI base
	- AI Attack triggers
	- Instant action
	- Ambient sounds set mood
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Flash Bang!

	Flash bangs are great to kill infantry before they deal any real damage to
	your infantry.

	Of course flash bangs are useful for clearing buildings of garrisoned enemies 
	but they are also useful when taking out stinger sites.

	Hint #2: Defensive Formation

	Getting your units in a proper position can be hard when you're being
	attacked sporatically. Build counter units and place them in a proper position
	to use their couter attack.

	Hint #3: Disabling Defences

	Use microwave tanks to disable structures effectively. Make sure you keep
	other untis nearby them to defend them.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION @ DK Online
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

New Maps

	Communication Breakdown (ZH) SP MISSION @ cncden.com

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour SP map was created by Dean Krause on the 2nd of February
2004. This map is copyright Dean Krause 2004.