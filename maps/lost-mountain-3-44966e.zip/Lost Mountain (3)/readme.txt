MAP ::  Lost Mountain

AUTHOR :: WACKWARDS

PLAYERS :: 1vs1vs1

STYLE :: ABSTRACT [AFTERNOON VOLCANO]

AI :: SDI TEAM [ENHANCED]

ONLINE READY ::  YES

INFO :: 
========================================
* Custom Color Water added.
* The MOUNTAIN has paths around it for ambushes & SNIPERS.
* VERY FEW Buildings and TECH Supplies, but enough to get job done!
* Center Player has a larger base to make up for being in the MIDDLE.
* Terrain was created to allow MOTORCYCLES easy access, keep your defenses up.
* Hidden CRUSADERS exist on the OUTSKIRTS of every base.
* All TOWERS and OIL DERRICKS have enhanced Hit Points.
* Earthquakes & Landslides occur around the mountain.

=========================================


...MORE MAPS AT WWW.FASTGUILD.COM
