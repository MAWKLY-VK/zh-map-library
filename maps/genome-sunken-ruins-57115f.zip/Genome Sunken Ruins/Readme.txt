Genome Sunken Ruins
======================
Two high plateaus where players start. Best for 2v2.
lotsa money, build space. Sunken city on middle-right section.
======================
<C> to me