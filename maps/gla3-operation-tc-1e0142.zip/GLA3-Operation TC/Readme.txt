Map Details:
Game: Generals Zero Hour
Number of players: 1
Name: Operation: Toxin Commando
Difficulty Level: Medium
General: Toxin General and Infantry General
Creator: Mr. Toxin
Credits to: Beng
Date: 14/7/2009

________________________________________________________________________________________________

Features
________________________________________________________________________________________________

-moving cars, and whole city
-lot of enemies
-the use of stealth
-intro cut-scene
-a moving train
-a much better intro and gameplay since previous update


________________________________________________________________________________________________

Description
________________________________________________________________________________________________

This is the third map of the GLA Campaign which I am making. The story of the campaign comes
after the events of Zero Hour. The GLA has arisen again. In this campaign you will help the GLA
retake their lands, gather an army and supplies, and then liberate the world. The world will be
free of China's nationalizm hordes and American imperialism.
In this mission, you control the last surviving Dr. Thrax's commando. His mission are important 
chinese objects like US Embassy, Police Office, Prison Camp, Emperor Tank and Goverment 
building. You will free a Hijacker who will steal the Emperor, and you will kidnapp Chinese 
Ambassador by Battle Bus.

________________________________________________________________________________________________

Bugs and problems in the game
________________________________________________________________________________________________

If you find any bugs, PM me on www.cncmaps.com and explain what is the mistake. I will fix it.
Thanks very much to Beng, who fixed some bugs and created map.ini file. He also changed intro.
This map wouldn't be the same without him.

________________________________________________________________________________________________

How to install
________________________________________________________________________________________________

To install this map, just place the folder to your My Documents/Command&Conquer Generals Zero Hour Data/Maps.
Then start Zero Hour and go to Unofficial maps.