Author: General 362
Map Name: Last Hope

Description: Last Hope is a conversion of an old USA campaign level into a fun skirmish map that can also be used in multiplayer.  It is set up to be able to play with three players, preferably with the bottom two to face off against the mountain base,  although 1vs1 can also be fair. A lot of work went into converting this map to be able to play in skirmish mode.