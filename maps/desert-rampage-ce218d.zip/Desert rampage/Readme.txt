Map Name:  Desert Rampage
Map Author: Major_general_t
Players:4
Usage: Online or skirmish
Items: 438

Map Description: This is a 4 player desert, set during the afternoon. It has a large open layout, with a fort/town in the center, i have used it online several times and large tank battles tend to occur because it is so open.
There is a good amount of cash, but you will have to venture out of your base to get it.

This map uses Rvmech's AHAI, which is great.

 