Map: MicroMap - BattleBus - Tournament Desert
Players: 2
Date first released to community: 24th August 2017 (UK)
Map Maker: Jundiyy
Contact: the-onejundiyy@hotmail.com

MicroMaps - Each player starts with a set amount of units, the first player to loose all of their units loses.
If both players are left with units and there is no chance of killing each then it is a draw - such as Ambulance, or SpeakerLix (Helix with Speaker Tower).
If there are maps which Infantry can garrison other units (such as Humvee, Helix, Battlebus micro maps), then you can't be evacuate your units once garrisoned,
unless it is the very start of the game, to swap your units around.

-----------------------------------------------------------------------

Welcome Generals.

If you need to get in touch, advise or ask anything, please email me on

the-onejundiyy@hotmail.com

I also have a youtube channel, if you have any good action replays, please also email them to me or message me on youtube.
Please have action in the replay and not bunkering games only, or one sided.

https://www.youtube.com/channel/UC4UY-HVad4kfaGwa-lVKUtg

Thanks for playing my maps, you can download many more of my maps on this website.

https://www.gamereplays.org/community/index.php?showtopic=990750

I also turn my survival maps into official maps, these can be downloaded below.

https://www.gamereplays.org/community/index.php?showtopic=989603&pid=9982525&st=0&#entry9982525

Please download my MicroMaps using the link below.

https://www.gamereplays.org/community/index.php?showtopic=1002926

----------------------------------------------------------------------------------------------------------

You are free to use my maps and scripts, please don't take the credit for them, as they are still my work and they belong to me.

Sometimes I may edit a map, this will be told at the begining of the map, something like Welcome to xxxxx by xxx edit/revised by The-One/Jundiyy.

------------------Scripts/Features on my maps------------------
What do they mean?

Ghost Market/Hidden Market - This is a off map market which is given to the players, if the player dies or surrenders, this market is destroyed.

Defence is the last buidling - Any map which has the hidden market script, will have this script with it, this script only allows the player to die once EVERY building has been destroyed, including
                               all defences, just like it is in the Command and Conquer Generals.

Carpet Level 3 - AirForce General Carpet is enabled at level 3. Usually once the player is Rank 3, Carpet will become available, if not, it will need you to purchase A10 Level 1.

Super Hacker - This is an Infantry General Hacker with 501 HP (Kell needs to snipe 2 times to kill it).

Super Strong Supply Dropping Drop Zone - This is a non captureable drop zone with 4000 HP - this means it is just over 2 times stronger than an oil.

Free Tunnels - This gives players free tunnels on the map.

Respawning oils - Some or all of the oils will respawn after a given timer, this is usually 3.5 mins.

Respawning cash crate - Some or all of the cash crates will respawn after a given timer, this is usually depdent on the amount of cash receievd. $100 cash crate will respawn every 60 seconds.

Respawning units - Certain units will respawn after being destroyed.

Give money to teammates - This scripts allows you to give money to your teammate, simply by enterting one unit into the outhouse (or whichever building may be used) and having units in the squared
                          patches of land near the building, (usually 2, but can be any amount). The outhouse will respawn once destroyed. At the moment this does not work on shockwave 1.1.

Money giving huts - These are huts which give money when garrisoned, usually:-
                    - The grass huts give $20 every 15 seconds
                    - The wooden huts give $35 every 15 seconds.
                    - The large grass huts (MarketHuts) are equivalent to a market.
                    - The huts will usually give double the amount of money in shockwave.
                  However it is possible that this rule isn't followed in every map.
                    The huts will respawn.

Grass huts - Usually all NON MONEY giving small grass huts have 250 HP.

Respawning Supplies - These supplies will respawn on a timer after depletion.