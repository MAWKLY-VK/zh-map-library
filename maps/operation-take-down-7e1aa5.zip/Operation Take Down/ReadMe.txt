HOW TO INSTALL:

1. Paste the "Operation Take Down" folder into your Generals save folder in: Desktop - My Documents - Generals Zero Hour Data - Maps 
2. Play the Mission in Skirmish mode, Unofficial Maps

 -To make the game more fun, please don't move the game camera until all the units finish moving, don't interupt them :)

ENJOY!