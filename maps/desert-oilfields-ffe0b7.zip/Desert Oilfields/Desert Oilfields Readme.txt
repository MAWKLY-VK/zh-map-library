You Downloaded A Generals Zero Hour Map:                          No Mod Problems yet
         Desert Oil Fields
           By. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!


To Gain Access:
extract, copy, and paste the Desert Oilfields files to the Command & Conquer Generals Zero Hour map data Directory

OVERVIEW: 
4 players AI or multiplayer
I have played many times in the multiplayer system and mastered many single player maps and missions
and have become a good artistic map maker I also have taught some people new to multiplayer 
so i decided to make a couple of multiplayer practice maps.
This map is an oily flatland with a desert theme including a dried up river flowing through the middle 
(err what river if dried up... lol) This map also really begins the practice of capturing and conquering enemy, tech, and neutral buildings 
while conquering your enemies and practiceing chokepoint stratgies on a bridge in a multiplayer game. 
A small but simple map designed for beginning players to practice strategy in multiplayer.
*The third installment of my multiplayer practice maps  Added Even more goodies to this map than what was in my previous two.



Problems/BUGS: none detected yet

YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!!


PRACTICE WELL AND HAVE FUN!!!

place a question, or comment via email or instant messenger to sgtmyers88@yahoo.com


2005 sgtmyers88
