Frostbite
by AndrewAce3158
andrewace3158@yahoo.com.au

Frostbite is a small winter map designed for quick 2 player battles. There are three ways to approach the enemy and limited room to build. Each player has only one supply dock, so players must fight for the single oil derrick in the center. The owner of the oil is almost guaranteed the win.

The layout of the map was inspired by the map Alpine Snow and the texturing is based on China mission 7.

Andrew