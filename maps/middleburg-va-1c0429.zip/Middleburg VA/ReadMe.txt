Middleburg V.A For C&C Generals Zero Hour
==============================================
This is myself(DratsaB) and LoSer's 2nd map together. This map is a 2 player, country side, temperate map with a medium sized city in the middle.  This map is unique in that it has fields seperated by Ditches/HedgeRows that creates some interesting battles, without being too restrictive.
     

A couple of notes
------------------
There are supplies that can be made use of adjacent to each players Base Area, the building that looks like a factory (Toxin Repository is its World Builder name). 

Finally, I would recommend you shutdown & restart your pc, and any others playing, before going to battle on this map. This is to ensure optimum performance (I find this to be a good rule anyway with all Generals maps).

I Hope you have fun with this map and feel free to email me or LoSer with any comments/problems at the address' below.

LoSer & DratsaB


Map Info
========
Creators : Loser & DratsaB
Zip File Size : Kb
Map Size  : Medium/Small
Afternoon, Coutry side town, Clear Weather
2 Players
AI Support for ALL start points and ALL Factions
10 Oil well(s)
0 Hospital(s)
2 oil Refinery(s)
2 Artillery Platform(s)
0 Repair Bay(s)
0 Reinforcement Pad(s)
2 Supply Factories(s)(Toxin Repositories)
2 Supply Point(s)
0 Supply Depot(s)
0 Train(s)

Installation
=============
Unzip/RAR the "Middleburg VA" zip file into your "My Documents/Command and Conquer Generals Zero Hour Data/Maps" Folder

Start the game and the Map should appear in the Unofficial list.


E-mail: dratsab(NOSPAM)@gofree.indigo.ie
       rizvinameer(NOSPAM)@hotmail.com