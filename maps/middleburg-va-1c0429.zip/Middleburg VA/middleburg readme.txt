Zero Hour map by LoSeR

Map name: Middleburg, VA

For skirmish and online play.

This is a 2-player temperate map with a small town in the center. Plenty of money, oil derricks, and other tech goodies available. Good amount of room to build. Nice clean layout.