Made By Byornski (byornsk1@aol.com)
Thanks to RVMECH for his AHAI

Detailed map designed for team play in a 2v2 game. Quite a lot of supplies and a large group of oil derelicts on the map. Includes the 'Almost Human AI' for skirmishes and should give any decent player a run for their money. 