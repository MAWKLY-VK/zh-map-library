Command & Conquer Generals: Zero Hour Map

================================================================
Title                   : Moon Assault
Version                 : 1.0
Author                  : Pascalis Sadewa
Email Address           : pascalis_sadewa@yahoo.co.id
Twitter			: pascalisadewa
deviantART		: http://dawn-shade.deviantart.com
Facebook		: http://www.facebook.com/pascalis
                           
Description             : This is a 3-player map set in the moon. Along with the craters, rocks, and mountains.
			  There are techbuildings available for capture but beware with the random explosions!
Game Type               : Skirmish
Single Player           : Yes
Multiplayer             : Yes
Known bugs              : None known

Installation
------------
To use the map, look in your "My Documents" for a folder named "Command and Conquer Generals Zero Hour data/Maps". If this directory doesn't exist (means you never played a skirmish game), play a skirmish map for a few minutes and comeback. The folder will be automatically created by the game. Extract the COMPLETE Map FOLDER (not just the individual files) included in the map zip file in the "/Command and Conquer Generals Zero Hour data/Maps" folder. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section.


Copyright / Permissions
-----------------------
This level is copyrighted by Pascalis Sadewa a.k.a Dawn-Shade 2009
Authors may NOT use this level as a base to build additional levels, unless they have my permission.

You are NOT allowed to commercially exploit this level, i.e. put it on a CD
or any other electronic medium that is sold for money without my explicit
permission!
----------------------
All trademarks and trade names are properties of their respective owners.
