MAP ::  Allied Assault

AUTHOR :: WACKWARDS

PLAYERS :: 2vs2

STYLE :: Abstract

AI :: SDI TEAM

ONLINE READY :: YES

INFO :: 

* This map has a small-dense city with highrises.
* Tech Building are all around.  
* A Nuke Truck is tucked into the City so be careful.
* Playtested June 2006 and passed.