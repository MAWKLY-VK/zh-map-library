Gnawing Sands of Time
============================

Created by: Doug "SCSI4u2" Farley 

Size: Med-Large
Players: 4
Skirmish: Yes
MultiPlay: Yes
Resources: Above Average
Dev Time: Week +- a Week =P

==================================
	INSTALL
==================================

Dump in your maps dir.

==================================
	Comments
==================================

My First real attempt at a Generals map.  I hope someone out there likes it.

I tried my hardest to keep this map balanced, while adding enough cash
and surprises for the player.  I've added maybe too much pathing for the
AI, it seems to stop and cordinate its attacks on the center island!
Each player has 2 Oil rigs. One that are easy to hold and/or control, 
thus insuring that they have at least some income. Pluse one harder to defend oil rig. 

I sometimes find the Super Weapons annoying in Multiplayer games vs. Humans,
so they have been removed as a major threat in the game.  I think ground/AIR
attacks without them are more enjoyable.  Just my 2 cents, you can still 
build them (So China still gets their overloard upgrades), they just 
take FOREVER to charge. ;o)

If you find any bugs, _PLEASE_ e-mail me to let me know! I want to keep 
the map free of anything critical.

SCSI4u2

Feel Free to repost/host this map whereever you wish (drop me an e-mail 
if you do! I like to know where my maps end up!), just keep the files intact.  
If you make changes, credit me, and send me a copy of your changes.

<SHOUTnRANT>
Thanks to EAP/Westwood for making Generals, and for keep Promising they'll 'fix'
the network issues that make me loose sync in so many local lan games.
Been Playin their games since 'Dune 2'.
</SHOUTnRANT>