A 4 player skirmish/multiplayer map. Each team begins with a command center from
each side. This will make things interesting when you are able to use technologies 
from China, USA and GLA

Daniel .A (Sweden)
anddan2@hotmail.com