;========================================================;
;-------------------Mountain Aggression------------------;
;---------------------------by---------------------------;
;----------------***LoSeR*** (<<EcO>>fiReBaLL)-----------;
;========================================================;

Mountain Aggression is a four-player map with very responsive A.I. players, cool water color, and much more. There are several tech buildings around the map, but the comp will try as hard as possible to take them from you. A nice intro message at the beginning, and an overall fun map to play on.


size = 270 x 270

players = 4