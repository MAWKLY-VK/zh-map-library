
--------------------------------------------------------------------------------------------
                    WWW.CNCMAPS.COM            Duck and Dive
--------------------------------------------------------------------------------------------


Author: Judds
email: Juddss@gmail.com
Created For: www.cncmaps.com
size: 400x300
3 Player for Zero Hour

Map last modified:Monday, November 13, 2006 by thomasalan, fixed some issues with the areas of the map mistakenly placed as waypoints. 

Duck and Dive is a 3 player temperate skirmish map for command and conquer generals zero hour. It is set in the morning and has 941 objects on it so it is fairly well detailed. There is a train that runs from the North station within the Docks and runs the length of the map through the middle and exits to the East. The second train runs from the South through the center of the map and also exits the map to the East. There is a lot of capturable tech buildings to make the gameplay a little more interesting and also plenty of cash dotted about in supply docks, warehouses loose crates and also there is 3 special supply buildings to be found and emptied, (one for each player or all for one depending on your tactics). Also scattered about there is : 
3x boss dozers
2x Boss supply trucks
2 crusader tank crate with 2 tanks in each
1x Overlord (upgradable0
1x USA Airforce Chinook
1x USA Aircraft Carrier - The aircraft carrier is capturable , but as it is docked out of reach of your rangers then boarding it may cause a problem. To obtain full control of the Aircraft carrier then you must find the water works building and garrison it fully and keep control of that building as it is the major advantage of this map. If you loose control of the building or the building is destroyed then the Aircraft carrier will no longer be in control by you. Find the water building, but which one is it? that is down to you to figure.


Each base has 2 supply docks within their base so funds won't become an issue in the early stages of battle. Strategic turret capturing will play a major part in this battle and if captured and used to your advantage you can take out your enemy as they leave their base. This map is my second map in 6 months and is far more eye pleasing and more enjoyable then my previous map Enemy Enclosure. Now that i am back in the saddle i intend to make a lot of maps over the next few weeks, if you enjoy this map or have any issues regarding gameplay, layout or anything else then please feel free to email me i will be more than happy to take any critisism or tips, please rate this map to give me and the other map makers on this site aware of what you the users are looking for in maps we provide.
Thankyou and have fun.
Judds


--------------------------------------------------------------------------------------------

Install directory:  MyDocuments/Command and conquer generals zerohourdata/maps

--------------------------------------------------------------------------------------------
