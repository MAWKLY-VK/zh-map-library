Dry Gulch By RVMECH
rvmech@cncgames.com
This map is the intellectual property of RVMECH
It is copyright protected under license by cncden .com
Copyright cncden~rvmech 2003
Your free to play the map, decompile the map, inspect the map,
and anything else your heart desires. YOU are not allowed to offer  it on your website for download.
I made it, I own it, I say where it gets downloaded from. It was made available to the Generals fans from my website http://www.cncgames.com
CNCGAMES.com is the owned and operated by Hal Lynch aka Lion..

This is a 4 player East vs West type map. It can be used for clan games and your basic friendly team game. The scenario is a arid western desert area in the early evening hours. You and your mate should start off on the same side of the map as the starting points are 'stacked" one behind the other , although there is plenty of room between you both fore expansion.

 If the map looks vaguely familiar then you would be correct. It was a prototype for one of the official maps  before I expanded it and modified the terrain somewhat to accomadate the Almost Human AI that I created. The map is setup for AHAI and if you have the AHAI mod then just enable the mod and it will function to it's fullest. It is also setup for the normal AI provided by EA.

Crates are scattered around the border areas and the map.ini file provides for 45,000 dollars per supply dock. There are two supply docks on each side as well as one in the north and one in the south.

A pair of Bunkers offer protection to the main access path to your base area. Guard Towers provide  some protection from the rear entrances.

Skirmish players will recieve a pair of Chinese Gattling Cannons as well as a Nuclear Power Plant to give them a headstart against the AI as long as you choose either of the INSIDE starting points.  These will not transferred in Multiplayer games.

Enjoy , RV