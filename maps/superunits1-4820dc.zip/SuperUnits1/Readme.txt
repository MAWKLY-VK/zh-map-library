SuperUnits map for Zero Hour
----------------------------
by Beng

I made this small map more to test out modifications than for actual
gameplay but its still fun in its own way.

This is a small and simple GLA mission against a Chinese base. You start
with a small GLA base.

There are many modified units.

On the Chinese side a super bunker overlord tank that detects stealth,
and up to 10 infantry. The 8 Chinese tank officers will retake Jarmened
tanks until they run out of men, and the last one will scuttle the tank
in a nuclear explosion.

They also have a very tough bunker helix that will explode with the fuel
air bomb explosion when you kill it, so beware.

You get 2 Jarmens, GC_Slth (parachutes in) and Demo Jarmen (which you build).
Both have upgraded weapons that can snipe garrisoned buildings and snipe
vehicles at a higher rate than normal Jarmnens.  The demo Jarmen also
carries augmented demo cgarges which have 3 effects: Explosive blast,
Black Napalm firestorm, and Superweapon's Aurora bomb explosion.

You can buld workers from the barracks who can make demo traps and
tunnels.

The arms dealer makes only radar vans and modified crop duster planes
(the first icon). The crop dusters cost nothing to build (a bug i can't
solve yet)but you can only build one at a time and only when you have
over 2000 credits.  They will benefit from the junk repair upgrade and
Demo suicide upgrades. They have toxin weapons and explode like the
Helix, in a FAB explosion, plus spreading toxin everywhere.

There is a train that provides a ride in and out of the Chinese base if
you want to sneak in.

I've also added in Missile gunboats on the Chinese side.
If you can tempt them onto shore, snipe them, then take them over,
they are very powerful weapons.

Your only income if from 2 black markets, but when you get more points
buy the cash bounty powers to get more cash.

You win when you destroy of capture all China buildings, and you lose if
they destroy your palace, barracks, and arms dealer. Its an easy
mission.

Map makers: Feel free to take the modifications for your own maps,
see the scripts, teams (in world builder), and the map.ini file (a text
file) to see how they were done.

