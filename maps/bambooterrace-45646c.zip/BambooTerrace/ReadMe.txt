GAME:       C&C Generals: Zero Hour
MAP:        Bamboo Terrace
PLAYERS:    2 Players  ( 1 on 1 )
SIZE:       Medium-Large
PLAYSTYLE:  Meant for aggresive-expansion style gameplay, encourages
            land-grabbing, but leaves plenty of room for defensive styles.
DESCRITION: The map is set in a rainy bamboo plantation, featuring unique terraces,
            several farms/villages and a lake. Most of the map is accessible, 
            making for some great tank-battles. Plenty of tech structures to capture.
AUTHOR:     Jake Splichal 'Uncle Enzo'