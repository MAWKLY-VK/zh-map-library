Operation Irene II
by COValle
-------------------------------------------------------------------------
- Single player mission for Generals Zero Hour

Mogadishu, Somalia.

After the end of the civil war, the UN returned to Somalia to help with the reconstruction of the country, the US set up a small base in an airfield near the capital city of Mogadishu. Everithing was running smoothly, until now...

An in-game briefing will tell the details.

Hints:

- Don't get the downed pilots killed
- Wacht out for snipers

-------------------------------------------------------------------------

This is my first "serious" mission, I hope you like it.

I created this mission to return something to the CnC community that has given me so much since the times of TS.

homerovalle@starmedia.com