Map name: CO-OP_GC_Slth_Medium_v1
Author : Sriracha
Date: 2021-04-06
E-mail Author : jonathan16153@hotmail.com


Game: Command & Conquer Generals Zero Hour



Description:

This is a custom generals challenge Co-op map made for 2 players. You will face the Stealth General and his stealthed forces.

Difficulty: Medium


About the map:

- This is an online 2-player custom generals challenge map against the Stealth General, Prince Kassad.
  
- Choosing a Skirmish AI as a teammate will not work, the AI won't do anything. Good idea if you want to play it alone though.

- The map checks for playing players in the upper two slots in the game options (where you set up the game, like choosing map etc).

- Both playing players should be in the same team. Otherwise the game will end if one of the players is defeated.

- If the two playing players are in the same team, the game will be lost when both players are defeated.

- You can't play as the Stealth General on this map.

- The colour of the AI opponent is maroon.

- The game needs to be restarted after map transfer.

- Only one superweapon per player can be built.

- Recommended starting cash at least 20k.

- To conclude: The two players who will play the map needs to be in two upper slots in the game options.
  They should be in the same team. The game will be lost if both players are defeated.
  You can't play as Stealth General on this map.
  The colour of the AI opponent is maroon.
  Need to restart game after map transfer.
  Only one superweapon per player can be built.
  Recommended starting cash at least 20k.
  

The map has been tested and beaten.
If you find any bugs, you're welcome to report it to me by e-mail.

have fun!


Sriracha 
2021-04-06