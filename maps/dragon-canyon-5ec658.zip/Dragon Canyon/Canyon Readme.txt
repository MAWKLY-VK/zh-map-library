This map is for the game Command & Conquer: Generals - Zero Hour

Map Name: Dragon Canyon v5.2z

Map Author: Bhones

Released: 10/28/04

Map size: 400 X 250

Usage: Online or Skirmish mode against the computer

Players: 2

Description: This is the "Zero Hour" version of a map I released originally for "Generals". I had created a four player version of this map, but it seemed the top right and lower left areas weren't quite big enough to allow the AI enough space to build without bunching up, thus the two player version.

This map gained its name by the pattern the "view Impassable Areas" command yeilded in the Top Down view of WorldBuilder.

There are four stock piles, one to each corner, and an oil derrick on the left and right side of the map. I thought about using more of the Zero Hour texture sets, unique items and capture-ables, but decided to leave it be and move on.

Installation: Extract items in to: My Documents\Command And Conquer Generals Zero Hour Data\Maps.

please send any comments to  Bhones@AOL.com. Include "Dragon Canyon comments" in the subject.