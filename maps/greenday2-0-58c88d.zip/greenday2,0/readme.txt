hi generals a breifing before u play

this map was created for cncmaps.com
To place this map into the game put it
and its folder here: 
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

for those new to map editing use the
notepad program to open .str .files 
I stumbled around a lot before i 
found out about that.

map favors top left an bottom right
also favors usa generals air,lazer...
watch out for arouras they have  mod

I'd appreciate it if this map were 
left unmodified and in its orginal
condition, if u have an idea on how 
to inprove it, if u have a membership 
plz post your comment on cncmaps.net 
in my introduction "The New Lozer In Town" 

		   thx!!
		    Redlack

Greenday 2.0
Things you should know:
-sentry gun has special mod
-regular china is granted use of a naplam strike from there command center
-american humvee has a EMP missle be careful when moving them they can misfire!
-watch out the tech artillery cannons are more of a threat now!(use Arouras on them)

Most of the scipting came from cncmaps and the wonderful staff there thx!
if it isn't obvios this map is for 'C&C Gen ZH'