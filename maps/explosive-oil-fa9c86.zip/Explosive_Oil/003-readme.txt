:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "Explosive Oil"
[File Name]    = 003-Explosive_Oil.map
[File Size]    = 125 KB
[Map Size]     = 210 X 210
[Players]      = 2
[Time Setting] = Morning
[Field Intel]  = Mostly flat and open plains
[Resources]    = Medium-Low
-----------------------------------------------------------------


--< WARNING NOTICE >---------------------------------------------
Due to the nature of this map, this map cannot be played online.
Some of the scripts that are contained in this map will cause 
mismatches when attempting to play them.  This might not be the 
case in network/LAN play.  Attempt to at your own risk.

Should you want to play this map online, we suggest you use the 
online version of this map (as stated by 'NET').  It contains 
only the nessesary and workable scripts, and no skimrish scripts
are installed, therefore having a lower file size as indicated 
above.  However, some objects present in the normal version 
won't be available in the online version.

Therefore, use this map only for skimrish. Use the map w/ 'NET'
on it for online matches.
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Commander "Flippster" - Alliance HQ
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

Hey, General.  It's good to see that your doing quite well for
the Alliance.  But, I digress... There's a important job I have 
for you.

Do you know about the ??? Oil Zone in ???, Africa?  About 2 years
ago, scientists stumbled over some old ruins by accident.  During
the dig, they've suddenly hit a rich oil vein.  After further 
analysis, there was a huge deposit of oil underneath the bedrock.

A year later, oil companies have set up systems of oil derricks
to grab that precious oil.  This discovery have made lots of
people rich, yet about more than a billion dollars worth of oil
that remains untouched.  That lead to the problem we have today.

Even though the Chinese have wiped out the heart of the GLA, 
rements still linger.  Recent news tells us that a former GLA
sect known as the Dark Resistance have taken over much of the oil
field.  They're demanding that they will blow up the entire
reserve unless China stops its aggressive campaign against the 
GLA.

Now, your job remains clear.  Clear out the Resistance and any 
other threats and claim back the Oil Zone. Good luck.

        ______
  >>>>>/_____/>>>>>>>>>>>>>>>>>>>>>>>>
  >   ______   ** ALLIANCE HQ **     >
  >  /  ___/   Commander "Flippster  >
  >>/__/>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: Be ready for anything.  This area is highly guarded.   Be 
   aware that much of the units may be hidden.
:: Oil output and supplies are low. Our supply drops to your 
   base might not be enough. Capture and protect as many oil
   derricks as you can.
:: The government has banned the use of superweapons in the 
   country, so they won't be available in this mission.
   [NOTE FOR CHINESE GENERALS: Upgrades that were available at
   the Nuclear Silo can be found in the Propanganda Center]
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@mail.com
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================