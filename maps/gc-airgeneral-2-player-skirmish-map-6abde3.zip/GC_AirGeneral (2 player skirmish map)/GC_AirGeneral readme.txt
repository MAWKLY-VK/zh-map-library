*********GC_AirGeneral readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        GC_AirGeneral
Created by:  snowy007
Players:     2 players




installation:
--------------

unzip and put the folders in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

the official Air General map of the Generals challenge. i made 2 more 
enterences to the base in the left corner. 








