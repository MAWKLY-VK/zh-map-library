==========================================

Game: Command & Conquer Generals Zero Hour.

Author: map unknown to me , scripts by Johnny Bravo aka JB

******All the scripts are made by me Johnny Bravo from Gameranger******
The idea I get from gentool where it reveals at the loading screen which faction players get
after the random setup in the game room.The game announcements are really cool following 
by some awesome wise taunts after them.Because there are no announcements for 
vanila China, USA and GLA, I added the boss ones.But the wise taunts should give 
you a clue which faction you are facing.
The scripts work for the first 4 player slots in the game room.
First they check how many players are in the game, then determine 
if there are observers among them and how many they  are.
The announcement scripts work for any of the following combinations: 
2 players, 2 players & 1 observer, or 2 players and 2 observers - for game sreaming
with life comentary. :)


Enjoy

How to istall?
--------------

  You will have to copy or move the map folder with all the files inside it to 
 "%USERPROFILE%\My documents\Command & Conquer Generals Zero Hour Data\maps"
  Then you will have to run the game, go to maps and click on unofficial maps. There you 
  will find it.

How to uninstall?
-----------------
  
  You just delete the map folder
  in "%USERPROFILE%\My documents\Command & Conquer Generals Zero Hour Data\maps"
  

===========================================