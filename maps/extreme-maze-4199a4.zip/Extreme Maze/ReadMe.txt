HOW TO INSTALL:

1. Paste the "Extreme Maze" folder into your Generals save folder in: Desktop - My Documents - Generals Zero Hour Data - Maps 
2. Play the Maze in Skirmish mode, Unofficial Maps

ENJOY!