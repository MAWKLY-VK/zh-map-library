America versus Grainger
-------------------------
version 1.0
by beng

Here is a single player mission (modified from air force general's challenge map).

The map.ini gives your firebases flak guns. Firebases built within 500 distance
of each other will assist each other against air targets.

map.ini weapons cannot use projectiles, so for the flak explosion effects i
added them to the damageFX of airborne vehicles.

Firebases also have anti missile lasers.

The strategy centre cannon now has a battleship gun. To fire this you need a
colonel burton. Burton uses a button that needs to be used on objects to call for
fire from the this strategy centre artillery.

You can build the tomahawk storm. The Bunker busters upgrade makes the tomahawk
storm submunitions 30% more powerful. The composit armor upgrade makes the
tomahawk storm building stronger.

Airforce general has a B-52 that has air launched cruise missiles, an aurora
bomber with Frantan napalm bombs, and A-10's with cluster bombs.

Unexploded cluster bombs can be jammed with the Avenger laser so they do no
damage when they explode. They can be destroyed using the dozer or ambulance,
once they have cooled down and stopped smoking.

Hint: Stay out of the village area until you are ready to receive A10 and
carpet bomb attacks as going in the village will trigger these.

Build a lot of firebases and use spy drones to reveal stealth units.

There is an air force dozer you can liberate somewhere.