*************** Drive through *****************

- Map with RVMECH's AHAI 1.6
- Designed for four players (better in teams)
- Moderate amount of supplies
- Good for tournaments !
- Have fun :)

This map is copyright protected under license by Generals Oracle!
So it may be only downloaded from :
http://www.generalsoracle.pwp.blueyonder.co.uk/

greetz 2 all 
THX alot and greets to RVMECH for his work with AHAI !!!
-Funkiller-

contact: Funkiller_2000@web.de