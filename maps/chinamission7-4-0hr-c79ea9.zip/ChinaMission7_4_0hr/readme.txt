China Mission 7 for Zero Hour (Nuclear Winter) v 1.2
====================================================

This is a modified version of EA's China Mission 7 from the original Generals China campaign modified for Zero Hour by beng.
Feel free to use the map.ini stuff for your own maps.

You start with a mixed force of China generals vehicles types and 2 Nuke General dozers.

As in the original Generals mission, the GLA will only launch their scud storm when your money reaches $5000. If you keep your money less than this they will not launch it! If the GLA launch, they always aim at your highest cost area, which is usually your vehicles bunched together, so if you can do so, it may be useful to build a tunnel network near your vehicles so that you can quickly move them away if you get a scud storm launch warning. If the GLA launch the scud storm and you survive it, quickly build your own scud storm and then keep your money below $5000 to prevent them launching their scud storm again.

Remember that you are the Nuke General and he has some special advantages over a standard China army. Exploit these.

There are some extra goodies for you to find and liberate, and the GLA will also use new Zero Hour powers and tactics.


Installation:
-------------
Unzip and put the folder named "ChinaMission7_4_0hr" in your map folder, usually:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

Start Zero Hour, go to Skirmish, Select Map, Unofficial Maps, and load the map ChinaMission7_4_0hr.


Bugs:
-----
As in the original mission, the frame rate can become slow and jerky so if you don't have one of the fastest computers, it may help to decrease the graphics resolution etc. I have tried to lessen the processor load by removing all the three way blended textures i could find and thinning out the trees a lot, but it still becomes jerky on my machine when the GLA attack is in full tilt.

Sometimes saved games will crash (like if Jarmen sniped a dragon tank, then you upgraded to black napalm, then recaptured that tank, then saved, it will crash), so save in more than one slot.


New Units:
----------
You get a Super Lotus who can climb cliffs and kill enemy infantry with her lotus fist kung fu. She can also kill stinger site crew though she will get damaged in the process.

You also get a new hero type, the Chinese Secret Agent. He speaks with an American accent because he is trained by the School of the Americas in counter-terrorist bomb making techniques. He can build 2 types of bombs:

1. The INEMPD (Improvised Nuclear EMP Device) explodes a tactical nuclear bomb similar to the helix nuclear bomb in yield. The blast pumps a high power microwave (HPM) pulse generator which immobilises nearby vehicles, forcing them to stay in the radiation field from the blast. It also disables nearby buildings for 30 seconds. This bomb defaults to manual mode, but can be switched to proximity detonation.

2. The Neutron Booby Trap is a bounding mine that explodes with neutron effects, killing all nearby infantry including the drivers of vehicles and infantry in garrisoned buildings. It defaults to manual mode too. Immobilised vehicles can block those narrow city streats and create traffic jams.

3. The secreat agent can also attach improved TNT charges to vehicles and structures like the tank hunter. Whilst less powerful than Col Burton's C4 charges, these can usually incapacitate a base defence with one blast, and is useful for finishing off GLA building holes left by nuclear missile strikes.

The agent can also defuse enemy demo traps and mines using his made in china tools, and climb cliffs.

The Nuke General's Mig has been given better weapons. The default EA Games version has Nuke_MiGMissileWeapon (damage=100) to start with and gets Nuke_NukeMissileWeapon (damage=150) when the tactical nuclear Mig upgrade is purchased. The version in this map gets Nuke_NukeMissileWeapon to start with, and is upgradaded to NukeMissileWeapon (damage=300).

Migs also get a command button that lets you fire just one missile, useful for engaging two targets on 1 sortie.

If you see a UAV spy drone appear somewhere, you can select it and move it around.


Version 1.1 Changes
-------------------
GLA paradrop garrison teams now spawn off the map and fly in instead of spawning in the city.
Bunker Garrisons will garrison their bunkers.
Deleted all civilian infantry to try and improve frame rate.
Civilian dozers work properly.

Version 1.2 changes
-------------------
Agents are now stealth garrisonable, the GLA will not attack buildings if they garrison them.
Reinforcements should now come when you garrison the spy post.
GLA time between building teams increased to 20 seconds.
Boss Avenger now gains rank from shooting down missiles.
