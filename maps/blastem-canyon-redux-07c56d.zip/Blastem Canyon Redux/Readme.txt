Blastem Canyon Redux
============================

Created by: Doug "SCSI4u2" Farley 

Size: Med-Large
Players: 4
Skirmish: Yes
MultiPlay: Yes
Resources: Above Average
Dev Time: Week +- a Week =P

==================================
	INSTALL
==================================

Dump in your maps dir.

==================================
	Comments
==================================

Back with the original RA I created a set of maps called
Blast'em Canyon, mostly for LAN and modem play, they were posted
to a few BBS sites, and circulated by many a friend.  This is my second
Attempt at a Generals Map, hope it lives up to what I used
to make.

I tried my hardest to keep this map balanced, while adding enough cash
and surprises for the player.  I've added maybe too much pathing for the
AI, it seems to stop and cordinate its attacks at a few key points, but 
besides that its agressive!  Each player has 1 Oil rig that is easy to hold
and/or control, thus insuring that they have at least some income, but then
every postion has at least 2 more oil rigs that are MUCH harder to keep.
I've found that the Brutal AI seems to get tired of retaking them from you
so they will eventually destroy them, but it can be a challange to keep
them from Humans.  Some of the cliffs are a bit high for aircraft 
(Mostly Paratroopers) and i've seen a few paratroopers occasionally get
stuck, but an enemy will take care of them quick.  

I sometimes find the Super Weapons annoying in Multiplayer games vs. Humans,
so they have been removed as a major threat in the game.  I think ground/AIR
attacks without them are more enjoyable.  Just my 2 cents, you can still 
build them (So China still gets their overloard upgrades), they just 
take FOREVER to charge. ;o)

If you find any bugs, _PLEASE_ e-mail me to let me know! I want to keep 
the map free of anything critical.

SCSI4u2

Feel Free to repost/host this map whereever you wish (drop me an e-mail 
if you do! I like to know where my maps end up!), just keep the files intact.  
If you make changes, credit me, and send me a copy of your changes.

<SHOUTnRANT>
Thanks to EAP/Westwood for making Generals, and for keep Promising they'll 'fix'
the network issues that make me loose sync in so many local lan games.
Been Playin their games since 'Dune 2'.
</SHOUTnRANT>