
Name of map:Castle on the mountaintop

Author: yuug254 

For the game, Command and Conquer Generals Zero Hour

Description:
This is a skirmish 2-player map, 1 player starts on the northwest part of the map while the other starts on the northeast part. Both players will begin with 2 passages each to exit and enter.
Plenty of land to build on but limited routes you can take to your enemy's base. Plenty of goodies around the map. 

To install extract the map folder into:
My Documents\Command and Conquer Generals Zero Hour Data\Maps


yuug254

