                                       _/BREAKPOINT\_

                                  Created by [AGM]Launcher
          *Special thanks to Triumph for detail and and balance tweak suggestions*


My intent in creating this map was to provide a more team based starting area setup. In most of EA's maps, you are too far away to help your ally when he needs it. Unless you have ESP, its impossible to really give your ally a hand ahead of time or before its too late. This 2v2 map puts both players from each team closer to each other so that they can coordinate defense better.

The map layout features asymmetric terrain for each player per team, but overall symmetry per team. Both players on a team have two jobs to ensure strategic control of the map. One player must setup a defense on the flank close to him while securing the middle. The other player should expand to the more distant flank on his side of a small river while helping his ally secure the middle. The purpose of this is to create a deeper team strategy than most perfectly symmetrical maps, which end up being nothing more than two 1v1s occuring at the same time on the same terrain respective to each side of the map.

Features:
<- 1 main supply pile per player
<- Numerous small supplies towards the middle, in the middle, and on the flanks
<- 4 oil derricks
<- 2 artillery platforms in the middle 
<- 2 tech repair bays (one in each corner)
<- 8 takeable vehicles for GLA (2 in the middle for quick anti-dozer solutions)
<- Numerous garrisons to help protect your captured investments
<- Small footbridges that only small groups of units can cross on the very extremes of each    flank river. This is intended to help sneak heros or any stealthed units around away         from traditional scans and spy drone placements. To help keep vehicle traffic down,    garrisons are near these little crossings for protection. Of course hero units wont be    affected by these at all.
<- Hidden pathways on the mountains behind each team which allow you to sneak support units     in behind your ally's base to support him. There is also room at the top to build tunnels    and various defensive structures to help detect any stealthed Comanches hiding out in the    corners.
<- Pathways on the mountains in the middle for special attacks.
<- No built in mods on this map. 
<- For Multiplayer Online or Skirmish Mode. AI is enabled.

--------------
[AGM]Launcher
Replay Reviewer
cncreplays.com

lemue@wpi.edu

This map was downloaded from CNCDEN.com
Covering the entire C&C Universe of games.