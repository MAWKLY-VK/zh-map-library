MAP ::  Head Russian

AUTHOR :: WACKWARDS

PLAYERS :: 4vs4

STYLE :: Symetrical

AI :: SDI TEAM

INFO :: 

* Straight forward team based map.
* Various Buildings.  
* Desert Map with high mountains thru the center.
* 2 Particle Cannons and Custom Water Added.