*********mission superheroes++ readme*************
Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        Mission Superheroes++
Created by:  snowy007
map.ini (and some other changes) by: beng

Players:     1 player

Original mission "Mission superhero's" located at:
http://www.cncmaps.com/zerohourmissions.html


installation:
--------------

unzip and put the folder in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\



description:
------------

This is a 1 player mission. the GLA have taken over a Chinese base.
Your main objective will be to recapture the Chinese base from the GLA.
You will have Colonel Burton, Black Lotus and Jarmen Kell under your command.
The Chinees base is heavily defended. Find a way to disable the base defences.
When you enter the Chinese base you must destroy the speaker towers and the
internet center. Make sure you capture intact all the other Chinese buildings
in the base. Note: you only need to capture 5 US power plants.
The 3 heros MUST stay alive or you lose.



Some notes on this ++ version:
------------------------------

Your only source of cash at the start will be the cash bounty power.
Upgrade it to level 3 when you have enough points.

Jarmen Kell can kill infantry garrisoned inside buildings with a toxic
flechette gun once you buy the chain guns upgrade. The gun is so powerful
it can kill groups of infantry with one shot if they are standing close
together. The chain guns upgrade also gives him a faster reloading vehicle
sniping gun. Force fire him on empty looking buildings to check for hidden
snipers.

Hijackers will add their rank to the vehicle like pilots.

Mini gunners and their upgrades:
run faster:            Upgrade_AmericaAdvancedTraining OR Upgrade_GLAWorkerShoes
get quad cannon+ guns: Upgrade_ChinaChainGuns          OR Upgrade_Veterancy_ELITE
get +25% damage:       Upgrade_GLAAPBullets            OR Upgrade_Veterancy_HEROIC
gain rank faster:      Upgrade_AmericaAdvancedTraining
get chemical suit:     Upgrade_AmericaChemicalSuits

You can buy some upgrades from the hospital.

Artillery platforms can be upgraded to fire nuke canon shells.

Garrison the boat factory to stop the GLA building more PT boats in the
river near your base. You can also build 1 boat with the factory using
the Gattling upgrade button, you can build it again if it sinks.
The boat's drone can shoot missiles and shells, making it hard to kill
using projectile weapons. It comes with 4 sailors who can swim and
climb cliffs.

When you are fighting PT boats, tell your units to target the gunner on
the deck first, this will reduce the amount of firepower the boat can use
on you and give you an extra cash bounty and experience points. Also,
without the gunner the boat cannot detect stealth.

Tunnel networks will spawn new infantry to guard them if the infantry
that guard them are killed.

Burton can stab some vehicles with his knife to kill them quietly.
Burton can also stab stinger sites. Lotus and Burton can thus work
together to take out sentry drones quietly.

Your dozer is very tough, use it to draw fire from artillery platforms
etc while Lotus captures it. The dozer can also clean up toxins.

If you capture the reinforcement pad you will get up to 12 special
tomahawk vehicles from it. These can be upgraded with the neutron
shells upgrade which gives them a very long range stinger missile
(not neutron shells). You have to discover where you can find the
neutron shells upgrade.

When you can get workers, build a command center to get some
additional powers.

There are hidden goodies in some buildings.

Take your time and save often, and in different slots!

You can play it with just the 3 heroes running around, or you can get
a bunch of vehicles to help you by shooting up your tunnel network
and letting the hole rebuild to get new infantry to take over sniped
vehicles.

At certain points you come across obstacles, sometimes indestructable
things blocking your way. Don't worry, there is a way around them or
you are not meant to go there yet.


Bugs:
-----
Sometimes the game will stop being able to be saved. When this bug happens,
when you try and save you get an Error message. If this happens, delete the
savedgame slot you just tried to save as it is corrupted, then reload from
a previous save as your current session cannot be saved any more. After
you reload from a working slot you can usually carry on and still save
the game.

I do not know what causes this, if you have any idea let me (beng) know in
the forum http://cncmaps.net . Just save often and in different slots,
so that if the game stops being savable you can reload from a previous
slot and continue from there. Also, sometimes the game will crash after
you win.

Another bug is when a PT boat explodes sometimes the frame rate drops
very low. I do not know what causes this (perhaps something to do with
the infantry coming out over water while the boat is flipping around?),
it is not the particle effects as i tried turning them all off and it still
happened. You just have to bear with it when it happens and just wait a
while for the frame rate to come back to normal. Just pretend it's a
"bullet time" special effect.

Another bug is, when you reload from a saved game, Jarmen Kell will
keep using the same weapon after he's fired it. So, after you tell him
to snipe a vehicle, he will keep using the vehicle sniping weapon
even though you do not click the snipe vehicle command button. He
will even snipe sentry drones.


