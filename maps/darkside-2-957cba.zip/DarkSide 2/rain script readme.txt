You downloaded this file from CNCDEN

http://www.cncden.com


Description:

Zero Hour map script

Place the map INI file inside your map folder that contains your other files that make up your map. (.tga and .map files). This script simulates rain in your map.

Thanks to CNCDEN staffer RVMECH for this map script.