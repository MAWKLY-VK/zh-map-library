A.I. Island created by: stairwaytoheaven

The map was designed to be a 2v5 compstomp map

Permission given to CnCmaps to host, if you would like to host it email me at stairwaytoheaven@cncmaps.net

Special thanks given to Thomasalan of Cncmaps for the the scripting help

Things you should know:
-you can use the the hovercrafts to attack the computer from the back with the use of the hover crafts.
 -i recomend that you put a dozer/worker in and build to start a two front war
-gla player can capture the power plants for power if they would like to use the crusie missle
-regular china is granted use of a naplam strike from there command center
-regualar american crusader has a machine gun 
-watch out the tech artillery cannons are more of a threat now!(use aircraft on them)

happy gaming gaming general