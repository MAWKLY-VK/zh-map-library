Zero Hour Mission

created by: by saalkin

Mission name: The Rerise



This is a misson that's part 1 of a series of missions I'll be making. Your playing as the GLA and your misson is to rescue Jarman Kell from the USA troops. He is being held captive in a prison. Since the GLA has suffered major loses in the war, there's not much help available. In the city you can recruit some GLA mobs to assist you. You must destroy all opposing forces and all buildings. Jarmen Kell is in the Secret Lab. Once that is destroyed you can claim victory...Good luck!

HINTS:

Go to the GLA Mob on the right side of the map first. When you drive up to them they will join you in your fight to get to the prison where Jarmen Kell is being held captive.

There's another GLA Mob near the center of the city...recruit them as well, taking out any USA vehicles you encounter. After you have taken out the USA forces in the city head to the West where you'll find a small army base where Jarmen is. 







