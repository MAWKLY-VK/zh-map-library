:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "The Dying Daylights"
[Author]       = flippster06
[File Name]    = 011-The_Dying_Daylights.map
[File Size]    = 49 KB
[Map Size]     = ??? X ???
[Players]      = 2 only
[Time Setting] = Afternoon
[Field Intel]  = Urban
[Resources]    = High
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

**** Argentina's Troubles Doubles ****
By ~~~~~~~~~~~~~~~~~

Buenos Aires, Argentina (AP) - Protests have been held outside 
the governmental building for a fifth day in a row. The mayor 
has already deployed riot police to curb the rowdy crowds, but 
the people have urged the government that they will be heard.

The source of their anger goes back to the last few weeks. The 
GLA have apparently backed the local Argentinian rebel militas. 
With re-newed source of power, many major towns have been hit by 
these militas. The Argentinian military were able to push back 
many of the attacks, but with devastating cost in the form of 
property damage and civilian casualties.

The people of the nation are urging the government for more 
help. However, the President have said in a news conference that 
they simply do not have enough man-power to keep going. Protests 
started a few days ago at the fact that more of their people are 
dying at the hands of the GLA, and the government is doing 
little to stop them.

GLA WANTS CONTROL

In an related story, U.S. officials have anlysized the documents 
recently recovered in an abandoned house in Iraq. It states 
recent reports of Argentina's oil exports. The GLA seem to have 
an interest in this matter. When asked if this could be the 
reason that the GLA is backing local militias over there, the 
U.S. Secretary Of State said nothing of the matter.

What disturbs most people is the fact that in one of the 
documents, there states a plan to attack Buenos Aires via some
kind of chemical attack. Whether this plan is tangible and 
possibly being carried out is uncertain, although the U.S. 
denies the claim.

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: From the information recovered, there is a credible threat 
   directed towards Buenos Aires. The nature of this threat is 
   unknown, so be prepared for anything.
:: In the middle of the district you are in is a Satellite
   Station. Garrison it to get a full view of the map.
:: Superweapons are banned in this mission.
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * Alliance website = http://alliance.cncdepot.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================