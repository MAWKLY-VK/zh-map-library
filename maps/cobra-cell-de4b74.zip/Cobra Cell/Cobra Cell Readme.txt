
Cobra Cell (ZH) (a SP mission for C&CG Zero Hour)
_____________________________________________________________________________________

Breifing
_____________________________________________________________________________________

	Welcome General,

	Your GLA Cell (code named cobra cell) is on US soil. You are to strike
	a major city. Detailed objectives are below.

	Objective 1: Destroy the supply trucks before they reach the airport

	Objective 2: Destroy the airport

	Objective 3: Search the city and destroy all target civilian buildings
	(Target buildings show up red on radar and display red tooltips)

	Objective 4: Eliminate all USA military buildings

	* Difficulty of mission set to medium

_____________________________________________________________________________________

Features
_____________________________________________________________________________________

	- Multiple chances at using various tactics to win
	- Mulitple routes to AI base
	- AI Attack triggers
	- Instant action
	- Ambient sounds set mood
	- Detailed city environment
_____________________________________________________________________________________

Hints
_____________________________________________________________________________________

	Hint #1: Individual Ability

	Check out the abilities of each type of unit you have at your disposal.

	Hint #2: Speed

	Move your units quickly in the beginning of the mission.
_____________________________________________________________________________________

Public Testing
_____________________________________________________________________________________

	To make sure that the maps that I make are quite a high standard I have now
	launched a public testing policy. After I release a map you can report bugs
	or landscape issues to deankrause@hotmail.com.

	If enough bugs or errors have been reported I will fix them and rerelease the
	map.
_____________________________________________________________________________________

Mission Note
_____________________________________________________________________________________

	Missions in general often require more graphical resources than skirmish or
	online maps. This mission is not exception to that rule.

	If you are having problems running the mission consider changing the options 
	and lowering the quality of graphics and/or switching of taxing features.
_____________________________________________________________________________________

Installation
_____________________________________________________________________________________

	To install read the instructions in the Zero Hour manual on page 41.
_____________________________________________________________________________________

Maps
_____________________________________________________________________________________

(In release order)

Pack of Ten [Map Pack #1]

	The Sands of Time (ZH)  @ cncden.com
	Mount Olympus (ZH) @ cncden.com
	Octoberfest (ZH) @ cncden.com
	Cliffhanger [General Challenge] (ZH) @ cncden.com
	Fight for All (ZH) @ cncden.com
	Preemptive Strike (ZH) @ cncden.com
	Minesweeper (ZH) @ cncden.com
	Head 2 Head (ZH) @ cncden.com
	Rush (ZH) SP MISSION @ cncden.com
	Wastegrounds(ZH) @ cncden.com

Pack of Ten [Map Pack #2]

	Mercury Falling (ZH) @ cncden.com
	Black Squadron (ZH) SP MISSION @ cncden.com
	Headstrong Attack (ZH) @ cncden.com
	Desert City (ZH) @ cncden.com
	Bring it On! @ cncden.com
	Frozen @ cncden.com
	Close Encounter (ZH) @ cncden.com
	Useful Technology (ZH) SP MISSION
	Up Close and Personal (ZH) @ cncden.com
	American Beauty (ZH) @ cncden.com

New Maps

	Communication Breakdown (ZH) SP MISSION @ cncden.com
	Sudden Strike (ZH) SP MISSION @ cncden.com

NOTE: All my maps are available from my website, DK Online.

I created maps for cncden.com for a while under the nickname of "Headcracker"

My old Yuri's Revenge maps are available here:

	http://www.cncgames.com/maps_headcracker.shtml
_____________________________________________________________________________________

My Website
_____________________________________________________________________________________

If you like my maps please take the time to visit my website:

	http://thekrause.idx.com.au
_____________________________________________________________________________________

This C&C Generals Zero Hour SP map was created by Dean Krause on the 6th of February
2004. This map is copyright Dean Krause 2004.