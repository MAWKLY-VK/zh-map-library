This map is for the game Command & Conquer: Generals

Map Name: FootBall Mayhem

Map Author: Thrawn28  (Englands Biggest Slacker)

Released: 17/09/03

Map size: 200 x 400

Usage: Online or Skirmish mode against the computer

Players: 2-4

Description:a larger version of my football mayhem map 

all you football nuts out there will like it im sure 
the map contains a moderate amount of supplies so use them wisely and dont forget to capture those oil derricks 
(the map contains 4 derricks and 2 refinerys)

Note:this map use's RVMECH's almost human Ai 


Installation: Unzip and place  folder in:
My Documents->Command And Conquer Generals Data->Maps
...and enjoy!

please send any comments to  de_thrawn@msn.com