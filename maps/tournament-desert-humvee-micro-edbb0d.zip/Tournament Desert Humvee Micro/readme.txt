Welcome Generals.

If you need to get in touch, advise or ask anything, please email me on

the-onejundiyy@hotmail.com

I also have a youtube channel, if you have any good action replays, please also email them to me or message me on youtube.
Please have action in the replay and not bunkering games only, or one sided.

https://www.youtube.com/channel/UC4UY-HVad4kfaGwa-lVKUtg

Thanks for playing my maps, you can download many more of my maps on this website.

https://www.gamereplays.org/community/index.php?showtopic=990750

I also turn my survival maps into official maps, these can be downloaded below.

https://www.gamereplays.org/community/index.php?showtopic=989603&pid=9982525&st=0&#entry9982525

Sometimes I may edit a map, this will be told at the begining of the map, something like Welcome to xxxxx by xxx edit/revised by The-One/Jundiyy.