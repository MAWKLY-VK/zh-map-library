Map Info:
---------

-Map Made for: C&C Zero Hour expansion
-Date: 27th sept 2004 
-Map: Full art of defense v11 
-Author: Rigel6669 
-Size: 300x380
-Climate: dirt 
-Time of day: Morning
-Players: 5 
-Type: Multiplayer/Skirmish
-Resources: 1 money crate + 2 supply docks + 4 oil derricks for each player

            
Theme: ATLANTIC WALL - UTAH BEACH
**********************************

Scripted team map for co�perative online ( or LAN ) play. 
Put the starting position of the USA AI north

On this map the AI will mostly defend its own base and its up to the human players to
attack and complete a specified objective within 12 minutes of play

The AI base is situated on the northern side across the water
Use air units or capture the bonus vehicles ( chinooks and hovercrafts ) to reach
the ai base   


By choosing the army ( easy, medium, hard ) a different mission will be activated.


Easy = mission 1 = Assasinate 20 enemy snipers 
Minimal AI attack on the human base without sw


Medium = mission 2 = Destroy museum + radar outposts + labs to launch the Baikonur rockets
Moderate AI attack on the human base with 1 sw


Hard = mission 3 = Destroy all enemy airfields 
The AI will continously attack by air and tunnels

In mission 3 the AI will also use 5 fast loading superweapons ( scud, nuke, particle, 
cruise and neutron missle ) during 6 min of play. 
Destroy 1 of the labs ( north ) to reset the sw timers.

A good strategy is to destroy 1 lab and wait for the sw to come back online before you 
destroy the 2nd lab to maximise the offline time of the sw. 



E-mail: rigel6669@yahoo.com



New updates:
------------
- new "atlantic wall" beach map  
- new ai base defense script
- added sneak attack ability
- units spawning from inside sneak tunnel and gla tunnel
- new team: demo burton using the timed demo charge attack


My other zero hour maps:
------------------------ 
Desert Sphinx ( 6 ) - Bermuda 3angle zh ( 6 ) - The_Crossroads ( 6 ) - Fortified_Canyon ( 6 )
Knife_fight 8 ( 8 ) - Bermuda_8_triangle ( 8 ) - Wall_of_china ( 6 ) - Infantry strike II ( 6 )
Full art of defense v5 to v9 ( 7 ) - Full art of defense v10 ( 5 )



Installation:
-------------

Unzip the complete map folder in: my documents/command and conquer generals zero hour data/maps
Select the map in the unofficial maps tab 


Copyright:
----------

I hereby only give permission to post this map on www.cncden.com and cnc.filefront.com 
Do not modify, copy and/or use the mapscript or map without permission of the author

Map design and scripts by Rigel6669 � 2004


Special thanks to the following maptesters: [EX]Pethegreat and popeye




Note concerning illegal copying:
--------------------------------

You can view or reply on a thread concerning this subject "zh maps being
stolen" by going to the den forum http://forums.cncden.com/showthread.php?t=2319


Blacklisted illegal script copiers: Uncle_osama, titus-21-, agent_grinch, mrg69, neocell
-----------------------------------
  
