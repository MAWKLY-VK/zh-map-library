Mission POW Capture 1.1
-----------------------
by beng

This is a singple player mission for Zero Hour 1.04, made mainly to test a map.ini that enables
you to get money from POWs using a POW truck.

You can build a POW truck from your prison. It can be upgraded wtith flashbang grenades upgrade which
enables it to use tranquiliser darts to capture enemy infantry as POWs.

It also has a general purpose machine gun. AP bullets upgrade makes it's GPMG do 25% more damage.

The POW truck can also be upgraded with the camo netting upgrade, which enables it to disguise as
other vehicles, like a bomb truck.

When you use the darts to shoot enemy rangers, missile defenders, or pathfinders, they will surrender
and drop their supplies, which your POW truck or other harvesters can then collect and bring back
to the prison as ransom money.

The POW truck has 6 slots for transporting infantry or some vehicles, you can use it to smuggle things
into the enemy base when his patriots are powered down.

There are some hidden goodies around the map.

You win by destroying all US factories.

Tip: once you cross the bridge to the enemy side of the river the enemy attacks become stronger,
so you may wish to not cross that bridge until you have built up some defences.


Version 1.1 changes:

Saboteurs can now TNT faction buildings without entering them.

There is a hidden tech repair bay to capture somewhere on the map,
it will repair all your units and buildings.

Stealth jets have longer range weapons and can shoot their 2 missiles at different targets.

Computer will use his jets.

POW truck darts now fire better uphill.

Firebases have anti air flak weapons.

Tunnel networks and other things that didn't before will now make salvage crates from enemy vehicles.

Some other chages you will find when you play.








Info for ini coders:

This is how it works: The POW truck fires a projectile (GC_Slth_JarmenKellBullet) that OCLs a short
lived temporary object (CINE_DemoTrapDetonationObject) when it detonates. The projectile also fires
a weapon when it detonates (JarmenKellBulletDamageWeapon), and this weapon kills the infantry
with death type TOPPLED.

When the infantry dies with death type TOPPLED, it fires a weapon that kills the temporary object
(CINE_DemoTrapDetonationObject) that the POW truck projeectile OCLed. The weapon is specific to each
infantry:
ranger fires RgrDeathStatusWeapon
middile defender fires MDeathStatusWeapon
pathfinder fires PFDeathStatusWeapon

Each infantry's death weapon causes the temporary object to die with a certain death type.
Depending on which death type it dies with, it then OCLs the appropriate supply pile for that
infantry type (which i made from rarely used crateobjects).

I tried using status weapons to tell the temporary object which supply pile to OCL but it did
not work so i am using death types.

Also, i tried crate behaviors but this also did not work with suppli piles.

Simply making the infantry OCL the supply pile also did not work because it then belonged to
the infantry's team, and my harvesters could not collect it. The supply pile must belong to
civilian or to your own team for you to be able to harvest from it.
