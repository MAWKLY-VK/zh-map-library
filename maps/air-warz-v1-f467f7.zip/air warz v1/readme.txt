theres 6 air cariers a 3vs3 oil and oil refinerys in corner connected by a bridge
the 2 land masses are not connected in anyway day time is night