City Of Stadium Lovers by nolon

My 1st ZH map that I origanally designed for Yuri's revenge, designed for those who have a siege mentality. Made for 2vs3 play or if your brave 1vs3 play.