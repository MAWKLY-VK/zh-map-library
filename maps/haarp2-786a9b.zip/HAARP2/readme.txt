HAARP2 by beng
=================

Single player mission for Zero Hour.

This is a test map for HAARP earthquake superweapon code. It is a modified version of the
USA mission from Generals where you fight the GLA and China.

The HAARP code is in map.ini, other code for other objects in the map is in solo.ini
Feel free to copy anything you like in the code for your own map.inis, as long as you state the source of it.


Tips for playing:

Avengers can shoot down shells.
Base defences can also, to a more limited extent.
Capture the artillery platforms and upgrade them to make them shoot faster.
Nuke and scud storm missiles can be shot down by concentrated air defences.
Build your supply dropzones along the left edge of the map so the planes fly over the
enemy base - they are armed.
Stealth jet missiles can unman vehicles.