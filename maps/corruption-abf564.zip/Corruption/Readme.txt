Thanks for downloading "Corruption" by Osey

Based on an apocalyptic city setting "Corruption" is a huge 8 player 
tournament style map featuring rain and ligthing scripts, its dark
its deserted! its corruption!

Players= 8
Size= V.Large
Resources= Many
Play Method= Top right vrs Bottom left
                     Or Bottom right vrs Top left

Thanks to "RVMECH" for the weather scripts :)

if you have any problems or want to submit feedback please e-mail
me at: os3y03@msn.com
