Map is based on El_Chapo's templates!
Thanks again for that, really helped.
El_Chapo: https://www.gamereplays.org/community/index.php?showuser=625355