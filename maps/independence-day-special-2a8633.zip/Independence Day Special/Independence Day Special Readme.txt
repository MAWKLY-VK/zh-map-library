YOU DOWNLOADED A GENERALS ZERO HOUR MAP:                            NO MOD PROBLEMS
        Independence Day Special
           By. sgtmyers88
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!!!

TO ACCESS:
extract, copy, and paste the Independence Day Special Files to your Generals Zero hour map data Directory

OVERVIEW:
I just tried something different (and very unrealistic lol).
It was the 4th of July and I was playing C&C Generals when I got the idea to make a special 
Independence Day Map So I made a map with some red white and blue textures and formed 
a giant flag as the playing field and some borders and lumps so the terrain wouldn't be 
too bland. Since the "4th" of July is Independence Day I added "4" players. 
Soon I had made a 4 player AI or multiplayer map with the floor appearing to be
draped with a giant American Flag to play on. 

TIP: IT WOULD BE BEST THAT YOU DO NOT REALLY USE AN AMERICAN FLAG AS A PLAYMAT.
THANK YOU

SPECIAL NOTE: I tried to make stars but they turned out crappy sorry.

ALSO YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!!!

NO BUGS OR PROBLEMS WITH THIS MAP!!!


"Have fun, enjoy, and HAPPY INDEPENDENCE DAY USA!!!"

2005 sgtmyers88 
                                      "God Bless America"