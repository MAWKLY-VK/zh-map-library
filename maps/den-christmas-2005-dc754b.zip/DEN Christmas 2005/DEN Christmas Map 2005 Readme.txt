THE DEN'S ANNUAL CHRISTMAS MAP

You downloaded this map from CNCDEN - http://www.cncden.com
email: dalion@comcast.net

CNCDEN covers everything in the Command & Conquer Universe of Games as has available for downloading hundreds of maps, mods, game replays, wallpapers, etc. Daily news updates, an active forum, and so much more!

This map is for the game Command & Conquer Generals: Zero Hour

Map Name: DEN Christmas Map 2005
Map Author: Lion (Webmaster - Den Games Network)
Released: December 22, 2005
Map size: 300x250
Map type: Snow/Mountains
Use: Skirmish (AI enabled) or Multiplayer Online
Players: 2-4

Map Description: This is a 4-player team based or FFA multi-level Snow map, but works great in skirmish mode against the AI. Plenty of room to expand your base, and an adequate supply of cash to keep your army on the go. Each player starts with two supply docks. More money on the battlefield to fight over. The large mountain/plateau in the center of the map is filled with Christmas presents under the trees! A variety of tech structures including oil derricks and some tank crates scattered about the map. Lots of strategic possibilities with back entrances to the enemy camp. A few buildings and bunkers on the battlefield to garrison. Watch out for the train, which by the way can be garrisoned with troops and vehicles. The train will stop at two different locations for 20 seconds each time. You can load up vehicles and infantry and manually unload them at the next stop. I don't have it set for auto disembark. Enjoy the map!

Directions for playing: To use the map, look in your computer for a folder named C:/My Document/Command and Conquer Generals Zero Hour data/Maps. If this directory doesn't exist, play a skirmish map and comeback. The folder should be there now. Extract the COMPLETE FOLDER included in the map zip file in the C:/My Document/Command and Conquer Generals Zero Hour data/Maps. Fire up the game and you should be good to go. Look for the map in the Unofficial Maps section. You can use the map for online play or skirmish against the computer. Works great both ways! Enjoy the map...


This map is exclusive to CNCDEN and is copyrighted 2005. You may use it for personal use. Please do NOT modify the map and call it your own. I spent many hours creating the map.

Long live the memory of Westwood Studios...