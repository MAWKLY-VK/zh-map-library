Map Author: Judds
Size: 450x450
Weather Thunder storm/ high winds
Created for www.cncmaps.com
Night time setting with ambient sounds throughout.
Time to Build: 7 hours from start to finish.
Email: judds@cncgames.every1.net

This map is a huge landscape, with 450 x 450 you will find many routes and levels to battle on, the map is made up of lots and lots of small islands conected with bridges, narrow roads and ramps, throughout the map you will find many useful building which you can capture to make your army the stronger party in battle. As this map is set at night the thunder storm and rain are accompanied along with high winds and the sounds of a rough tide. 

Fight strong and hard and enjoy the map. any comments or problems please feel free to email me. thanks,

Judds