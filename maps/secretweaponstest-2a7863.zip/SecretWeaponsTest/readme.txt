Secret Weapons Test map by beng
--------------------------------

This map was created mainly to test some map.ini concepts i am experimenting with.
I didn't put much effort into cut scenes or fancy scripts.
Its pretty basic.

Difficulty level is easy, its not so much a challenge as for those who like to blow things up.

You win by destroying all GLA buildings including base defences in the GLA base to the north (the area behind the wall).


Installation:
-------------
Unzip and put the folder named "SecretWeaponsTest" in your map folder, usually:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

Start Zero Hour, go to Skirmish, Select Map, Unofficial Maps, and load the map SecretWeaponsTest.


Scenario:
---------
You are being given new experimental prototype secret weapons developed by American arms manufacturers to test under battle conditions.

Long range WMD vehicles: 2 New units:

1.) The Cruise Missile launcher is an improved version of the tomahawk, 25% bigger than the original vehicle, that launches devasting long range cruise missiles. They can be shot down by concentrated AA defences however, and have a low flight profile to fly under enemy radar, and so may crash into tall buildings.

2.) The ScudStorm Launcher vehicle launches 9 scud missiles at a time. These fly higher than the cruise missiles and so are more vulnerable to fire from ground units. As it is still in the prototype stage there may be some problems with the missiles, notably the explosions of the first missiles to hit the target sometimes destroys other missiles following close behind. This is made more likely if they are weakened by AA fire on their way to the target.

These 2 new weapons plus the battleships can be fired via the battleship fire shotcut button on your screen. Their weapons take 20 seconds to reload.

A third weapon, the Ordos Deviator, has been developed by a Chinese arms manufacturer based inthe Ordos desert in Inner Mongolia. It is a modified copy of the Tomahawk which fires missiles loaded with a special nerve gas that can cause the drivers of enemy vehicles to become mind controlled by our side. This is useful for capturing enemy vehicles and recapturing hijacked vehicles. It does not work on ships or aircraft.

We have furnished you with a heavily armoured amphibious transport vehicle that can enable you to land your troops behind enemy lines. Be advised however, that there are GLA pirate ships operating in the sea.

Your main source of funding will be a detention camp. You are authorised to use special interrogation techniques to make terrorist suspects reveal their bank account details so that their assets can be seized and used to fund our war effort. If this building is damaged below 30% it will stop producing funds until repaired.



To get these units for your own map just copy the map.ini file into the folder you map is in.
The changed units are:

Object CruiseMissile (projectile used by Superweapon General's Cruise Missile building)
Object Lazr_AmericaVehicleTomahawk (vehicle in Laser general's list, not normally buildable)
Object GC_Chem_ScudStormMissile (projectile, also used by GC_CHem's scudstorm building)
Object Demo_ScudStormMissile (projectile, also used by Demo general's scudstorm building)
Object Slth_GLAVehicleScudLauncher (Vehicle in stealth general's list, not normally buildable)
Object SupW_AmericaVehicleTomahawk made parachutable and given longer sight range
Object ScudStormMissile now shows on the radar and can be seen flying as it flies like the normal scud missile,
       can also be shot down but only with very concentrated AA defences.
Object GLAInfantryJarmenKell will now auto snipe vehicles
Object Slth_GLAInfantryJarmenKell will now auto snipe vehicles
Object CommercialAirliner has better crashing effectsm explodes in a ball of fire
Object TomahawkMissile has deviator gas
Object GC_Slth_GLAInfantryHijacker used by the above missile
Object SupplyPile the prison
Object BoatAsianFishing pirate junk with quad cannon guns and angry mob AK47
Object BoatTugboat pirate Dragonboat
Object BoatFishingTrowler pirate fishing boat with long range misisles
Object CivilianVehiclePTBoat Gattling gunboat
Object AmericaJetCargoPlane doesn't drop things at 1000ms intervals but rather at 300ms intervals like the Chinese plane
Object AmphibiousTransport works like a ferry, 
       make 2 waypaths with the end points named AmphibStart01 AmphibEnd01 and
       AmphibStart02 AmphibEnd02 respectively.

Migs and Stealth fighers get a button to fire only 1 missile so they can use 2 missiles on 2 different targets.

Take note that scud storm weapons are affected by this map.ini.
