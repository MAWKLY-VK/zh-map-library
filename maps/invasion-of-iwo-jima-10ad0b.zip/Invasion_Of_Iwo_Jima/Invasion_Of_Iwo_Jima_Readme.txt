 YOU Downloaded C&C Generals Zero Hour MISSION:             Works Great with MODS:
            Invasion Of Iwo Jima
               By, sgtmyers88                               ZERO HOUR REBORN or NAVAL WARS   
 PLEASE DONT EDIT ANYTHING WITHOUT MY PERMISSION!!!
           
       
                    [CLASSIFIED: GENERALS EYES ONLY]

January 1945,



   To the General who recieves this,
	As you may know we have been planning the invasion of 
Iwo Jima for many months now and also explaining that Iwo Jima is the key goal in the stepping 
stones to Tokyo Japan. 
	The reason we are writing this to you is that YOU have been chosen for the command 
of the upcoming invasion. (date not set)
	General, as there was on "D-Day" the previous summer the factors of
when NOT if we invade play a role in 3 key factors: 

1.) Weather conditions.
2.) Enemy intel on our plans and movements.
3.) The training of the men you will be responsible of.
	
	But, from what were looking at this time, things are favorable for us
to invade within the next 1 to 2 months. The Japanese know that we will be setting 
our sights on Iwo Jima sometime in the future but they do not know how or when this
will come to be. But for what we know the Japanese know of the islands value to us that 
they have established a heavy defence force on the island for quite some time, 20 years of 
preparation to be exact. There is an estimated 20,000 of em' dug in through the most complex
array of bunkers and tunnel networks the world has ever seen.

	General, as you may know, the Marines are the ones who will be invading Iwo Jima. 
They will have some naval and air support, the Navy and Air Force will be pounding the
island to "soften them up" Then the Marines will be set out to land on the island via landing craft 
and later other forces will arrive by plane.

	Also, this fight will likely be infantry only, tanks and other vehicles
wont be readily available until those airfields are captured. This DOES NOT mean you won't be recieving
any vehicle support, it just means not a whole lot. So make use of and protect whatever we can get in there on the transports, because
the tanks will be easy targets if they get bogged down in the soft wet sand. 

OBJECTIVES: (Do in order as shown to minimize casulties and to ensure a swift success.)

1.) Bombard the island with naval and air support and land "safely" on the beach and establish a 
beachead by clearing out the defensive positions near your landing zone, (i.e. bunkers, arterilly platforms etc.) 
^ This will help make your push easier.

2.) Once thats done, begin to make your way to the Radio Station and capture it
by garrisoning some troops to clear it out and bring it under our control.
^ This will disable the Japanese's ability to coordinate units and radio for help from Japan. (or Warn Japan)  

3.) As the communications are compermised for the Japanese, capture the main airfield (the biggest)
so the B-29's and similar bombers can land here from bombing raids on Japan, because they have to ditch
into the Pacific otherwise and thats not good.(and in enemy waters on top of that, the Japanese sailors 
wont be too nice when rescuing the pilots that just finished bombing their homeland.)
^ Step 1 of 2 on capturing the airfields, also enables Paradrop Command at the Command Center. 
(hopefully you already have one established)

4.) With the main airfield secure, finish capturing the secondary airfield and clear out 
the enemies nearby. (so they dont try to re-capture it and take back their Zeros and Achivals in the hangars 
to use against us.) 
^ Step 2 of 2 on capturing the airfields, also enables vehicle drop to recieve Heavy Tanks (Also Known as the Crusader or M60 Patton depending on the mod)

5.) Now when the airfields are secure we still need to keep our planes from being shot down.
There is going to be some enemy risistance still hiding out in the hills to the east, including some anti air/machine gun nest bunkers.
They will defend their last control point well with mines and booby traps... disable the traps, 
remove the defenders, and knock out the bunkers.
^ Planes will land and/or bring units/supplies safely, Iwo Jima is then preety much secure.

	Also you asked: "Whats the new reason for capturing Iwo Jima?" Well, its still TOP SECRET and we 
cant reveal it UNTIL we see what the outcome of this battle will be.

	Good Luck, General.

                                                                         -Dismissed,
                                                                      General Macarther
                                                                       

HINTS/TIPS: 
1.)You may have to manually capture buildings attached to the airfields by using the capture building command.
2.)Also, watch out for booby traps and demo traps. (Dozers are good on removing these, including minefields)
3.)The Japanese have a vast array of Bunkers and Tunnel Networks. (Battleships are good on destroying these)
4.)There is a large supply pile and ammo/fuel dump near your landing area a little ways inland (northwest side), build a base around it.
5.)You might need to destroy the reinforcement pad at the main airfield to hamper enemy reinforcements and supply drops. 
6.)Piles of junk can buy you some time and bring free benefits. (they are repairable too)
7.)There are some GOOD AND BAD surprises in this mission.
8.)NO HELICOPTERS OR JETS for they were not in full service yet. (Earliest was in 1948 except for the German Messerscmitt Jet.)
9.)You may have to go directly to the command center to use your special abilities, due to some mod bugs. (i.e. paradrop, battleship bombardment etc.)
10.)To be historically accurate and balanced some upgrades should be overlooked. I tried to remove them but I dont know why it wont.
If you got a suggestion on how to remove them and fix other problems, it would be appreciated. (email address near bottom)


Guide to Units and Buildings:                         *May vary or be unavailible depending on MOD. (if one being used)

Iwo Jima Unit Name:                                               C&C Generals Unit Name:

Wheeled Dozer                                                     America Dozer
Treaded Dozer                                                     China Dozer                                               
B-29 Bomber                                                       GLA Cargo Plane
Japaniese Cargo Plane                                             China Cargo Plane
C-47 Cargo Plane                                                  C-130 Cargo Plane (America)
Propaganda Plane                                                  B-52 Heavy Bomber  
Landing Craft*                                                    Hovercraft Amphibious Transport*
Patrol Boat*                                                      Patrol Boat*
Battleship*                                                       Battleship*
Pilot                                                             Pilot
Marine Assault Soldier*                                           Marine*
Marine Assault/Grenader                                           Ranger
Marine Bazooka Advanced                                           Missile Defender
Marine Bazooka                                                    Tank Hunter
Marine Springfield No.4 Sniper                                    Pathfinder
Marine M1 Carbine Infantry                                        Redguard
Marine Heavy Machine Gunner 30cal.                                Mini-Gunner
Marine Flamethrower Infantry*                                     Flame Trooper*/Toxin Rebel
Marine Combat Officer*                                            China Officer*
Japaniese Suicide soldier                                         Terrorist
Japaniese K98/Type 5 Riflemen                                     Redguard
Japaniese Bazooka Infantry                                        Tank Hunter
Japaniese K98/Type 5 Sniper                                       Pathfinder/Jarmen Kell
Japaniese Heavy Machine Gunner 30cal.                             Mini-Gunner
Japaniese Sabatour                                                Sabatour
Japaniese Hijacker                                                Hijacker
Japaniese Radio Operator                                          Hacker
Japaniese Grenader                                                Ranger
M5 Stuart Tank*                                                   Guardian Drone*/Sentry Drone
M4A3 Sherman FireFly                                              Milita Tank
M4 Sherman*                                                       Crusader*/M60 Patton*/M55 Sheridan*
Combat Jeep                                                       Technical
Medical Jeep                                                      Ambulance Humvee                   
Sherman Flame Tank                                                Dragon Tank
Anti Aircraft Halftrack                                           Quad Cannon
Chi-ha Tank                                                       Scorpion Tank
Mobile Arterilly Platform                                         Inferno Cannon
Armored Personel Carrier                                          Troop Crawler
Advanced Armored Personel Carrier                                 Assault Troop Crawler
Anti Aircraft/Personel Tank                                       Gattling Tank
Zero Fighter Plane                                                Cessna Plane
Achival Fighter/Bomber Plane                                      Crop Duster Plane
Supply Truck                                                      Supply Truck
Radar Van                                                         Radar Van
Landing Craft*                                                    LTVP Amtrack*
USMC Command Center                                               America Command Center
Supply Center                                                     China Supply Center
Power Plant                                                       Cold Fusion Reactor                                                     
Advanced Power Plant                                              Nuclear Reactor
Arterilly Platform/Bunker                                         Fire Base
Bunker                                                            China Bunker
Armored Bunker                                                    China Advanced Bunker
Speaker Tower                                                     Propaganda Tower
Anti Aircraft/personel Gun                                        Gattling Cannon
Light Weapons Factory                                             Arms Dealer
Heavy Weapons Factory                                             China War Factory
Light Bunker/Anti Aircraft Bunker                                 Stinger Site
Heavy Bunker                                                      Civilian Bunker
Barracks                                                          China Barracks
Advanced Barracks                                                 America Barracks
Small Tunnel Network                                              Tunnel Network
Large Tunnel Network                                              Sneak Attack Tunnel Network
Heavy Arterilly                                                   Tech Arterilly Platform
Oil Derrick                                                       Tech Oil Derrick/Constructable Oil Derrick*
Reinforcement/Supply Drop Pad                                     Tech Reinforcement Pad
Repair Bay                                                        Tech Repair Bay
Oil Refinery                                                      Tech Oil Refinery
Supply Warehouse                                                  Supply Warehouse
Supply Dock                                                       Supply Dock

So are you ready for battle?

To gain access to the battlefield controls: Extract, copy, and paste 
the Invasion Of Iwo Jima files to your Command & Conquer Generals Zero Hour Map Directory.


Possible Bugs or Problems:
	The most obvious problem (im sorry to say) is on slower computers where the game is slow and/or choppy and/or does not run at all.
(otherwise recommended for pentium III computers with at least 512 mb RAM or better because I tried making realistic troop numbers and to make 
this as close to scale as possible. (possible= computer functionality) and still be functional for my computer<<<200gb HD 1gb RAM with pentium 4)<<<hopefully yours for best results (or close to anyway)
And if you want to use a MOD I know Zero Hour Reborn and Naval Wars works well but you can try your own MOD 
and see how it does, but it might screw up the mission or crash the game if the MOD does not work.
Oh, you might see some superweapon timers pop up when using some MODS. Disreguard them, they wont screw up the game.
If they do appear (which is very unlikely) Im sorry, but if they did I cant figure out how they got there and how to remove them, if you can help me fix that... let me know! 
Finally, Some Commands you may have to go directly to the Command Center to use and (possibly) even then they may not work.


MISC:
	I am also intrested if anyone has or knows of any graphics, and WWII vehicle mods (i.e. Sherman Tanks, Zero Fighters, blood/explosion FX)
Because that would really make this mission 100% better! And your Satisfaction 100% better!
I also have a simple skirmish map of this mission that EVERYONE can download and try out. (Not as good as the mission but easier on your computer) <<<Alternitive you have a pentium III or less 
or just have memory/graphics problems.


Map designed, created, and engineered by. sgtmyers88
June 2005
	It took alot of painstaking hours and lots of frustrating issues to resolve, just to get this map to its current (presentable) status.
You can place a question, comment, suggestion, or other information relating to Command & Conquer and/or My Maps
at: sgtmyers88@yahoo.com using e-mail or instant messenger.

SPECIAL NOTE: Relive History, and HAVE FUN!!!

SPECIAL THANKS:
THE UNITED STATES MARINE CORPS
TO ALL the men and women on BOTH American and Japanese sides who fought and/or died In The Invasion Of Iwo Jima.
AND THE SAME TO ALL other troops who fought and/or died in past and present battles. 
EA GAMES/WESTWOOD STUDIOS For all of the Command & Conquer Games, BATTLEFIELD 1942, and other products.
EA/BETA SOFTWARE for Generals Worldbuilder
VALUSOFT/3LV GAMES For their WWII IWO JIMA 1st.person missions.
UNITED AMERICAN VIDEO CORP For their AWESOME documentry videos on Tarawa and Iwo Jima. 
(wish I could put some clips in this Mission, but its a Video Tape and I would also need to check with them to avoid copyright violation. BE CAREFUL WITH COPYRIGHTING PLEASE!)
THE INTERNET SITE that posts my map. 
MY FATHER For his Knowledge. Who also is (and always will be) a Marine, who served in Veitnam.
AND MY GRANDFATHER Who is a retired Army Officer who served in WWII.
And some good ole research with books and pictures.

NOTICE:
This map and related files IS made and owned by sgtmyers88. 
YOU MAY NOT CLAIM ANY PART OF THIS MAP AS YOUR OWN!!! 
(EVEN THE GENERALS ZERO HOUR GAME YOU PLAY IT ON, THE OWNERSHIP RESPECTS TO IT ARE TO EA GAMES AND FORMER WESTWOOD STUDIOS.) 
Command & Conquer, Command & Conquer Generals, Command & Conquer Generals Zero Hour EXPANSION PACK, BATTLEFIELD 1942, and all other related properties
are registered trademarks of Electronic Arts. 
COPYRIGHT 2003 ELECTRONIC ARTS, INC.  WESTWOOD STUDIOS and EA GAMES are an Electronic Arts Brand.
Worldbuilder IS Beta Software all property respects of Worldbuilder are to EA/Beta.
GO TO: www.eagames.com for more information

WWII IWo Jima is trademarked published and distrubuted by VALUSOFT, INC. All other trademarks are property of their respective owners. All rights reserved.
COPYRIGHT 2002 VALUSOFT
GO TO: www.valusoft.com for more information.

UNITED AMERICAN VIDEO CORP's "THE MARINES AT TARAWA" and "TO THE SHORES OF IWO JIMA" are all property rights of UNITED AMERICAN VIDEO CORP.
Reproduction in whole or part without written permission of copyright owner is prohibited.
COPYRIGHT 1986 UNITED AMERICAN VIDEO CORP, all rights reserved.
GO TO: www.unitedamericanvideo.com for more information.

2005 sgtmyers88 
SEMPER~FI 