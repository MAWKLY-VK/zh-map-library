hi generals a breifing before u play

this map was created for cncmaps.com
To place this map into the game put it
and its folder here: 
My Documents\Command and Conquer Generals Zero Hour Data\Maps\

if you like this map try Greenday2.0

map favors usa generals air,lazer...
watch out for arouras they have  mod

I'd appreciate it if this map were 
left unmodified and in its orginal
condition, if u have an idea on how 
to inprove it, if u have a membership 
plz post your comment on cncmaps.net 
under map comments

		   thx!!
		    Redlack

BlueSnows
Things you should know:
-Auroras WeaponSet has been modified
-Humvee has been modified to fit USA General's and their powers
-SentryDrones WeaponSet has been modified

Most of the scipting came from cncmaps and the wonderful staff there thx!
if it isn't obvios this map is for 'C&C Gen ZH'