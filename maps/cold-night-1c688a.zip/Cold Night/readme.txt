Cold Night

Author: GB

Map Size: 250 x 300

# Players: 2

On an icy night, a frosty wind is sweeping across the wild and mountainous landscape of this lonely area. A one-track railway that cuts the landscape provides the important link to the outside world.