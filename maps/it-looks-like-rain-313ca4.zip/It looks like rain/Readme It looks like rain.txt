You download this Map from www.CNCDEN.com
=============================================================================================
It looks like rain is created by Funkelchen
=============================================================================================
It looks like rain is my first 8 Player map, I with the desired the user dealt. They want large Map's, and water is to give it in the Map's. Somewhere in the world this island lies, and a tempest approaches. The water already accepted the unmistakable greenish color, as always if Storm-warning is. The thunderstorm is exact over the island, and now it begins to rain. The color of the Wasser's, the thunderstorm and the cold rain, provide in the dawn for uncomfortableness. Resources are to be found distributed on the whole map to each player, begin with a Supply dock. This map is fully AI suited and can thus also alone be played. To enjoy...

Map Daten: 
Map name: It looks like rain
Version:  1.0
Map Author: Funkelchen
Released: 24.01.2005
Map size: 450x450
Players: 8
Skirmish Compatible: Yes
Resources: 
Terrain: Desert
Time: Morning
Objects: 944
Game: Zero:Hour/Die Stunde Null
Schulnote: -
