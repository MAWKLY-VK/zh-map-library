
"Battle Fortress III: The Gauntlet"



Created by Rhino

This is an 8-player eye appealing 'team based' Temperate Map that features walls and rivers separating the players. Lots of money along with a few tech goodies. Good amount of room to build and expand.


For the Zero Hour Expansion

