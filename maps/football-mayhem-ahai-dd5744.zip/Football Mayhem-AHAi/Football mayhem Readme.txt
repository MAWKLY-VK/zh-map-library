This map is for the game Command & Conquer: Generals

Map Name: FootBall Mayhem

Map Author: Thrawn28  (Englands Biggest Slacker)

Released: 09/09/03

Map size: 100 x 200

Usage: Online or Skirmish mode against the computer

Players: 2

Description:a small Tournament style map 
which took me 3 hours to make one night while i was bored (this included falling asleep at the keyboard)
all you football nuts out there will like it im sure 
the map contains a moderate amount of supplies so use them wisely and dont forget to capture those oil derricks 
(the map contains 4 derricks )

Note:this map use's RVMECH's almost human Ai 

playing suggestions:well for some reason the Ai doesnt like the lower part of the map
 so its best to put the enemy ai in the top starting position 
i also suggest you use a Brutal Ai for the best playing experience
its also lots of fun online (quick matches 30 minutes max :D )

Installation: Unzip and place  folder in:
My Documents->Command And Conquer Generals Data->Maps
...and enjoy!

please send any comments to  de_thrawn@msn.com