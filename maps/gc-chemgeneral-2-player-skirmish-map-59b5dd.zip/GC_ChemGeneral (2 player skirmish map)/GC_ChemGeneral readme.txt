*********GC_ChemGeneral readme*************




Map Info:
----------

Game:	     Command and Conquer Generals ZeroHour
Name:        GC_ChemGeneral
Created by:  snowy007
Players:     2 players




installation:
--------------

unzip and put the folders in:
My Documents\Command and Conquer Generals Zero Hour Data\Maps\




description:
------------

the official Chemical General map of the Generals challenge. did not change
anything.







