                                                   Home on the Range
                                                  ===============


Date created: 06/06/05
size : 400x400
Map Type: Temperate 4 player Skirmish map
Setting: Night time
Weather: High winds, Rain and thunder storms
www: This map was created for www.cncmaps.com all rights reserved.
Author: Judds
Inspired by: Natasha Sankey aged 9
email: Judds@cncmaps.tk
Time taken: Drawings for this map took around 3 hours by my daughter and approx 3 hours to build.

 This map is a real good map, it is fast paced and fun map to play, as the tech buildings are few and far between it makes great opportunity to have a good slogfest for control of tech buildings.

Supply piles for each base as default, after which it is down to you General to find the oil derriks and secure them to obtain a steady flow of cash into you balance.

This map was made by myself Judds of www.cnc.maps.com but was totally inspired and designed by my 9 year old daughter, She has great artistic abilities and had fun designing this map.

I am now in the progress of making my next map which is also one of my daughters designs and to be honest if this is an insight to her design capabilities i think that www.cncmaps.com is to houored with a new stock of maps.
Thankyou for downloading this map and i hope you find the fun factor as cool as i did.

Judds, helped by Natasha my 9 year old daughter.