IntroducingTheGangOf4�


Chinese Single Player Mission for Zero Hour. Mapsize: 350 x 350
Full scripted, included a few goodies. All ways lead to Rome... 
No tankrush, no turtling, just players sweat.


Resolution:	1152 x 864	O.K.
		1024 x 768	O.K.
		 800 x 600	Teletext is cut off

After unzip into C&C-Generals-Zero-Hour map folder go
Solo Play->Skirmish->Select Map->Unofficial Maps
and select "IntroducingTheGangOf4.map".

The files contained within this package are intellectual property of nipthecat. Commercial use (includes modifications) is not permitted.

May-04-2005, nipthecat@web.de



Play it LOUD!!!

_______________________________________________________________________

The story goes like this: 

As we know god's own country won the war in Iraq and Afghanistan. While democracy blossoms the remaining Taliban, Al-Qaida members and Iraqi officials wrongly called GLA found a save haven in Sudan, Africa.
Really save?
No!
Because China fears upcoming connections and activities between the terrorist factions in Sudan and in countries close to Chinas border, the chinese leadership decided to send a very special forces team of four high-trained, open-minded and nice-looking guys'n'girls to Sudan. Called "The Gang Of 4" not to confuse with a very nice former rockband. The goal of our gang is to stop the islamic nincompoop and take control of their bionics by using all forces wisely. 
Run without strategy and you'll fail.
Be prepared.
The second lesson on how to start a war and the continuing story called "Kim Is Ill - The Beloved Leader Of The North-Korean People Meets The Gang Of 4"� is in progress...

_______________________________________________________________________

Roadmap to peace

1.
Don't harass too many civilians! If true, then fine - else locals will remove player from their world.

2.
Meet C.I.A. officials, unfortunately you depend upon them.

3.
Search for collaborators, collect wheels and techs.

4.
Accomplish first objective, that means capture the enemy radio post to go further...

5.
...nice to see you alive and ready to finally take over an enemy biolab, not to destroy it!
_______________________________________________________________________

All bugs owned by EA.