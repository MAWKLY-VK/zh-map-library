basically the name ezplains it all map made by willietoo its a   4 player map
has you on ilsand   you got 3 amphibous carrier to move around and some more scattered around the map
they dont die very fast(there hp is 10000) there is oil on a couple islands and a refinery on the middle island
and small supply piles everywhere

Installation
Put this in My Documents/Command and Conuer Generals Zero Hour Data/Maps