Map Name: Cliff Assault
Author: Halkeye (james)
My email: jfowl007@yahoo.com.au 
Number of players: 4

This is my first map so
PLEASE DONT EDIT THIS MAP WITHOUT MY PERMISSION!
YOU MAY NOT CLAIM THIS MAP AS YOUR OWN!

Map Description:

A Medium size map with some tech buildings in the middle and some more scattered around the place
mostly forest but looks good.  This map can be played as singleplayer or multyplayer.

Directions for Installing
Extract to \My Documents\Command and Conquer Generals Zero Hour Data\Maps\ 

Have Fun
