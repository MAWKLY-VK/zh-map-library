:: WARNING!!! Set font to Courier New and disable word wrap to ::
:: view this readme file correctly.                            ::
         ____ 
         \   \===================================================
          \   \                                                 =
     ____  \   \     *** Alliance ***                           =
    /   /   \   \    An elite organization dedicated "to        =
   /   /_____\   \   serve for the better cause"                =
  /               \                                             =
 /_________________\=============================================


--< File Data >--------------------------------------------------
[Name]         = "In Deep Water"
[File Name]    = 002-In_Deep_Water.map
[File Size]    = 123 KB
[Map Size]     = 240 X 240
[Players]      = 2
[Time Setting] = Afternoon
[Field Intel]  = Mostly flat and open plains
[Resources]    = Medium
-----------------------------------------------------------------


--< Mission Briefing >-------------------------------------------

  [From]      = Alliance - Manila HQ
  [To]        = General ~
  [Time Post] = ~~:~~:~~ ~/~~/~~

Welcome General to our neck of the woods here in ???,
Philippines.  The thing is that these woods have been swept away
by the water.  Recent heavy rainstorms have caused landslides
at some parts and heavy flooding in others.  Forunately, those
storms have finally ended, and that the floodwaters are going
to be pushed back later in the day.  It's too bad that isn't
the end of the problem.

This area has also been subjected to raids by terrorist groups.
They are mostly aiming for just supplies that run through here,
like AK47s, RPGs, etc.  They have not stolen anything major, but
rumors are that they are planning for something big.  As you
will see later, these guys have set up base on a hill, away from
the floodwater.  I bet these guys are going to grab way more
than relief supplies.

General, right now there is nothing we can do.  These guys might
start making their move at the moment the floodwaters has been
pushed back entirely.  Your job here is to eliminate them as 
best as you can, while causing little damage to civilian
and government property.  It's hard, so good luck!


/--[ Manila HQ         ]--\
\--[ Alliance Division ]--/

-----------------------------------------------------------------


--< Additional Intel >-------------------------------------------
:: The water should be able to reside soon.  You won't be able 
   to move outside your base until then, so use this time 
   wisely to build up your base and your army. (The exception 
   is stated below.)
:: The governement is sending in relief supplies as well as an 
   army helicopter.  The landing pad that the helicopter is near
   is also the drop-off site for those relief supplies.  Take 
   advantage of both for money and travel.
:: In order to prevent futher mass property damage, superweapons
   are banned in this mission.
   [NOTE FOR CHINESE GENERALS: Upgrades that were available at
   the Nuclear Silo can be found in the Propanganda Center]
:: For futher assistance, use these following contacts:
   * PM at DEN Forums = http://forums.cncden.com
   * PM at FA/C&C Tomorrow Forums = http://forum.finalalert.net/
   * HQ E-mail = flippster06@mail.com
   * Alt. E-mail = angel_ace88@yahoo.com
   * Alliance website = http://alliance.finalalert.net
-----------------------------------------------------------------

       //---[ This map is property of the Alliance. ]---\\
       \\---[ Alliance �2005 - All rights reserved. ]---//

==[ END FILE ]===================================================