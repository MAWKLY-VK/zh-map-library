==========================================

Game: Command & Conquer Generals Zero Hour.

Author: map unknown to me , Fixed for Pro rules by Johnny Bravo aka JB

******All the scripts are made by me Johnny Bravo from Gameranger******
The map is fixed and pro rules are enforced for everybody playing on it!
Some noob have made wrong scripts in the map that forbid Airforce general for having 
carpet bomber.It does not matter your rank.If you are air you will never get carpet bomber.
It has been made unattentionally , because of lacking knowledge.
I fixed this, and once AirF general becomes 3 star general, he can get carpet bomber.

Map features:

1. No Aurora, DemoBike, Superweapon and carpet after 3 star for everyone - 
so called pro rules in Gameranger.
2. Now map can be played in all kinds of cash start modes.All players gets
aditional 500 cash for fast develope, instead of a fixed cash for all.

Enjoy


How to istall?
--------------

  You will have to copy or move the map folder with all the files inside it to 
 "%USERPROFILE%\My documents\Command & Conquer Generals Zero Hour Data\maps"
  Now you will have to run the game to to maps and click on unofficial maps. there you 
  will have to find it.

How to uninstall?
-----------------
  
  You just delete the map folder
  in "%USERPROFILE%\My documents\Command & Conquer Generals Zero Hour Data\maps"
  

===========================================